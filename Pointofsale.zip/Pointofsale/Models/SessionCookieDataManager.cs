﻿using RetailMaster.POS.Models;

namespace RetailMaster.POS.Web.DefaultData
{
    public class SessionCookieDataManager
    {
        public static string SessionMenu = "lererm olkd fasdkfalskdf";
        public static string LogedInInfo = "poyrlkklekldlf ksjdie iewrkllkfd";
        public static string globalSetup="dasdas sadasd asdasd";
        public static string buyData = "oui rf  xvefer jhkhtya";
        public static string freeData = "mmv ifkfk whwpg deimfl";
        public static string tempPackage = "oyi kjgj fhrj rfitr kgd";
        public static string tempPackageIssue = "ruiter n,xvn sdjflskdf uewepp sdhfkjs";
        public static string tempDisCircularDetails = "uioert sfdkasd ahs iui sd";
        public static string tempPriceCngDetails = "ioytrt rtjkgf nmnmcvjkde flsfjfke";
        public static string tempPayLess = "ipelfmgkdji rurml djkeildm ekrk";
    }
}