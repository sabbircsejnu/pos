﻿namespace RetailMaster.POS.Web.Models
{
    public class CustomerCategoryOption
    {
        public string Catgry { get; set; }
    }
}