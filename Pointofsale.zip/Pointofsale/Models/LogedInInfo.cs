﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RetailMaster.POS.Web.Models
{
    public class LogedInInfo
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string ShopID { get; set; }
        public string ShopName { get; set; }
        public string CounterID { get; set; }
    }
}