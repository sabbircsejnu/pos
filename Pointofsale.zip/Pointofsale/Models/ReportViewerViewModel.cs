﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RetailMaster.POS.Web.Models
{
    public class ReportViewerViewModel
    {
        public string ReportPath { get; set; }
    }
}