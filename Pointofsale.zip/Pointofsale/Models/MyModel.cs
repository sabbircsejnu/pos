﻿using System.Collections.Generic;
using System.Web.WebPages.Html;

namespace RetailMaster.POS.Web.Models
{
    public class MyModel
    {
        //The Values of selected items
        public string[] SelectedCars { get; set; }
        //The list of all cars
        public IEnumerable<SelectListItem> AllCars { get; set; }
    }
}