﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Antlr.Runtime.Misc;
using AutoMapper;
using Microsoft.Ajax.Utilities;
using MoreLinq;
using Newtonsoft.Json;
using RetailMaster.POS.Models;
using RetailMaster.POS.Service;
using RetailMaster.POS.Web.BLL;
using RetailMaster.POS.Web.ViewModels;
using RetailMaster.POS.Web.Models;

namespace RetailMaster.POS.Web.Controllers
{
    public class SetupController : Controller
    {
        private readonly IGlobalSetupService _globalSetupService;
        private readonly IPGroupService _pGroupService;
        private readonly IProductService _productService;
        private readonly IBrandTypeService _brandTypeService;
        private readonly ISupplierService _supplierService;
        private readonly ISupplierRegPrdService _supplierRegPrdService;
        private readonly IStyleSizeService _styleSizeService;
        private readonly ICustomerMstService _customerMstService;
        private readonly IShopListService _shopListService;
        private readonly IMenuURLService _menuURLService;
        private readonly IUsersMenusService _usersMenusService;
        private readonly IBuyAndGetService _buyAndGetService;
        private readonly IBuyCentralService _buyCentralService;
        private readonly IPackageService _packageService;
        private readonly IPackageIssueDetailService _pckPackageIssueService;
        private readonly IPackageIssueService _pckPackageIssue;
        private readonly ICircularDiscountService _circularDiscountService;
        private readonly ICircularDiscountDetailService _circularDiscountDetailService;
        private readonly ICircularPriceChangedService _priceChangedService;
        private readonly ICircularPriceChangedDetailService _priceChangedDetailService;
        private readonly ISalesManService _salesManService;
        private readonly IDesignationService _designationService;
        private readonly IEmployeeService _employeeService;
        private readonly IPayLessService _payLessService;

        public SetupController(IGlobalSetupService globalSetupService, IPGroupService pGroupService,
            IProductService productService, IBrandTypeService brandTypeService, ISupplierService supplierService, ISupplierRegPrdService supplierRegPrdService
            , IStyleSizeService styleSizeService, ICustomerMstService customerMstService, IMenuURLService menuURLService, IUsersMenusService usersMenusService
            , IShopListService shopListService, IBuyAndGetService buyAndGetService, IBuyCentralService buyCentralService, IPackageService packageService,
            IPackageIssueDetailService pckPackageIssueService, ICircularDiscountService circularDiscountService, ICircularDiscountDetailService circularDiscountDetailService,
            ICircularPriceChangedService priceChangedService, ICircularPriceChangedDetailService priceChangedDetailService, ISalesManService salesManService,
            IDesignationService designationService, IEmployeeService employeeService, IPayLessService payLessService, IPackageIssueService pckPackageIssue)
        {
            _globalSetupService = globalSetupService;
            _pGroupService = pGroupService;
            _productService = productService;
            _brandTypeService = brandTypeService;
            _supplierService = supplierService;
            _supplierRegPrdService = supplierRegPrdService;
            _styleSizeService = styleSizeService;
            _customerMstService = customerMstService;
            _shopListService = shopListService;
            _menuURLService = menuURLService;
            _usersMenusService = usersMenusService;
            _buyAndGetService = buyAndGetService;
            _buyCentralService = buyCentralService;
            _packageService = packageService;
            _pckPackageIssueService = pckPackageIssueService;
            _circularDiscountService = circularDiscountService;
            _circularDiscountDetailService = circularDiscountDetailService;
            _priceChangedService = priceChangedService;
            _priceChangedDetailService = priceChangedDetailService;
            _salesManService = salesManService;
            _designationService = designationService;
            _employeeService = employeeService;
            _payLessService = payLessService;
            _pckPackageIssue = pckPackageIssue;
        }

        public ActionResult Index()
        {
            return View();
        }
        private LogedInInfo GetLogedInInfo()
        {
            LogedInInfo info = new LogedInInfo();
            if (HttpContext.Request.Cookies["POSLogedInInfo"] != null)
            {
                HttpCookie cookie = HttpContext.Request.Cookies.Get("POSLogedInInfo");
                info = Newtonsoft.Json.JsonConvert.DeserializeObject<LogedInInfo>(cookie.Value) as LogedInInfo;
            }
            return info;
        }

        #region Global Setups

        public ActionResult GlobalSetup()
        {
            if (!IsPermissionApply("Setup", "GlobalSetup"))
            {
                return RedirectToAction("Index", "Home");
            }
            return View();
        }

        [HttpPost]
        public ActionResult UpdateGlobalSetup(GlobalSetupViewModel model)
        {
            try
            {
                GlobalSetup dbModel = new GlobalSetup();
                dbModel = Mapper.Map<GlobalSetupViewModel, GlobalSetup>(model);

                var dataExists = _globalSetupService.Gets();
                if (dataExists.Count() == 0)
                {
                    dbModel.GlobalSetupID = "1";
                    _globalSetupService.Create(dbModel);
                    _globalSetupService.Save();
                }
                else
                {
                    var data = _globalSetupService.Gets().FirstOrDefault();
                    data.goldrate = model.goldrate;
                    data.discount = model.discount;
                    data.StoreId = model.StoreId;
                    data.VAT = model.VAT;
                    data.ALLOWBNL = model.ALLOWBNL;
                    data.TAP = model.TAP;
                    data.VATL = model.VATL;
                    data.EnableSCAN = model.EnableSCAN;
                    data.ShowPOL = model.ShowPOL;
                    data.AllowMultiScan = model.AllowMultiScan;
                    data.OpenCashDrawer = model.OpenCashDrawer;
                    data.MaxOrderCheck = model.MaxOrderCheck;
                    data.IsZoneID = model.IsZoneID;
                    data.IsPoint = model.IsPoint;
                    data.FiscYr = model.FiscYr;
                    data.FiscYr2 = model.FiscYr2;
                    data.IsCPUAverage = model.IsCPUAverage;
                    data.DisableWSP = model.DisableWSP;
                    data.IsVatAfterDiscount = model.IsVatAfterDiscount;
                    _globalSetupService.Update(data);
                    _globalSetupService.Save();
                }

            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult FindByStoreId(string storeId)
        {
            IEnumerable<GlobalSetupViewModel> result = null;
            IEnumerable<GlobalSetup> datas = _globalSetupService.Gets();
            result = Mapper.Map<IEnumerable<GlobalSetup>, IEnumerable<GlobalSetupViewModel>>(datas);

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        #endregion

        #region PGroup

        public ActionResult PGroup()
        {
            if (!IsPermissionApply("Setup", "PGroup"))
            {
                return RedirectToAction("Index", "Home");
            }
            //ReportViewerViewModel model = new ReportViewerViewModel();
            //string content = Url.Content("~/Reports/Viewer/SetupReportViewer.aspx");
            //model.ReportPath = content;
            //return View("ReportViewer", model);
            return View();
        }

        [HttpPost]
        public ActionResult CreatePGroup(PGroupViewModel model)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    PGroup dbModel = new PGroup();
                    dbModel = Mapper.Map<PGroupViewModel, PGroup>(model);

                    #region duplicate check
                    //for new item duplicate check  primary key must be zero
                    dbModel.GroupID = "0";
                    if (_pGroupService.IsDuplicate(dbModel))
                    {
                        return Json(new { result = false, Error = "Duplicate Data" }, JsonRequestBehavior.AllowGet);
                    }
                    #endregion

                    //get primary key value
                    dbModel.GroupID = new GlobalClass().GetMaxId("GroupID", "PGroup");
                    if (dbModel.GroupID == "1")
                        dbModel.GroupID = "101";

                    _pGroupService.Create(dbModel);
                    _pGroupService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult UpdatePGroup(PGroupViewModel model)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    var data = _pGroupService.Get(model.GroupID);
                    data.GroupName = model.GroupName;
                    data.FloorID = model.FloorID;
                    data.VATPrcnt = model.VATPrcnt;
                    data.DiscPrcnt = model.DiscPrcnt;

                    if (_pGroupService.IsDuplicate(data))
                    {
                        return Json(new { result = false, Error = "Duplicate Data" }, JsonRequestBehavior.AllowGet);
                    }

                    _pGroupService.Update(data);
                    _pGroupService.Save();

                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "Updated" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult DeletePGroup(PGroupViewModel model)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    var data = _pGroupService.Get(model.GroupID);
                    _pGroupService.Remove(data);
                    _pGroupService.Save();

                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult PGroupList()
        {
            IEnumerable<PGroupViewModel> result = null;
            IEnumerable<PGroup> datas = _pGroupService.Gets();
            result = Mapper.Map<IEnumerable<PGroup>, IEnumerable<PGroupViewModel>>(datas);

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        public ActionResult FindByGroupId(string groupId)
        {
            PGroupViewModel result = mFindByGroupId(groupId);

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        private PGroupViewModel mFindByGroupId(string groupId)
        {
            PGroupViewModel result = null;
            PGroup datas = _pGroupService.Get(groupId);
            result = Mapper.Map<PGroup, PGroupViewModel>(datas);
            return result;
        }
        #endregion

        #region Product

        public ActionResult Products()
        {
            if (!IsPermissionApply("Setup", "Products"))
            {
                return RedirectToAction("Index", "Home");
            }
            List<PGroupViewModel> result = null;
            IEnumerable<PGroup> data = _pGroupService.Gets();
            result = Mapper.Map<IEnumerable<PGroup>, IEnumerable<PGroupViewModel>>(data).ToList();

            PGroupViewModel obj = new PGroupViewModel();
            obj.GroupID = "";
            obj.GroupName = "Select";
            result.Insert(0, obj);

            ViewBag.GroupList = new SelectList(result, "GroupID", "GroupName");
            return View();
        }
        [HttpPost]
        public ActionResult CreateProduct(ProductViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    Product dbModel = new Product();
                    dbModel = Mapper.Map<ProductViewModel, Product>(model);


                    #region Get Group Name

                    PGroupViewModel result = null;
                    string idDecimal = model.GroupID;
                    PGroup datas = _pGroupService.Get(idDecimal);
                    result = Mapper.Map<PGroup, PGroupViewModel>(datas); ;
                    dbModel.GroupName = result.GroupName;

                    #endregion

                    #region duplicate check
                    dbModel.PrdID = "0";
                    if (_productService.IsDuplicate(dbModel))
                    {
                        return Json(new { result = false, Error = "Duplicate Data" }, JsonRequestBehavior.AllowGet);
                    }
                    #endregion

                    dbModel.PrdID = new GlobalClass().GetMaxId("PrdID", "Product");
                    if (dbModel.PrdID == "1")
                        dbModel.PrdID = "1001";

                    _productService.Create(dbModel);
                    _productService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult UpdateProduct(ProductViewModel model)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    var data = _productService.Get(model.PrdID);
                    data.PrdName = model.PrdName;
                    data.FloorID = model.FloorID;
                    data.GroupID = model.GroupID;
                    data.GroupName = model.GroupName;
                    data.VATPrcnt = model.VATPrcnt;
                    data.DiscPrcnt = model.DiscPrcnt;

                    if (_productService.IsDuplicate(data))
                    {
                        return Json(new { result = false, Error = "Duplicate Data" }, JsonRequestBehavior.AllowGet);
                    }

                    _productService.Update(data);
                    _productService.Save();

                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "Updated" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult DeleteProduct(ProductViewModel model)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    var data = _productService.Get(model.PrdID);
                    _productService.Remove(data);
                    _productService.Save();

                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ProductList()
        {
            IEnumerable<ProductViewModel> result = null;
            IEnumerable<Product> datas = _productService.Gets();
            result = Mapper.Map<IEnumerable<Product>, IEnumerable<ProductViewModel>>(datas);

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }


        public ActionResult FindByProductID(string prdID)
        {
            ProductViewModel result = mFindByProductID(prdID);

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        private ProductViewModel mFindByProductID(string prdID)
        {
            ProductViewModel result = null;
            Product datas = _productService.Get(prdID);
            result = Mapper.Map<Product, ProductViewModel>(datas); ;
            return result;
        }

        public ActionResult ProductFindByGroupID(string pGroupID)
        {
            List<ProductViewModel> result = null;
            IEnumerable<Product> data = _productService.GetProductByPGroupID(pGroupID);
            result = Mapper.Map<IEnumerable<Product>, IEnumerable<ProductViewModel>>(data).ToList();

            ProductViewModel obj = new ProductViewModel();
            obj.PrdID = "";
            obj.PrdName = "Select";
            result.Insert(0, obj);

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                          new JsonSerializerSettings()
                          {
                              ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                          });


            return Content(list, "application/json");
        }

        #endregion

        #region Brand Type
        public ActionResult BrandType()
        {
            if (!IsPermissionApply("Setup", "BrandType"))
            {
                return RedirectToAction("Index", "Home");
            }
            return View();
        }
        [HttpPost]
        public ActionResult CreateBrandType(BrandTypeViewModel model)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    BrandType dbModel = new BrandType();
                    dbModel = Mapper.Map<BrandTypeViewModel, BrandType>(model);

                    #region duplicate check
                    //for new item duplicate check  primary key must be zero
                    dbModel.BTID = "0";
                    if (_brandTypeService.IsDuplicate(dbModel))
                    {
                        return Json(new { result = false, Error = "Duplicate Data" }, JsonRequestBehavior.AllowGet);
                    }
                    #endregion

                    //get primary key value
                    dbModel.BTID = new GlobalClass().GetMaxId("BTID", "BrandType");
                    if (dbModel.BTID == "1")
                        dbModel.BTID = "1001";

                    _brandTypeService.Create(dbModel);
                    _brandTypeService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult UpdateBrandType(BrandTypeViewModel model)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    var data = _brandTypeService.Get(model.BTID);
                    data.BTName = model.BTName;

                    if (_brandTypeService.IsDuplicate(data))
                    {
                        return Json(new { result = false, Error = "Duplicate Data" }, JsonRequestBehavior.AllowGet);
                    }

                    _brandTypeService.Update(data);
                    _brandTypeService.Save();

                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "Updated" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult DeleteBrandType(BrandTypeViewModel model)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    var data = _brandTypeService.Get(model.BTID);
                    _brandTypeService.Remove(data);
                    _brandTypeService.Save();

                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult BrandTypeList()
        {
            IEnumerable<BrandTypeViewModel> result = null;
            IEnumerable<BrandType> datas = _brandTypeService.Gets();
            result = Mapper.Map<IEnumerable<BrandType>, IEnumerable<BrandTypeViewModel>>(datas);

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        public ActionResult FindByBrandTypeID(string btID)
        {
            BrandTypeViewModel result = mFindByBrandTypeID(btID);

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        private BrandTypeViewModel mFindByBrandTypeID(string btID)
        {
            BrandTypeViewModel result = null;
            BrandType datas = _brandTypeService.Get(btID);
            result = Mapper.Map<BrandType, BrandTypeViewModel>(datas);
            return result;
        }
        #endregion

        #region Suppliers

        public ActionResult Suppliers()
        {
            if (!IsPermissionApply("Setup", "Suppliers"))
            {
                return RedirectToAction("Index", "Home");
            }
            return View();
        }
        [HttpPost]
        public ActionResult CreateSupplier(SupplierViewModel model)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    Supplier dbModel = new Supplier();
                    dbModel = Mapper.Map<SupplierViewModel, Supplier>(model);
                    dbModel.DOE = DateTime.Now;

                    List<SupplierRegPrdViewModel> olist = model.RegPrd;

                    List<SupplierRegPrd> dbModelPrd = new List<SupplierRegPrd>();
                    dbModelPrd = Mapper.Map<List<SupplierRegPrdViewModel>, List<SupplierRegPrd>>(olist);

                    #region duplicate check
                    //for new item duplicate check  primary key must be zero
                    dbModel.SupID = "0";
                    if (_supplierService.IsDuplicate(dbModel))
                    {
                        return Json(new { result = false, Error = "Duplicate Data" }, JsonRequestBehavior.AllowGet);
                    }
                    #endregion

                    //get primary key value
                    dbModel.SupID = new GlobalClass().GetMaxId("SupID", "Supplier");
                    if (dbModel.SupID == "1")
                        dbModel.SupID = "1001";

                    _supplierService.Create(dbModel);

                    decimal supRegID = decimal.Parse(new GlobalClass().GetMaxId("SupRegID", "SupplierRegPrd"));

                    foreach (SupplierRegPrd prd in dbModelPrd)
                    {
                        prd.SupID = dbModel.SupID;
                        prd.SupRegID = supRegID++.ToString();
                        _supplierRegPrdService.Create(prd);
                    }

                    _supplierService.Save();
                    _supplierRegPrdService.Save();

                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult UpdateSupplier(SupplierViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    #region Model update
                    var data = _supplierService.Get(model.SupID);
                    data.RegName = model.RegName;
                    data.RegAdd1 = model.RegAdd1;
                    data.RegAdd2 = model.RegAdd2;
                    data.RegPhone = model.RegPhone;
                    data.RegFax = model.RegFax;
                    data.RegWeb = model.RegWeb;
                    data.RegEmail = model.RegEmail;
                    data.ChkRegOwner = model.ChkRegOwner;
                    data.ChkRegPartner = model.ChkRegPartner;

                    data.Supname = model.Supname;
                    data.TradeAdd1 = model.TradeAdd1;
                    data.TradeAdd2 = model.TradeAdd2;
                    data.TradePhone = model.TradePhone;

                    data.TradeFax = model.TradeFax;
                    data.TradeWeb = model.TradeWeb;
                    data.TradeEmail = model.TradeEmail;
                    data.chkTradeMember = model.chkTradeMember;
                    data.chkTradeDirector = model.chkTradeDirector;

                    data.GenCName = model.GenCName;
                    data.GenCDesig = model.GenCDesig;
                    data.GenCCell = model.GenCCell;
                    data.GenCEmail = model.GenCEmail;

                    data.MngCname = model.MngCname;
                    data.MngCdesig = model.MngCdesig;
                    data.MngCCell = model.MngCCell;
                    data.MngCEmail = model.MngCEmail;

                    data.MgtCName = model.MgtCName;
                    data.MgtCDesig = model.MgtCDesig;
                    data.MgtCCell = model.MgtCCell;
                    data.MgtCEmail = model.MgtCEmail;

                    data.FinCname = model.FinCname;
                    data.FinCDesig = model.FinCDesig;
                    data.FinCCell = model.FinCCell;
                    data.FinCEmail = model.FinCEmail;

                    data.gMargin = model.gMargin;
                    data.gMarginTP = model.gMarginTP;
                    data.gMarginAVG = model.gMarginAVG;
                    data.chkgMarginAP = model.chkgMarginAP;
                    data.sacDays = model.sacDays;
                    data.crDays = model.crDays;
                    data.B2BDays = model.B2BDays;
                    data.SupType = model.SupType;
                    data.asDays = model.asDays;
                    data.chkAC = model.chkAC;
                    data.chkPO = model.chkPO;
                    data.chkCash = model.chkCash;

                    data.Bank = model.Bank;
                    data.BankBR = model.BankBR;
                    data.BankBRCode = model.BankBRCode;
                    data.ACCName = model.ACCName;

                    data.ACCnum = model.ACCnum;
                    data.ACCNB = model.ACCNB;
                    data.ACCtype = model.ACCtype;
                    data.ACCMNB = model.ACCMNB;

                    data.chkSupDay = model.chkSupDay;
                    data.chkSupWeek = model.chkSupWeek;
                    data.chkSupMonth = model.chkSupMonth;
                    data.chkSupAsPer = model.chkSupAsPer;
                    data.DeliveryDays = model.DeliveryDays;
                    data.TransportMode = model.TransportMode;

                    data.chkDamageRep = model.chkDamageRep;
                    data.chkDamageRet = model.chkDamageRet;
                    data.chkSlowRep = model.chkSlowRep;
                    data.chkSlowRet = model.chkSlowRet;
                    data.chkShortRep = model.chkShortRep;
                    data.chkShortRet = model.chkShortRet;
                    data.chkExpireRep = model.chkExpireRep;
                    data.chkExpireRet = model.chkExpireRet;

                    data.InformDay = model.InformDay;
                    data.chkTradeLicence = model.chkTradeLicence;
                    data.chkBSTIdocument = model.chkBSTIdocument;
                    data.chkVATCertificate = model.chkVATCertificate;
                    data.chkTINCertificate = model.chkTINCertificate;
                    data.chkOtherDocument = model.chkOtherDocument;

                    data.chkTypeLocal = model.chkTypeLocal;
                    data.chkTypeForeign = model.chkTypeForeign;
                    data.chkTypeOther = model.chkTypeOther;
                    data.SupCommodity = model.SupCommodity;
                    data.SupArea = model.SupArea;
                    data.SPonTP = model.SPonTP;
                    data.SPonMRP = model.SPonMRP;

                    #endregion

                    if (_supplierService.IsDuplicate(data))
                    {
                        return Json(new { result = false, Error = "Duplicate Data" }, JsonRequestBehavior.AllowGet);
                    }
                    _supplierService.Update(data);

                    // SupplierRegPrd get from supplier list
                    List<SupplierRegPrdViewModel> olist = model.RegPrd;
                    List<SupplierRegPrd> dbModelPrd = new List<SupplierRegPrd>();
                    dbModelPrd = Mapper.Map<List<SupplierRegPrdViewModel>, List<SupplierRegPrd>>(olist);
                    string subID = data.SupID;

                    //remove existing all prd by subID
                    IEnumerable<SupplierRegPrd> removePrd = null;
                    removePrd = _supplierRegPrdService.Gets(subID);

                    foreach (SupplierRegPrd prd in removePrd)
                    {
                        _supplierRegPrdService.Remove(prd);
                    }

                    // now insert new PrdID
                    decimal supRegID = decimal.Parse(new GlobalClass().GetMaxId("SupRegID", "SupplierRegPrd"));

                    foreach (SupplierRegPrd prd in dbModelPrd)
                    {
                        prd.SupID = subID;
                        prd.SupRegID = supRegID++.ToString();
                        _supplierRegPrdService.Create(prd);
                    }

                    _supplierRegPrdService.Save();

                    _supplierService.Save();

                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "Updated" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult DeleteSupplier(SupplierViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var data = _supplierService.Get(model.SupID);
                    _supplierService.Remove(data);
                    _supplierService.Save();

                    IEnumerable<SupplierRegPrd> removePrd = null;
                    removePrd = _supplierRegPrdService.Gets(model.SupID);

                    foreach (SupplierRegPrd prd in removePrd)
                    {
                        _supplierRegPrdService.Remove(prd);
                    }
                    _supplierRegPrdService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult SupplierList()
        {
            IEnumerable<SupplierViewModel> result = null;
            IEnumerable<Supplier> datas = _supplierService.Gets();
            result = Mapper.Map<IEnumerable<Supplier>, IEnumerable<SupplierViewModel>>(datas);

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        public ActionResult FindBySupplierID(string supID)
        {
            SupplierViewModel result = mFindBySupplierID(supID);
            string supId = result.SupID;

            IEnumerable<SupplierRegPrdViewModel> resultPrd = null;
            IEnumerable<SupplierRegPrd> datasPrd = _supplierRegPrdService.Gets(supId);
            resultPrd = Mapper.Map<IEnumerable<SupplierRegPrd>, IEnumerable<SupplierRegPrdViewModel>>(datasPrd);
            result.RegPrd = resultPrd.ToList();

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        private SupplierViewModel mFindBySupplierID(string supID)
        {
            SupplierViewModel result = null;
            Supplier datas = _supplierService.Get(supID);
            result = Mapper.Map<Supplier, SupplierViewModel>(datas);
            return result;
        }
        #endregion

        #region Supplier Merchant Prd

        public ActionResult SupplierMerchanPrd()
        {
            return View();
        }
        [HttpPost]
        public ActionResult CreateSupplierMerchanPrd(SupplierRegPrdViewModel model)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    SupplierRegPrd dbModel = new SupplierRegPrd();
                    dbModel = Mapper.Map<SupplierRegPrdViewModel, SupplierRegPrd>(model);
                    #region duplicate check
                    dbModel.SupRegID = "0";
                    if (_supplierRegPrdService.IsDuplicate(dbModel))
                    {
                        return Json(new { result = false, Error = "Duplicate Data" }, JsonRequestBehavior.AllowGet);
                    }
                    #endregion

                    dbModel.SupRegID = new GlobalClass().GetMaxId("SupRegID", "SupplierRegPrd");

                    _supplierRegPrdService.Create(dbModel);
                    _supplierRegPrdService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult UpdateSupplierMerchanPrd(SupplierRegPrdViewModel model)
        {
            try
            {

                //if (ModelState.IsValid)
                //{
                //    var data = _productService.Get(model.PrdID);
                //    data.PrdName = model.PrdName;
                //    data.FloorID = model.FloorID;
                //    data.GroupID = model.GroupID;
                //    data.GroupName = model.GroupName;
                //    data.VATPrcnt = model.VATPrcnt;
                //    data.DiscPrcnt = model.DiscPrcnt;

                //    if (_productService.IsDuplicate(data))
                //    {
                //        return Json(new { result = false, Error = "Duplicate Data" }, JsonRequestBehavior.AllowGet);
                //    }

                //    _productService.Update(data);
                //    _productService.Save();

                //}
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "Updated" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult DeleteSupplierMerchanPrd(SupplierRegPrdViewModel model)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    var data = _supplierRegPrdService.Get(model.SupRegID);
                    _supplierRegPrdService.Remove(data);
                    _supplierRegPrdService.Save();

                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult SupplierMerchanPrdList(string subID)
        {
            IEnumerable<SupplierRegPrdViewModel> result = null;
            IEnumerable<SupplierRegPrd> datas = _supplierRegPrdService.Gets(subID);
            result = Mapper.Map<IEnumerable<SupplierRegPrd>, IEnumerable<SupplierRegPrdViewModel>>(datas);

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }


        public ActionResult FindBySupplierMerchanPrdID(string supRegID)
        {
            SupplierRegPrdViewModel result = null;
            SupplierRegPrd datas = _supplierRegPrdService.Get(supRegID);
            result = Mapper.Map<SupplierRegPrd, SupplierRegPrdViewModel>(datas); ;

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        #endregion

        #region Style Size

        public ActionResult StyleSize()
        {
            if (!IsPermissionApply("Setup", "StyleSize"))
            {
                return RedirectToAction("Index", "Home");
            }

            List<SupplierViewModel> resultSupplier = null;
            IEnumerable<Supplier> dataSupplier = _supplierService.Gets();
            resultSupplier = Mapper.Map<IEnumerable<Supplier>, IEnumerable<SupplierViewModel>>(dataSupplier).ToList();
            SupplierViewModel obj = new SupplierViewModel();
            obj.SupID = "";
            obj.Supname = "Select";
            resultSupplier.Insert(0, obj);
            ViewBag.SuppliersList = new SelectList(resultSupplier, "SupID", "Supname");

            List<PGroupViewModel> resultGroup = null;
            IEnumerable<PGroup> data = _pGroupService.Gets();
            resultGroup = Mapper.Map<IEnumerable<PGroup>, IEnumerable<PGroupViewModel>>(data).ToList();
            PGroupViewModel objG = new PGroupViewModel();
            objG.GroupID = "";
            objG.GroupName = "Select";
            resultGroup.Insert(0, objG);
            ViewBag.GroupList = new SelectList(resultGroup, "GroupID", "GroupName");

            List<ProductViewModel> resultProduct = null;
            IEnumerable<Product> dataProduct = _productService.Gets();
            resultProduct = Mapper.Map<IEnumerable<Product>, IEnumerable<ProductViewModel>>(dataProduct).ToList();
            ProductViewModel objP = new ProductViewModel();
            objP.PrdID = "";
            objP.PrdName = "Select";
            resultProduct.Insert(0, objP);
            ViewBag.ProductList = new SelectList(resultProduct, "PrdID", "PrdName");

            List<BrandTypeViewModel> resultBrandType = null;
            IEnumerable<BrandType> dataBrandType = _brandTypeService.Gets();
            resultBrandType = Mapper.Map<IEnumerable<BrandType>, IEnumerable<BrandTypeViewModel>>(dataBrandType).ToList();
            BrandTypeViewModel objBT = new BrandTypeViewModel();
            objBT.BTID = "";
            objBT.BTName = "Select";
            resultBrandType.Insert(0, objBT);
            ViewBag.BrandTypeList = new SelectList(resultBrandType, "BTID", "BTName");

            return View();
        }
        public ActionResult CreateStyleSize(StyleSizeViewModel model)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    model.CMPIDX = model.sBarcode + model.Barcode;
                    StyleSize dbModel = new StyleSize();
                    dbModel = Mapper.Map<StyleSizeViewModel, StyleSize>(model);


                    if (dbModel.CPU > dbModel.RPU)
                        return Json(new { result = false, Error = "Sorry, Retail Price less than Cost Price is not allowed!" }, JsonRequestBehavior.AllowGet);
                    if (dbModel.WSP > 0)
                    {
                        if (dbModel.CPU > dbModel.WSP)
                            return Json(new { result = false, Error = "Sorry, Wholesale price less than Cost Price is not allowed!" }, JsonRequestBehavior.AllowGet);

                    }
                    if (dbModel.Barcode.Length == 0)
                        return Json(new { result = false, Error = "Sorry,Empty Prodcut Barcode is not allowed" }, JsonRequestBehavior.AllowGet);

                    string CBTID = string.Concat(dbModel.PrdID, dbModel.BTID);
                    string SSID = new GlobalClass().GetMaxIdByWhereVar("SSID", "StyleSize", "CBTID", CBTID);
                    if (SSID == "1")
                        SSID = "001";
                    dbModel.SSID = SSID;
                    dbModel.CBTID = CBTID;
                    dbModel.CSSID = CBTID + SSID;
                    dbModel.UserID = User.Identity.Name;
                    //dbModel.ENTRYDT = Convert.ToDateTime(DateTime.Now.ToShortDateString());

                    dbModel.ENTRYDT = DateTime.Now;

                    //SupplierViewModel result = mFindBySupplierID(dbModel.SupID);
                    //dbModel.SupName = result.Supname;

                    //PGroupViewModel resultGroupID = mFindByGroupId(dbModel.GroupID);
                    //dbModel.GroupName = resultGroupID.GroupName;

                    //ProductViewModel resultProduct = mFindByProductID(dbModel.PrdID);
                    //dbModel.PrdName = resultProduct.PrdName;

                    //BrandTypeViewModel resultBrandType = mFindByBrandTypeID(dbModel.BTID);
                    //dbModel.BTName = resultBrandType.BTName;

                    dbModel.DisContinued = "0";
                    dbModel.FloorID = "1";
                    dbModel.PrdComm = 0;

                    #region duplicate check
                    //for new item duplicate check  primary key must be zero
                    if (_styleSizeService.IsDuplicate(dbModel))
                    {
                        return Json(new { result = false, Error = "Duplicate Data" }, JsonRequestBehavior.AllowGet);
                    }
                    #endregion

                    _styleSizeService.Create(dbModel);
                    _styleSizeService.Save();
                    _buyCentralService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }
        public ActionResult StyleSizeUpdate(StyleSizeViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var data = _styleSizeService.GetstyleSizeByCMPIDX(model.CMPIDX);
                    data.SSName = model.SSName;

                    if (_styleSizeService.IsDuplicate(data))
                    {
                        return Json(new { result = false, Error = "Duplicate Data" }, JsonRequestBehavior.AllowGet);
                    }
                    //update vat into buycental
                    BuyCentral bc = _buyCentralService.GetObjByBarcode(model.Barcode);
                    if (bc != null)
                       bc.VATPrcnt = model.VATPrcnt;
                    data.CPU = model.CPU;
                    data.RPU = model.RPU;
                    data.VATPrcnt = model.VATPrcnt;
                    data.DiscPrcnt = model.DiscPrcnt;
                    data.Point = model.Point;
                    data.RPP = model.RPP;
                    data.Reorder = model.Reorder;
                    data.MaxOrder = model.MaxOrder;
                    _styleSizeService.Update(data);
                    _styleSizeService.Save();
                    _buyCentralService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "Updated" }, JsonRequestBehavior.AllowGet);
        }
        public ActionResult DeleteStyleSize(string CMPIDX)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var data = _styleSizeService.GetstyleSizeByCMPIDX(CMPIDX);
                    if(data == null)
                        return Json(new { result = false, Error = "Style/Size can't find." }, JsonRequestBehavior.AllowGet);

                    BuyCentral bc = _buyCentralService.GetObjByBarcode(data.Barcode);
                    if(bc != null)
                        return Json(new { result = false, Error = "This Barcode exists in BuyCental table, so can't be deleted." }, JsonRequestBehavior.AllowGet);

                    _styleSizeService.Remove(data);
                    _styleSizeService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult StyleSizeList()
        {
            IEnumerable<StyleSizeViewModel> result = null;
            IEnumerable<StyleSize> datas = _styleSizeService.Gets();
            result = Mapper.Map<IEnumerable<StyleSize>, IEnumerable<StyleSizeViewModel>>(datas);

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        public ActionResult FindByCMPIDX(string cMPIDX)
        {
            StyleSizeViewModel result = null;
            StyleSize datas = _styleSizeService.GetstyleSizeByCMPIDX(cMPIDX);
            result = Mapper.Map<StyleSize, StyleSizeViewModel>(datas); ;

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        public ActionResult FindByBarcode(string barcode)
        {
            StyleSizeViewModel result = null;
            StyleSize datas = _styleSizeService.GetstyleSizeByBarcode(barcode);
            result = Mapper.Map<StyleSize, StyleSizeViewModel>(datas); ;

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        public ActionResult GetstyleSizeBySupID(string supID)
        {
            var result = mStyleSizeGetBySupID(supID);

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        public ActionResult GetstyleSizeByBarCodeAndSupID(string barcode, string supID)
        {
            List<StyleSizeViewModel> result = mStyleSizeGetBySupID(supID).ToList();
            StyleSizeViewModel obj = result.FindAll(m => m.Barcode == barcode).FirstOrDefault();
            if (obj == null)
            {
                return Json(new { result = false, Error = "Style/Size not find with this Barcode." }, JsonRequestBehavior.AllowGet);
            }
            var list = JsonConvert.SerializeObject(new { data = obj }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        private IEnumerable<StyleSizeViewModel> mStyleSizeGetBySupID(string supID)
        {
            IEnumerable<StyleSizeViewModel> result = null;
            IEnumerable<StyleSize> datas = _styleSizeService.GetstyleSizeBySupID(supID);
            result = Mapper.Map<IEnumerable<StyleSize>, IEnumerable<StyleSizeViewModel>>(datas);
            return result;
        }

        public ActionResult GenarateSBarCode(string prdID, string bTID, string pGroupID, string supID)
        {
            string sBarCode = string.Empty;
            string CBTID = string.Concat(prdID, bTID);
            string SSID = new GlobalClass().GetMaxIdByWhereVar("SSID", "StyleSize", "CBTID", CBTID);
            if (SSID == "1") SSID = "001";
            sBarCode = supID + pGroupID + CBTID + SSID;
            var list = JsonConvert.SerializeObject(new { data = sBarCode }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        public ActionResult StyleSizeFindByPrdIdBTId(string PrdID, string BTID)
        {
            List<StyleSize> result = _styleSizeService.FindByPrdIdBTId(PrdID, BTID).ToList();

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                          new JsonSerializerSettings()
                          {
                              ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                          });
            return Content(list, "application/json");
        }

        public ActionResult StyleSizeGetByCriteria(string SupID, string GroupID, string PrdID, string BTID)
        {
            DataTable dt = _styleSizeService.StyleSizeGetByCriteria(SupID, GroupID, PrdID, BTID);
            List<StyleSize> ssList= new List<StyleSize>();
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    StyleSize ss= new StyleSize();
                    ss.SSID = dr["SSID"].ToString();
                    ss.SSName = dr["SSName"].ToString();
                    ssList.Add(ss);
                }
            }

            var list = JsonConvert.SerializeObject(new { data = ssList }, Formatting.None,
                         new JsonSerializerSettings()
                         {
                             ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                         });
            return Content(list, "application/json");
        }
        #endregion

        #region CustomerMst
        public ActionResult Customers()
        {
            if (!IsPermissionApply("Setup", "Customers"))
            {
                return RedirectToAction("Index", "Home");
            }

            List<CustomerCategoryOption> customerCategoryOption = new List<CustomerCategoryOption>() { 
              new CustomerCategoryOption{Catgry = "PLATINUM"},
              new CustomerCategoryOption{Catgry = "SILVER"},
              new CustomerCategoryOption{Catgry = "GOLD"}
            };

            ViewBag.CustomerCategory = new SelectList(customerCategoryOption, "Catgry", "Catgry");
            return View();
        }
        [HttpPost]
        public ActionResult CreateCustomer(CustomerMstViewModel model)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    CustomerMst dbModel = new CustomerMst();
                    dbModel = Mapper.Map<CustomerMstViewModel, CustomerMst>(model);

                    if (dbModel.BirthDt == null)
                        dbModel.BirthDt = DateTime.Now.AddYears(-50);
                    else
                        dbModel.BirthDt = model.BirthDt;

                    if (model.DOE == null)
                        dbModel.DOE = DateTime.Now;
                    else
                        dbModel.DOE = model.DOE;

                    #region duplicate check
                    //for new item duplicate check  primary key must be zero
                    string ShopID = GetLogedInInfo().ShopID;
                    dbModel.PrvCusID = new GlobalClass().GetMaxIdWithPrfix("PrvCusID", "5", "00001", "CustomerMst", ShopID);
                    if (_customerMstService.IsDuplicate(dbModel))
                    {
                        return Json(new { result = false, Error = "Duplicate Data" }, JsonRequestBehavior.AllowGet);
                    }
                    #endregion
                    _customerMstService.Create(dbModel);
                    _customerMstService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult UpdateCustomer(CustomerMstViewModel model)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    var data = _customerMstService.Get(model.PrvCusID);
                    data.CusName = model.CusName;
                    data.Catgry = model.Catgry;
                    data.FName = model.FName;
                    data.MName = model.MName;
                    data.LName = model.LName;
                    data.CusName = model.CusName;
                    data.Address = model.Address;
                    data.Phone = model.Phone;
                    data.Email = model.Email;
                    data.Profession = model.Profession;
                    if (model.BirthDt == null)
                        data.BirthDt = DateTime.Now.AddYears(-50);
                    else
                      data.BirthDt = model.BirthDt;

                    if (model.DOE == null)
                        data.DOE = DateTime.Now;
                    else
                        data.DOE = model.DOE;

                    data.DiscAllowed = model.DiscAllowed;
                    data.IsCreditAllowed = model.IsCreditAllowed;
                    if (_customerMstService.IsDuplicate(data))
                    {
                        return Json(new { result = false, Error = "Duplicate Data" }, JsonRequestBehavior.AllowGet);
                    }

                    _customerMstService.Update(data);
                    _customerMstService.Save();

                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "Updated" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult DeleteCustomer(CustomerMstViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var data = _customerMstService.Get(model.PrvCusID);
                    _customerMstService.Remove(data);
                    _customerMstService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult CustomerList()
        {
            DataTable dt = _customerMstService.GetByShopID(GetLogedInInfo().ShopID);

            var list = JsonConvert.SerializeObject(new { data = dt }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        public ActionResult FindByCustomerID(string customerID)
        {
            CustomerMstViewModel result = mFindByCustomerID(customerID);

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        private CustomerMstViewModel mFindByCustomerID(string customerID)
        {
            CustomerMstViewModel result = null;
            CustomerMst datas = _customerMstService.Get(customerID);
            result = Mapper.Map<CustomerMst, CustomerMstViewModel>(datas);
            return result;
        }

        public ActionResult GetAutoCustomerID()
        {
            string PrvCusID = new GlobalClass().GetMaxId("PrvCusID", "CustomerMst");
            if (PrvCusID == "1") PrvCusID = "0000001";
            var list = JsonConvert.SerializeObject(new { data = PrvCusID }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        #endregion

        #region Shop List
        public ActionResult ShopList()
        {
            if (!IsPermissionApply("Setup", "ShopList"))
            {
                return RedirectToAction("Index", "Home");
            }

            return View();
        }
        [HttpPost]
        public ActionResult CreateShopList(ShopListViewModel model)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    ShopList dbModel = new ShopList();
                    dbModel = Mapper.Map<ShopListViewModel, ShopList>(model);

                    #region duplicate check
                    if (_shopListService.IsDuplicate(dbModel))
                    {
                        return Json(new { result = false, Error = "Duplicate Data" }, JsonRequestBehavior.AllowGet);
                    }
                    #endregion
                    _shopListService.Create(dbModel);
                    _shopListService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }

            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult UpdateShopList(ShopListViewModel model)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    var data = _shopListService.Get(model.ShopID);
                    data.ShopName = model.ShopName;
                    data.Phone = model.Phone;
                    data.Contact = model.Contact;
                    data.District = model.District;
                    data.Post = model.Post;
                    data.Pstation = model.Pstation;
                    data.VATDisabled = model.VATDisabled;
                    data.VillAreaRoad = model.VillAreaRoad;
                    data.VatRegNo = model.VatRegNo;
                    _shopListService.Update(data);
                    _shopListService.Save();

                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "Updated" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult DeleteShopList(ShopListViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var data = _shopListService.Get(model.ShopID);
                    _shopListService.Remove(data);
                    _shopListService.Save();

                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetShopList()
        {
            IEnumerable<ShopListViewModel> result = null;
            IEnumerable<ShopList> datas = _shopListService.Gets();
            result = Mapper.Map<IEnumerable<ShopList>, IEnumerable<ShopListViewModel>>(datas);

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        public ActionResult ShopListGetByShopID(string ShopID)
        {
            ShopList result = _shopListService.Get(ShopID);

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        public ActionResult ShopListGetByShopName(string ShopName)
        {
            ShopList result = _shopListService.GetByShopName(ShopName);

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }


        #endregion

        #region Menu Distribution

        public ActionResult MenuDistribution()
        {
            if (!IsPermissionApply("Setup", "MenuDistribution"))
            {
                return RedirectToAction("Index", "Home");
            }


            string _selectQuery = @"select UserId, UserName
                                from dbo.UserProfile";
            SQLDALService dal = new SQLDALService();
            DataTable dt = dal.Select(_selectQuery).Data;
            List<UserProfile> user = new List<UserProfile>();
            foreach (DataRow dr in dt.Rows)
            {
                UserProfile up = new UserProfile();
                up.UserId = int.Parse(dr["UserId"].ToString());
                up.UserName = dr["UserName"].ToString();
                user.Add(up);
            }
            ViewBag.Users = new SelectList(user, "UserName", "UserName");

            IEnumerable<MenuURLViewModel> result = null;
            IEnumerable<MenuURL> datas = _menuURLService.Gets();
            result = Mapper.Map<IEnumerable<MenuURL>, IEnumerable<MenuURLViewModel>>(datas);

            ViewBag.ParentMenu = result.OrderBy(a => a.Serial).Where(m => m.ParentID == 0).ToList();
            ViewBag.ChildMenu = result.OrderBy(a => a.Serial).Where(m => m.ParentID > 0).ToList();

            return View();
        }
        public ActionResult MenuURLList()
        {
            IEnumerable<MenuURLViewModel> result = null;
            IEnumerable<MenuURL> datas = _menuURLService.Gets();
            result = Mapper.Map<IEnumerable<MenuURL>, IEnumerable<MenuURLViewModel>>(datas);
            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }
        public ActionResult MenuURLByMenuId(int menuId)
        {
            MenuURLViewModel result = null;
            MenuURL datas = _menuURLService.Get(menuId);
            result = Mapper.Map<MenuURL, MenuURLViewModel>(datas);

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }
        public ActionResult MenuURLGetByParentID(int parentID)
        {
            IEnumerable<MenuURLViewModel> result = null;
            IEnumerable<MenuURL> datas = _menuURLService.GetByParentID(parentID);
            result = Mapper.Map<IEnumerable<MenuURL>, IEnumerable<MenuURLViewModel>>(datas);

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }
        public ActionResult MenuURLGetByUserID(string userName)
        {
            IEnumerable<MenuURLViewModel> result = null;
            IEnumerable<MenuURL> datas = _menuURLService.GetByUserID(userName);
            result = Mapper.Map<IEnumerable<MenuURL>, IEnumerable<MenuURLViewModel>>(datas);

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }
        public ActionResult UsersMenu()
        {
            return View();
        }
        [HttpPost]
        public ActionResult CreateUsersMenu(UsersMenuViewModel model)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    UsersMenu dbModel = new UsersMenu();
                    dbModel = Mapper.Map<UsersMenuViewModel, UsersMenu>(model);

                    #region duplicate check
                    //for new item duplicate check  primary key must be zero
                    dbModel.UMenuId = 0;
                    if (_usersMenusService.IsDuplicate(dbModel))
                    {
                        return Json(new { result = false, Error = "Duplicate Data" }, JsonRequestBehavior.AllowGet);
                    }
                    #endregion

                    //get primary key value
                    dbModel.UMenuId = int.Parse(new GlobalClass().GetMaxId("UMenuId", "UsersMenus"));
                    _usersMenusService.Create(dbModel);
                    _usersMenusService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult UpdateUsersMenu(UsersMenuViewModel model)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    var data = _usersMenusService.Get(model.UMenuId);
                    //data.GroupName = model.GroupName;
                    //data.FloorID = model.FloorID;
                    //data.VATPrcnt = model.VATPrcnt;
                    //data.DiscPrcnt = model.DiscPrcnt;

                    if (_usersMenusService.IsDuplicate(data))
                    {
                        return Json(new { result = false, Error = "Duplicate Data" }, JsonRequestBehavior.AllowGet);
                    }

                    _usersMenusService.Update(data);
                    _usersMenusService.Save();

                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "Updated" }, JsonRequestBehavior.AllowGet);
        }
        public ActionResult SaveUserMenu(string MenuName, string userName)
        {
            try
            {
                //first delete old user menu
                IEnumerable<UsersMenu> datas = _usersMenusService.GetByUserID(userName);
                foreach (UsersMenu contesxt in datas)
                {
                    _usersMenusService.Remove(contesxt);
                }
                _usersMenusService.Save();

                // then insert new
                string[] menu = MenuName.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
                decimal UMenuId = decimal.Parse(new GlobalClass().GetMaxId("UMenuId", "UsersMenus"));

                // parentList
                List<MenuURL> dbMenuURL = _menuURLService.Gets().ToList();
                List<MenuURL> dbModelParentNew = new List<MenuURL>();
                foreach (var s in menu)
                {
                    UsersMenu model = new UsersMenu();
                    model.MenuId = Convert.ToInt32(s);
                    model.UserId = userName;
                    model.UMenuId = UMenuId++;
                    _usersMenusService.Create(model);

                    MenuURL isFound = dbMenuURL.FirstOrDefault(m => m.MenuId == model.MenuId);
                    if (isFound != null)
                    {
                        int? paID = isFound.ParentID;

                        var isFoundPa = dbModelParentNew.FirstOrDefault(m => m.MenuId == paID);
                        if (isFoundPa == null)
                        {
                            dbModelParentNew.Add(dbMenuURL.Find(m => m.MenuId == paID));
                        }
                    }
                }
                _usersMenusService.Save();
                foreach (MenuURL rul in dbModelParentNew)
                {
                    UsersMenu model = new UsersMenu();
                    model.MenuId = Convert.ToInt32(rul.MenuId);
                    model.UserId = userName;
                    model.UMenuId = UMenuId++;
                    _usersMenusService.Create(model);
                }
                _usersMenusService.Save();

                if (userName == User.Identity.Name)
                {
                    Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.SessionMenu] = null;
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]

        public ActionResult DeleteUsersMenu(UsersMenuViewModel model)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    var data = _usersMenusService.Get(model.UMenuId);
                    _usersMenusService.Remove(data);
                    _usersMenusService.Save();

                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }
        public ActionResult UsersMenuList()
        {
            IEnumerable<UsersMenuViewModel> result = null;
            IEnumerable<UsersMenu> datas = _usersMenusService.Gets();
            result = Mapper.Map<IEnumerable<UsersMenu>, IEnumerable<UsersMenuViewModel>>(datas);
            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }
        public ActionResult UsersMenuByUserID(string userName)
        {
            IEnumerable<MenuURLViewModel> result = null;
            IEnumerable<MenuURL> datas = _menuURLService.GetByUserID(userName);
            result = Mapper.Map<IEnumerable<MenuURL>, IEnumerable<MenuURLViewModel>>(datas);

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );
            return Content(list, "application/json");
        }

        #endregion

        #region BuyAndGet

        public ActionResult BuyGet()
        {
            if (!IsPermissionApply("Setup", "BuyGet"))
            {
                return RedirectToAction("Index", "Home");
            }

            return View();
        }

        private List<BuyAndGet> GetBuyList()
        {
            List<BuyAndGet> buyAndGet = new List<BuyAndGet>();
            if (Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.buyData] != null)
            {
                buyAndGet = Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.buyData] as List<BuyAndGet>;
            }
            return buyAndGet;
        }

        private List<BuyAndGet> GetFreeList()
        {
            List<BuyAndGet> buyAndGet = new List<BuyAndGet>();
            if (Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.freeData] != null)
            {
                buyAndGet = Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.freeData] as List<BuyAndGet>;
            }
            return buyAndGet;
        }

        public ActionResult GetBuyGetTempExitsList(string BarCode, DateTime sDate, DateTime eDate)
        {
            try
            {
                List<BuyAndGet> findExists = _buyAndGetService.ExistswithinDate(Convert.ToDateTime(sDate),
                    Convert.ToDateTime(eDate));
                findExists = findExists.FindAll(m => m.BarCode == BarCode);
                string msg = "";

                var distinctItems = findExists
                    .GroupBy(x => x.BuyGetNo)
                    .Select(x => x.First());

                var list = JsonConvert.SerializeObject(new { data = distinctItems }, Formatting.None,
                    new JsonSerializerSettings()
                    {
                        ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                    });

                return Content(list, "application/json");

            }
            catch (Exception ex)
            {
                return Json(new {result = false, Error = ex.Message}, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult CreateBuyList(BuyAndGet model)
        {
            try
            {
                List<BuyAndGet> findExists = _buyAndGetService.ExistswithinDate(Convert.ToDateTime(model.StartDate), Convert.ToDateTime(model.EndDate));
                findExists = findExists.FindAll(m => m.BarCode == model.BarCode);
                if (findExists.Count>0)
                {
                    var distinctItems = findExists
                  .GroupBy(x => x.BuyGetNo)
                  .Select(x => x.First());
                    var list = JsonConvert.SerializeObject(new { result = false, data = distinctItems }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

                    return Content(list, "application/json");
                }

                List<BuyAndGet> buylist = GetBuyList();
                BuyAndGet one = buylist.Find(m => m.BarCode == model.BarCode);
                if (one != null)
                {
                    model.Qty = model.Qty + one.Qty;
                    buylist.Remove(one);
                    buylist.Add(model);
                }
                else
                {
                    buylist.Add(model);
                }
                Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.buyData] = buylist;
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }

            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult CreateFreeList(BuyAndGet model)
        {
            try
            {
                List<BuyAndGet> findExists = _buyAndGetService.ExistswithinDate(Convert.ToDateTime(model.StartDate), Convert.ToDateTime(model.EndDate));
                findExists = findExists.FindAll(m => m.BarCode == model.BarCode);
                if (findExists.Count > 0)
                {
                    return Json(new { result = false }, JsonRequestBehavior.AllowGet);
                }

                List<BuyAndGet> freelist = GetFreeList();
                BuyAndGet one = freelist.Find(m => m.BarCode == model.BarCode);
                if (one != null)
                {
                    model.Qty = model.Qty + one.Qty;
                    freelist.Remove(one);
                    freelist.Add(model);
                }
                else
                {
                    freelist.Add(model);
                }
                Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.freeData] = freelist;
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }

            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetBuyTempList()
        {
            List<BuyAndGet> buyAndGet = GetBuyList();

            var list = JsonConvert.SerializeObject(new { data = buyAndGet }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        public ActionResult GetFreeTempList()
        {
            List<BuyAndGet> buyAndGet = GetFreeList();

            var list = JsonConvert.SerializeObject(new { data = buyAndGet }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        public ActionResult BuyDeleteTemp(string BarCode)
        {
            List<BuyAndGet> buyAndGet = GetBuyList();
            BuyAndGet one = buyAndGet.Find(m => m.BarCode == BarCode);
            buyAndGet.Remove(one);
            Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.buyData] = buyAndGet;

            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }
        public ActionResult FreeDeleteTemp(string BarCode)
        {
            List<BuyAndGet> buyAndGet = GetFreeList();
            BuyAndGet one = buyAndGet.Find(m => m.BarCode == BarCode);
            buyAndGet.Remove(one);
            Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.freeData] = buyAndGet;
            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult BuyAndGetSave(string EffectiveDt, string ExpireDt)
        {
            string BuyGetNo = "";
            try
            {
                DateTime ef = DateTime.Now;
                DateTime exp = DateTime.Now;
                DateTime.TryParse(EffectiveDt, out ef);
                DateTime.TryParse(ExpireDt, out exp);

                BuyGetNo = new GlobalClass().GetMaxIdWithPrfix("BuyGetNo", "6", "000001", "BuyAndGet", "BG");

                List<BuyAndGet> buy = GetBuyList();
                foreach (BuyAndGet b in buy)
                {
                    b.BuyGetNo = BuyGetNo;
                    b.StartDate = ef;
                    b.EndDate = exp;
                    b.IsFree = "Buy";
                    b.UserId = User.Identity.Name;
                    b.CreateDate = DateTime.Now;
                    b.UpdateDate = DateTime.Now;
                    _buyAndGetService.Create(b);
                }
                Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.buyData] = null;

                List<BuyAndGet> Get = GetFreeList();
                foreach (BuyAndGet b in Get)
                {
                    b.BuyGetNo = BuyGetNo;
                    b.StartDate = ef;
                    b.EndDate = exp;
                    b.IsFree = "Free";
                    b.UserId = User.Identity.Name;
                    b.CreateDate = DateTime.Now;
                    b.UpdateDate = DateTime.Now;
                    _buyAndGetService.Create(b);
                }
                Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.freeData] = null;

                _buyAndGetService.Save();
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message.ToString() }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, buyGetNo = BuyGetNo }, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region == Package Setup ====

        public ActionResult Package()
        {
            if (!IsPermissionApply("Setup", "Package"))
            {
                return RedirectToAction("Index", "Home");
            }

            return View();
        }

        private List<Package> GetPackageTemp()
        {
            List<Package> packages = new List<Package>();
            if (Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.tempPackage] != null)
            {
                packages = Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.tempPackage] as List<Package>;
            }
            return packages;
        }

        public ActionResult CreatePackageTemp(Package model)
        {
            try
            {
                List<Package> packages = GetPackageTemp();
                Package one = packages.Find(m => m.BarCode == model.BarCode);
                if (one != null)
                {
                    model.Qty = model.Qty + one.Qty;
                    model.PckRPU = 0;
                }
                else
                {
                    model.PckRPU = 0;
                    packages.Add(model);
                }

                Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.tempPackage] = packages;
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }

            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }

        private void updatePackageTempList()
        {
            List<Package> packages = GetPackageTemp();
            foreach (Package p in packages)
            {
                p.PckRPU = 0;
            }
            Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.tempPackage] = packages;
        }

        public ActionResult PackageTempDelete(string BarCode)
        {
            try
            {
                List<Package> packages = GetPackageTemp();
                Package one = packages.Find(m => m.BarCode == BarCode);
                packages.Remove(one);
                updatePackageTempList();

                return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult GetPackageTempList()
        {
            try
            {
                List<Package> packages = GetPackageTemp();

                var list = JsonConvert.SerializeObject(new { data = packages }, Formatting.None,
                            new JsonSerializerSettings()
                            {
                                ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                            });

                return Content(list, "application/json");
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult GetPackageByPackageID(string PackageID)
        {
            try
            {
                List<Package> packages = _packageService.GetActiveByCurrentDt(DateTime.Now);

                Package pp = packages.Find(m => m.PackageNo == PackageID);

                var list = JsonConvert.SerializeObject(new { data = pp }, Formatting.None,
                            new JsonSerializerSettings()
                            {
                                ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                            });

                return Content(list, "application/json");
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult PackageRateCalculation(string TotalRPU, string PackagePrice)
        {
            try
            {
                decimal temp = 0;
                decimal.TryParse(TotalRPU, out temp);
                decimal totalRPU = temp;
                decimal.TryParse(PackagePrice, out temp);
                decimal packagePrice = temp;
                decimal diff = 0;
                bool IsPriceLess = true;
                if (totalRPU > packagePrice)
                    diff = totalRPU - packagePrice;
                else
                {
                    diff = packagePrice - totalRPU;
                    IsPriceLess = false;
                }
                decimal totalPrice = 0;
                decimal diffPec = (diff * 100) / totalRPU;
                List<Package> packages = GetPackageTemp();
                if (IsPriceLess)
                {
                    foreach (Package p in packages)
                    {
                        decimal RPU = Convert.ToDecimal(p.RPU);
                        decimal PckPrice = RPU - (diffPec * RPU) / 100;
                        p.PckRPU = decimal.Round(PckPrice);
                        totalPrice += decimal.Round(PckPrice) * Convert.ToDecimal(p.Qty);
                    }
                }
                else
                {
                    foreach (Package p in packages)
                    {
                        decimal RPU = Convert.ToDecimal(p.RPU);
                        decimal PckPrice = RPU + (diffPec * RPU) / 100;
                        p.PckRPU = decimal.Round(PckPrice);
                    }
                }

                // after divide the package price among the items if divie price is less or greater than the package price
                // then adjust the Item package price

                if (totalPrice > packagePrice)
                {
                    packages = packages.OrderBy(o => o.Qty).ToList();
                    Package p = packages.FirstOrDefault();
                    decimal qty = Convert.ToDecimal(p.Qty);
                    decimal PckPrice = Convert.ToDecimal(p.PckRPU);
                    decimal ownTotalPrice = qty * PckPrice;
                    decimal othersContirb = totalPrice - ownTotalPrice;
                    decimal ownToGive = packagePrice - othersContirb;
                    decimal ownRPU = Math.Round(ownToGive / qty,2);

                    foreach (Package pc in packages)
                    {
                        if (pc.BarCode == p.BarCode)
                        {
                            pc.PckRPU = ownRPU;
                        }
                    }
                }
                if (totalPrice < packagePrice)
                {
                    packages = packages.OrderBy(o => o.Qty).ToList();
                    Package p = packages.FirstOrDefault();
                    decimal qty = Convert.ToDecimal(p.Qty);
                    decimal PckPrice = Convert.ToDecimal(p.PckRPU);
                    decimal ownTotalPrice = qty * PckPrice;
                    decimal othersContirb = totalPrice - ownTotalPrice;
                    decimal ownToGive = packagePrice - othersContirb;
                    decimal ownRPU = Math.Round(ownToGive / qty,2);

                    foreach (Package pc in packages)
                    {
                        if (pc.BarCode == p.BarCode)
                        {
                            pc.PckRPU = ownRPU;
                        }
                    }
                }

                Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.tempPackage] = packages;
                return Json(new { result = true, Error = "" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult PackageInsertFromTemp(string PackageQty, string EffectiveDt, string ExpireDt, string PackagePrice, string PackageName)
        {
            string PackageNo = "";
            try
            {
                DateTime ef = DateTime.Now;
                DateTime exp = DateTime.Now;
                DateTime.TryParse(EffectiveDt, out ef);
                DateTime.TryParse(ExpireDt, out exp);

                PackageNo = new GlobalClass().GetMaxIdWithPrfix("PackageNo", "9", "000000001", "Package", "P");

                List<Package> packages = GetPackageTemp();
                decimal maxVATprcen = 0;
                var item = packages.MaxBy(x => x.VATPrcen);
                maxVATprcen = Convert.ToDecimal(item.VATPrcen);
                foreach (Package b in packages)
                {
                    if (b.PckRPU == 0)
                    {
                        return Json(new { result = false, Error = "Package Price yet not calculated" }, JsonRequestBehavior.AllowGet);
                    }
                    b.VATPrcen = maxVATprcen;
                    b.PQty = Convert.ToDecimal(PackageQty);
                    b.balPQty = b.PQty;
                    b.PackagePrice = Convert.ToDecimal(PackagePrice);
                    b.PName = PackageName;
                    b.PackageNo = PackageNo;
                    b.StartDate = ef;
                    b.EndDate = exp;
                    b.UserId = User.Identity.Name;
                    b.CreateDate = DateTime.Now;
                    _packageService.Create(b);
                }
                Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.tempPackage] = null;
                _packageService.Save();
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message.ToString() }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, packageNo = PackageNo }, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region ==== Package Issue =====

        public ActionResult PackageIssue()
        {
            if (!IsPermissionApply("Setup", "PackageIssue"))
            {
                return RedirectToAction("Index", "Home");
            }

            ShopList resultShop = null;
            List<ShopList> dataShop = _shopListService.Gets().ToList();
            resultShop = dataShop.Find(c => c.ShopID == "9999");
            dataShop.Remove(resultShop);
            List<ShopList> newList = new List<ShopList>();
            ShopList ss = new ShopList();
            ss.ShopID = "";
            ss.ShopName = "Select";
            newList.Add(ss);
            foreach (ShopList sl in dataShop)
            {
                ShopList s = new ShopList();
                s.ShopID = sl.ShopID;
                s.ShopName = sl.ShopID + "-" + sl.ShopName;
                newList.Add(s);
            }
            ViewBag.shopList = new SelectList(newList, "ShopID", "ShopName");

            List<Package> packages = _packageService.GetActiveByCurrentDt(DateTime.Now);
            List<Package> result = packages.GroupBy(t => t.PackageNo)
                   .Select(grp => grp.First())
                   .ToList();
            if (result.Count > 0)
            {
                Package a = new Package();
                a.PackageNo = "";
                a.PName = "Select";
                result.Insert(0, a);
            }

            ViewBag.PackageList = new SelectList(result, "PackageNo", "PName");
            return View();
        }

        private List<PackageIssueDetail> GetTempPackageIssue()
        {
            List<PackageIssueDetail> packages = new List<PackageIssueDetail>();
            if (Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.tempPackageIssue] != null)
            {
                packages = Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.tempPackageIssue] as List<PackageIssueDetail>;
            }
            return packages;
        }

        public ActionResult GetPackageByPackageNo(string PackageNo)
        {
            List<Package> packages = _packageService.Gets(PackageNo).ToList();

            var list = JsonConvert.SerializeObject(new { data = packages }, Formatting.None,
                            new JsonSerializerSettings()
                            {
                                ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                            });

            return Content(list, "application/json");
        }

        public ActionResult GetPackageBalance(string PackageNo)
        {
            try
            {
                List<Package> pack = _packageService.Gets(PackageNo).ToList();
                Package result = pack.GroupBy(t => t.PackageNo)
                       .Select(grp => grp.First())
                       .ToList().FirstOrDefault();

                decimal Price = Convert.ToDecimal(pack.FirstOrDefault().PackagePrice); // package price
                decimal Balance = Convert.ToDecimal(result.balPQty); // package Qty
                decimal tempQty = 0;
                List<PackageIssueDetail> tempIssues = GetTempPackageIssue();
                tempIssues = tempIssues.FindAll(m => m.PackageNo == PackageNo);
                tempQty = Convert.ToDecimal(tempIssues.Sum(m => m.PQty));

                Balance = Balance - tempQty; // packageQty - issueQty

                string startDate = Convert.ToDateTime(result.StartDate).ToShortDateString();
                string endDate = Convert.ToDateTime(result.EndDate).ToShortDateString();

                return Json(new { result = true, Balance = Balance, Price = Price, startDate = startDate, endDate = endDate }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult CreatePackageIssueTemp(PackageIssueDetail model)
        {
            try
            {
                List<PackageIssueDetail> packages = GetTempPackageIssue();
                PackageIssueDetail one = packages.Find(m => m.PackageNo == model.PackageNo && m.ShopID == model.ShopID);
                if (one != null)
                {
                    model.PQty = model.PQty + one.PQty;
                    packages.Remove(one);
                    packages.Add(model);
                }
                else
                {
                    model.RecvUserId = "";
                    packages.Add(model);
                }
                Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.tempPackageIssue] = packages;
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }

            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult PackageIssueTempDelete(string PackageNo, string ShopID)
        {
            try
            {
                List<PackageIssueDetail> packages = GetTempPackageIssue();
                PackageIssueDetail one = packages.Find(m => m.PackageNo == PackageNo && m.ShopID == ShopID);
                packages.Remove(one);
                Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.tempPackageIssue] = packages;

                return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult GetPackageIssueTempList(string ShopID)
        {
            try
            {
                List<PackageIssueDetail> packages = GetTempPackageIssue();
                packages = packages.FindAll(m => m.ShopID == ShopID);

                var list = JsonConvert.SerializeObject(new { data = packages }, Formatting.None,
                            new JsonSerializerSettings()
                            {
                                ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                            });

                return Content(list, "application/json");
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult PackageIssueInsert(string ShopID)
        {
            string PackageIssueNo = "";
            try
            {
                //get form temp by shopId
                List<PackageIssueDetail> packages = GetTempPackageIssue();
                List<PackageIssueDetail> packagesIssues = packages.FindAll(m => m.ShopID == ShopID);
                List<string> packagesNo = new List<string>();
                //insert into packageIssueTable

                PackageIssueNo = new GlobalClass().GetMaxIdWithPrfix("PIssueNo", "6", "000001", "PackageIssueDetail", "PI" + ShopID);
                foreach (PackageIssueDetail pi in packagesIssues)
                {
                    pi.PIssueNo = PackageIssueNo;
                    pi.UserId = User.Identity.Name;
                    pi.CreateDate = DateTime.Now;
                    _pckPackageIssueService.Create(pi);

                    //reduce PQty from Package
                    List<Package> packUpdate = _packageService.Gets(pi.PackageNo).ToList();
                    foreach (var Package in packUpdate)
                    {
                        Package.balPQty = Package.balPQty - pi.PQty;
                        _packageService.Update(Package);
                    }
                }

                //foreach (PackageIssueDetail pi in packagesIssues)
                //{
                //    PackageIssue pack = _pckPackageIssue.GetByPackageNo(pi.PackageNo).FirstOrDefault();
                //    if (pack != null)
                //    {
                //        pack.PQty += pi.PQty;
                //        pack.balPQty += pi.PQty;
                //        pack.PIssueNo = pi.PIssueNo;
                //        pack.CreateDate = pi.CreateDate;
                //    }
                //    else
                //    {
                //        PackageIssue p = new PackageIssue();
                //        p.PQty = pi.PQty;
                //        p.balPQty = pi.PQty;
                //        p.PIssueNo = pi.PIssueNo;
                //        p.CreateDate = pi.CreateDate;
                //        p.PackageName = pi.PackageName;
                //        p.PackageNo = pi.PackageNo;
                //        p.PackagePrice = pi.PackagePrice;
                //        p.RecvUserId = "";
                //        p.ShopID = pi.ShopID;
                //        p.UserId = User.Identity.Name;
                //        p.sPQty = 0;
                //        p.CreateDate = DateTime.Now;
                //        _pckPackageIssue.Create(p);
                //    }
                //}

                _pckPackageIssueService.Save();
                _packageService.Save();
                //_pckPackageIssue.Save();

                //update temp
                packages.RemoveAll(m => m.ShopID == ShopID);
                Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.tempPackageIssue] = packages;

                return Json(new { result = true, PackageIssueNo = PackageIssueNo }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }

        }

        #endregion

        #region ====Discount Circular ====

        public ActionResult DiscountCircular()
        {
            if (!IsPermissionApply("Setup", "DiscountCircular"))
            {
                return RedirectToAction("Index", "Home");
            }

            return View();
        }
        private List<CircularDiscountDetail> GetCircDiscTemp()
        {
            List<CircularDiscountDetail> cirdisc = new List<CircularDiscountDetail>();
            if (Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.tempDisCircularDetails] != null)
            {
                cirdisc = Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.tempDisCircularDetails] as List<CircularDiscountDetail>;
            }
            return cirdisc;
        }

        public ActionResult CreateCircDiscTemp(CircularDiscountDetail model)
        {
            try
            {
                List<CircularDiscountDetail> cirdisc = GetCircDiscTemp();
                CircularDiscountDetail one = cirdisc.Find(m => m.BarCode == model.BarCode);
                if (one != null)
                {
                    return Json(new { result = false, Error = "BarCode already exists in the list." }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    cirdisc.Add(model);
                }

                Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.tempDisCircularDetails] = cirdisc;
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }

            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult CircDiscTempDelete(string BarCode)
        {
            try
            {
                List<CircularDiscountDetail> cirdisc = GetCircDiscTemp();
                CircularDiscountDetail one = cirdisc.Find(m => m.BarCode == BarCode);
                cirdisc.Remove(one);
                return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult GetCircDiscTempList()
        {
            try
            {
                List<CircularDiscountDetail> cirdisc = GetCircDiscTemp();

                var list = JsonConvert.SerializeObject(new { data = cirdisc }, Formatting.None,
                            new JsonSerializerSettings()
                            {
                                ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                            });

                return Content(list, "application/json");
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult CircDiscInsertFromTemp(string EffectiveDt, string ExpireDt, string DCName)
        {
            string CDNo = "";
            try
            {
                DateTime ef = DateTime.Now;
                DateTime exp = DateTime.Now;
                DateTime.TryParse(EffectiveDt, out ef);
                DateTime.TryParse(ExpireDt, out exp);

                CDNo = new GlobalClass().GetMaxIdWithPrfix("CDNo", "9", "000000001", "CircularDiscount", "CD");

                List<CircularDiscountDetail> cirdisc = GetCircDiscTemp();
                foreach (CircularDiscountDetail b in cirdisc)
                {
                    if (b.DRPU == 0)
                    {
                        return Json(new { result = false, Error = "Discount Price yet not calculated" }, JsonRequestBehavior.AllowGet);
                    }
                    b.CDNo = CDNo;
                    _circularDiscountDetailService.Create(b);
                }

                CircularDiscount cd = new CircularDiscount();
                cd.CDNo = CDNo;
                cd.CDName = DCName;
                cd.EffectiveDate = ef;
                cd.ExpireDate = exp;
                cd.CreateDate = DateTime.Now;
                cd.UserId = User.Identity.Name;
                _circularDiscountService.Create(cd);
                _circularDiscountService.Save();

                _circularDiscountDetailService.Save();
                Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.tempDisCircularDetails] = null;
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message.ToString() }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, CDNo = CDNo }, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region === Price Changed Circular ===

        public ActionResult PriceChangedCircular()
        {
            if (!IsPermissionApply("Setup", "PriceChangedCircular"))
            {
                return RedirectToAction("Index", "Home");
            }

            return View();
        }

        private List<CircularPriceChangedDetail> GetPriceCngTemp()
        {
            List<CircularPriceChangedDetail> cirdisc = new List<CircularPriceChangedDetail>();
            if (Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.tempPriceCngDetails] != null)
            {
                cirdisc = Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.tempPriceCngDetails] as List<CircularPriceChangedDetail>;
            }
            return cirdisc;
        }

        public ActionResult CreatePriceCngTemp(CircularPriceChangedDetail model)
        {
            try
            {
                List<CircularPriceChangedDetail> cirdisc = GetPriceCngTemp();
                CircularPriceChangedDetail one = cirdisc.Find(m => m.BarCode == model.BarCode);
                if (one != null)
                {
                    return Json(new { result = false, Error = "BarCode already exists in the list." }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    cirdisc.Add(model);
                }

                Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.tempPriceCngDetails] = cirdisc;
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }

            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult PriceCngTempDelete(string BarCode)
        {
            try
            {
                List<CircularPriceChangedDetail> cirdisc = GetPriceCngTemp();
                CircularPriceChangedDetail one = cirdisc.Find(m => m.BarCode == BarCode);
                cirdisc.Remove(one);
                return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult GetPriceCngTempList()
        {
            try
            {
                List<CircularPriceChangedDetail> cirdisc = GetPriceCngTemp();
                var list = JsonConvert.SerializeObject(new { data = cirdisc }, Formatting.None,
                            new JsonSerializerSettings()
                            {
                                ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                            });

                return Content(list, "application/json");
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult PriceCngInsertFromTemp(string EffectiveDt, string PCName)
        {
            string CPCNo = "";
            try
            {
                DateTime ef = Convert.ToDateTime(DateTime.Now.ToShortDateString());
                
                DateTime.TryParse(EffectiveDt, out ef);

                CPCNo = new GlobalClass().GetMaxIdWithPrfix("CPCNo", "9", "000000001", "CircularPriceChanged", "CPC");

                List<CircularPriceChangedDetail> cirdisc = GetPriceCngTemp();
                foreach (CircularPriceChangedDetail b in cirdisc)
                {
                    if (b.CngAmount == 0)
                    {
                        return Json(new { result = false, Error = "Discount Price yet not calculated" }, JsonRequestBehavior.AllowGet);
                    }
                    b.CPCNo = CPCNo;
                    _priceChangedDetailService.Create(b);
                }

                CircularPriceChanged cd = new CircularPriceChanged();
                cd.CPCNo = CPCNo;
                cd.CPCName = PCName;
                cd.EffectiveDate = ef;
                cd.CreateDate = DateTime.Now;
                cd.UserId = User.Identity.Name;
                cd.IsActivated = "N";
                
                _priceChangedService.Create(cd);
                _priceChangedService.Save();

                _priceChangedDetailService.Save();
                Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.tempPriceCngDetails] = null;
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message.ToString() }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, CPCNo = CPCNo }, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region ===== Sales Man =====
        public ActionResult SalesMan()
        {
            if (!IsPermissionApply("Setup", "SalesMan"))
            {
                return RedirectToAction("Index", "Home");
            }

            List<ShopList> spl = _shopListService.Gets().ToList();
            ViewBag.ShopList = new SelectList(spl, "ShopID", "ShopName");
            return View();
        }
        [HttpPost]
        public ActionResult CreateSalesMan(SalesMan model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (_salesManService.IsDuplicate(model))
                    {
                        return Json(new { result = false, Error = "Duplicate Data" }, JsonRequestBehavior.AllowGet);
                    }
                    _salesManService.Create(model);
                    _salesManService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult UpdateSalesMan(SalesMan model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    List<SalesMan> dataList = _salesManService.Gets().ToList();
                    SalesMan data = dataList.Find(m => m.ID == model.ID);
                    data.SMID = model.SMID;
                    data.SMName = model.SMName;
                    data.ShopID = model.ShopID;
                    _salesManService.Update(data);
                    _salesManService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "Updated" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult DeleteSalesMan(SalesMan model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    List<SalesMan> dataList = _salesManService.Gets().ToList();
                    SalesMan data = dataList.Find(m => m.ID == model.ID);
                    _salesManService.Remove(data);
                    _salesManService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult SalesManList()
        {
            IEnumerable<SalesMan> datas = _salesManService.Gets();
            var list = JsonConvert.SerializeObject(new { data = datas }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }


        public ActionResult SalesManFindByID(string ID)
        {
            List<SalesMan> dataList = _salesManService.Gets().ToList();
            SalesMan result = dataList.Find(m => m.ID == Convert.ToInt32(ID));
            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        public ActionResult SalesManFindBySMID(string SMID)
        {
            SalesMan result = _salesManService.GetBySMID(SMID);

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        public ActionResult SalesManFindByShopID(string ShopID)
        {
            IEnumerable<SalesMan> datas = _salesManService.GetByShopId(ShopID);

            var list = JsonConvert.SerializeObject(new { data = datas }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }
        #endregion

        #region ===== Employee =====
        public ActionResult Employee()
        {
            if (!IsPermissionApply("Setup", "Employee"))
            {
                return RedirectToAction("Index", "Home");
            }

            List<ShopList> spl = _shopListService.Gets().ToList();
            ViewBag.ShopList = new SelectList(spl, "ShopID", "ShopName");

            List<Designation> de = _designationService.Gets().ToList();
            ViewBag.DesignationList = new SelectList(de, "DesignationId", "DesignationName");

            return View();
        }
        [HttpPost]
        public ActionResult CreateEmployee(Employee model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    string sId = new GlobalClass().GetMaxId("EmployeeId", "Employee");
                    int Id = 1;
                    int.TryParse(sId, out Id);
                    model.EmployeeId = Id;
                    _employeeService.Create(model);
                    _employeeService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult UpdateEmployee(Employee model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    Employee e = _employeeService.GetByID(model.EmployeeId);

                    e.CardNo = model.CardNo;
                    e.EmpName = model.EmpName;
                    e.Mobile = model.Mobile;
                    e.Email = model.Email;
                    e.Address = model.Address;
                    e.DesignationId = model.DesignationId;
                    e.ShopId = model.ShopId;
                    e.IsActive = model.IsActive;
                    _employeeService.Update(e);
                    _employeeService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "Updated" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult DeleteEmployee(string EmployeeId)
        {
            try
            {
                int eId = 0;
                int.TryParse(EmployeeId, out eId);
                var e = _employeeService.GetByID(eId);
                _employeeService.RemoveAttach(e);
                _employeeService.Save();
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult EmployeeList()
        {
            List<Employee> datas = _employeeService.Gets();
            var list = JsonConvert.SerializeObject(new { data = datas }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        public ActionResult EmployeeFindByDesignationID(string DesignationID)
        {
            int dId = 0;
            int.TryParse(DesignationID, out dId);
            List<Employee> dataList = _employeeService.GetByDesignationID(dId);
            var list = JsonConvert.SerializeObject(new { data = dataList }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        public ActionResult EmployeeByID(string EmployeeId)
        {
            int eId = 0;
            int.TryParse(EmployeeId, out eId);
            Employee result = _employeeService.GetByID(eId);

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        public ActionResult EmployeeFindByShopID(string ShopID)
        {
            IEnumerable<Employee> datas = _employeeService.GetByShopID(ShopID);

            var list = JsonConvert.SerializeObject(new { data = datas }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }
        #endregion

        #region Pay Less

        public ActionResult PayLess()
        {
            if (!IsPermissionApply("Setup", "PayLess"))
            {
                return RedirectToAction("Index", "Home");
            }

            return View();
        }

        private List<PayLess> TempPayLessList()
        {
            List<PayLess> payLess = new List<PayLess>();
            if (Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.tempPayLess] != null)
            {
                payLess = Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.tempPayLess] as List<PayLess>;
            }
            return payLess;
        }

        public ActionResult GetPayLessTempExitsList(string BarCode, DateTime sDate, DateTime eDate)
        {
            try
            {
                List<PayLess> findExists = _payLessService.ExistswithinDate(Convert.ToDateTime(sDate),
                    Convert.ToDateTime(eDate));
                findExists = findExists.FindAll(m => m.BarCode == BarCode);
                string msg = "";

                var distinctItems = findExists
                    .GroupBy(x => x.PayLessNo)
                    .Select(x => x.First());

                var list = JsonConvert.SerializeObject(new { data = distinctItems }, Formatting.None,
                    new JsonSerializerSettings()
                    {
                        ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                    });

                return Content(list, "application/json");

            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult CreatePayLessList(PayLess model)
        {
            try
            {
                List<PayLess> findExists = _payLessService.ExistswithinDate(Convert.ToDateTime(model.StartDate), Convert.ToDateTime(model.EndDate));
                findExists = findExists.FindAll(m => m.BarCode == model.BarCode);
                if (findExists.Count > 0)
                {
                    var distinctItems = findExists
                  .GroupBy(x => x.PayLessNo)
                  .Select(x => x.First());
                    var list = JsonConvert.SerializeObject(new { result = false, data = distinctItems }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

                    return Content(list, "application/json");
                }

                List<PayLess> payLessList = TempPayLessList();
                PayLess one = payLessList.Find(m => m.BarCode == model.BarCode && m.Status==model.Status);
                if (one != null)
                {
                    model.Qty = model.Qty + one.Qty;
                    payLessList.Remove(one);
                    payLessList.Add(model);
                }
                else
                {
                    payLessList.Add(model);
                }
                Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.tempPayLess] = payLessList;
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }

            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetPayLessTempList()
        {
            List<PayLess> payless = TempPayLessList();

            var list = JsonConvert.SerializeObject(new { data = payless }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }


        public ActionResult PayLessDeleteTemp(string BarCode)
        {
            List<PayLess> less = TempPayLessList();
            PayLess one = less.Find(m => m.BarCode == BarCode);
            less.Remove(one);
            Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.tempPayLess] = less;

            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }
        public ActionResult PayLessSave(string PayLessName,string EffectiveDt, string ExpireDt)
        {
            string PayLessNo = "";
            try
            {
                DateTime ef = DateTime.Now;
                DateTime exp = DateTime.Now;
                DateTime.TryParse(EffectiveDt, out ef);
                DateTime.TryParse(ExpireDt, out exp);
                PayLessNo = new GlobalClass().GetMaxIdWithPrfix("PayLessNo", "6", "000001", "PayLess", "PL");
                List<PayLess> less = TempPayLessList();
                List<PayLess> Buyless = new List<PayLess>();
                foreach (PayLess b in less)
                {
                    b.PayLessNo = PayLessNo;
                    b.PayLessName = PayLessName;
                    b.StartDate = ef;
                    b.EndDate = exp;
                    b.UserId = User.Identity.Name;
                    b.CreateDate = DateTime.Now;
                    b.UpdateDate = DateTime.Now;
                    _payLessService.Create(b);
                }
                _payLessService.Save();

                Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.tempPayLess] = null;
               
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message.ToString() }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, PayLessNo = PayLessNo }, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region ==== Menu Permission Check =====
        private bool IsPermissionApply(string Controller, string ActionName)
        {
            List<MenuURLViewModel> lstMenus = null;
            if (Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.SessionMenu] == null)
            {
                lstMenus = new GlobalClass().GetMenuByUserName(User.Identity.Name);
                Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.SessionMenu] = lstMenus;
            }
            else
            {
                lstMenus =
                    Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.SessionMenu] as
                        List<MenuURLViewModel>;
            }
            MenuURLViewModel menu = lstMenus.FindAll(m => m.Controller == Controller && m.ActionName == ActionName).FirstOrDefault();
            if (menu != null)
                return true;
            else
                return false;
        }
        #endregion
    }
}
