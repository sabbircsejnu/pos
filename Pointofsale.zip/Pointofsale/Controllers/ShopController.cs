﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AutoMapper;
using Newtonsoft.Json;
using RetailMaster.POS.Data;
using RetailMaster.POS.Models;
using RetailMaster.POS.Service;
using RetailMaster.POS.Web.BLL;
using RetailMaster.POS.Web.Models;
using RetailMaster.POS.Web.ViewModels;

namespace RetailMaster.POS.Web.Controllers
{
    public class ShopController : Controller
    {
        private readonly IrChallanShopService _rchallanShopService;
        private readonly IiChallanService _iChallanService;
        private readonly IiChallanTempService _iChallanTempService;
        private readonly IBuyRequisitionService _buyRequisitionService;
        private readonly IBuyRequisitionTempService _buyRequisitionTempService;
        private readonly IShopListService _shopList;
        private readonly ISaleService _saleService;
        private readonly IBuyService _buyService;
        private readonly IPackageIssueDetailService _packageIssueService;
        private readonly IPackageIssueService _pckPackageIssue;

        public ShopController(IrChallanShopService rrchallanShopService, IiChallanTempService iChallanTempService, IiChallanService iChallanService,
            IBuyRequisitionService buyRequisitionService, IBuyRequisitionTempService buyRequisitionTempService, IBuyService ibuyService,
             IShopListService shopList, ISaleService saleService, IPackageIssueDetailService packageIssueService, IPackageIssueService pckPackageIssue)
        {
            this._rchallanShopService = rrchallanShopService;
            this._iChallanService = iChallanService;
            this._iChallanTempService = iChallanTempService;
            this._buyRequisitionService = buyRequisitionService;
            this._buyRequisitionTempService = buyRequisitionTempService;
            this._buyService = ibuyService;
            this._shopList = shopList;
            this._saleService = saleService;
            this._packageIssueService = packageIssueService;
            this._pckPackageIssue = pckPackageIssue;
        }


        #region ====== Buy Requisition ======
        private LogedInInfo GetLogedInInfo()
        {
            LogedInInfo info = new LogedInInfo();
            if (HttpContext.Request.Cookies["POSLogedInInfo"] != null)
            {
                HttpCookie cookie = HttpContext.Request.Cookies.Get("POSLogedInInfo");
                info = Newtonsoft.Json.JsonConvert.DeserializeObject<LogedInInfo>(cookie.Value) as LogedInInfo;
            }
            return info;
        }
        public ActionResult ShopRequisition()
        {
            if (!IsPermissionApply("Shop", "ShopRequisition"))
            {
                return RedirectToAction("Index", "Home");
            }
            ViewBag.ShopID = GetLogedInInfo().ShopID;
            return View();
        }
        public ActionResult BuyRequisitionTempListByShopID()
        {
            string shopID = GetLogedInInfo().ShopID;
            IEnumerable<BuyRequisitionTemp> datas = _buyRequisitionTempService.GetByShopID(shopID,User.Identity.Name);

            var list = JsonConvert.SerializeObject(new { data = datas }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        public ActionResult GetShopStockByBarCode(string BarCode)
        {
            string balQty = "0";
            DataTable dt = _saleService.GetStockByBarCodeShopID(BarCode, GetLogedInInfo().ShopID);
            if (dt.Rows.Count > 0)
            {
                balQty = dt.Rows[0]["balQty"].ToString();
            }
            var list = JsonConvert.SerializeObject(new { data = balQty }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }
       
        [HttpPost]
        public ActionResult CreateShopRequisitionTemp(BuyRequisitionTempViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    BuyRequisitionTemp dbModel = new BuyRequisitionTemp();
                    dbModel = Mapper.Map<BuyRequisitionTempViewModel, BuyRequisitionTemp>(model);

                    string GetRequisitionNoCode = _buyRequisitionTempService.GetCode(dbModel.ShopID);

                    dbModel.RequisitionNo = "T" + GetRequisitionNoCode;

                    dbModel.CmpIDX = dbModel.RequisitionNo + dbModel.BarCode;

                    BuyRequisitionTemp data = _buyRequisitionTempService.Get(dbModel.CmpIDX);
                    if (data != null)
                    {
                        data.Qty = dbModel.Qty + data.Qty;
                        data.UserID = User.Identity.Name;
                        _buyRequisitionTempService.Update(data);
                    }
                    else
                    {
                        dbModel.UserID = User.Identity.Name;
                        _buyRequisitionTempService.Create(dbModel);
                    }

                    _buyRequisitionTempService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult UpdateShopRequisitionTemp(BuyRequisitionTempViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    BuyRequisitionTemp dbModel = new BuyRequisitionTemp();
                    dbModel = Mapper.Map<BuyRequisitionTempViewModel, BuyRequisitionTemp>(model);
                    BuyRequisitionTemp data = _buyRequisitionTempService.Get(dbModel.CmpIDX);
                    if (data != null)
                    {
                        data.Qty = dbModel.Qty;
                        data.UserID = User.Identity.Name;
                        _buyRequisitionTempService.Update(data);
                    }
                    _buyRequisitionTempService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Updated" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult DeleteShopRequisitionTemp(string CmpIDX)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var data = _buyRequisitionTempService.Get(CmpIDX);
                    _buyRequisitionTempService.Remove(data);
                    _buyRequisitionTempService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult BuyRequisitionTempByShopID(string ShopID)
        {
            IEnumerable<BuyRequisitionTemp> datas = _buyRequisitionTempService.GetByShopID(ShopID,User.Identity.Name);
            var list = JsonConvert.SerializeObject(new { data = datas }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        public ActionResult BuyRequisitionTempByCmpIDX(string CmpIDX)
        {
            BuyRequisitionTemp datas = _buyRequisitionTempService.Get(CmpIDX);
            var list = JsonConvert.SerializeObject(new { data = datas }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        public ActionResult InsertBuyRequisitionFromTemp()
        {
            string shopID = GetLogedInInfo().ShopID; //cs
            

            IEnumerable<BuyRequisitionTemp> tempData = _buyRequisitionTempService.GetByShopID(shopID,User.Identity.Name);
            BuyRequisitionTemp getone = tempData.FirstOrDefault();
            string NewRequisitionNo = _buyRequisitionTempService.GetCode(getone.ShopID);

            foreach (BuyRequisitionTemp icT in tempData)
            {
                BuyRequisition ic = new BuyRequisition();
                ic.RequisitionNo = NewRequisitionNo;
                ic.BarCode = icT.BarCode;
                ic.sBarCode = icT.sBarCode;
                ic.CmpIDX = NewRequisitionNo + icT.BarCode;
                ic.BuyDT = icT.BuyDT;
                ic.CPU = icT.CPU;
                ic.DiscPrcnt = icT.DiscPrcnt;
                ic.EXPDT = icT.EXPDT;
                ic.Point = icT.Point;
                ic.PrdComm = icT.PrdComm;
                ic.Qty = icT.Qty;
                ic.RPU = icT.RPU;
                ic.Reorder = icT.Reorder;
                ic.ShopID = icT.ShopID;
                ic.SupID = icT.SupID;
                ic.Transfer = icT.Transfer;
                ic.VATPrcnt = icT.VATPrcnt;
                ic.WSP = icT.WSP;
                ic.WSQ = icT.WSQ;
                ic.ZoneID = icT.ZoneID;
                ic.balQty = icT.balQty;
                ic.sQty = icT.sQty;
                ic.IsApproved = "N";
                ic.SupID = ic.SupID;
                ic.UserID = icT.UserID;
                _buyRequisitionService.Create(ic);
            }
            _buyRequisitionService.Save();

            try
            {
                //delete from temp
                foreach (BuyRequisitionTemp rcTemp in tempData)
                {
                    _buyRequisitionTempService.Remove(rcTemp);
                }
                _iChallanTempService.Save();

                //return rest of the things
                IEnumerable<BuyRequisitionTempViewModel> result = null;
                IEnumerable<BuyRequisitionTemp> datas = _buyRequisitionTempService.GetByShopID(shopID,User.Identity.Name);
                result = Mapper.Map<IEnumerable<BuyRequisitionTemp>, IEnumerable<BuyRequisitionTempViewModel>>(datas);

                var list = JsonConvert.SerializeObject(new { data = result, Error = "Saved", NewRequisitionNo = NewRequisitionNo }, Formatting.None,
                            new JsonSerializerSettings()
                            {
                                ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                            });

                return Content(list, "application/json");
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult BuyRequisitionTempDeleteByShopID()
        {
            try
            {
                string shopID = GetLogedInInfo().ShopID; //cs
               
                IEnumerable<BuyRequisitionTemp> tempData = _buyRequisitionTempService.GetByShopID(shopID,User.Identity.Name);
                foreach (BuyRequisitionTemp rcTemp in tempData)
                {
                    _buyRequisitionTempService.Remove(rcTemp);
                }
                _buyRequisitionTempService.Save();

                return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult GetRequisitioTotalAmount(string ShopID)
        {
            IEnumerable<BuyRequisitionTemp> datas = _buyRequisitionTempService.GetByShopID(ShopID,User.Identity.Name);
            var total = datas.Sum(s => s.CPU * s.Qty);
            var list = JsonConvert.SerializeObject(new { data = total }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        public ActionResult BuyRequisitionByCmpIDX(string CmpIDX)
        {
            DataTable dt = _buyRequisitionService.GetByCmpIDX(CmpIDX);
            var list = JsonConvert.SerializeObject(new { data = dt }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        #endregion

        #region ====== Shop Receive =====
        public ActionResult ShopReceive()
        {
            if (!IsPermissionApply("Shop", "ShopReceive"))
            {
                return RedirectToAction("Index", "Home");
            }
            ViewBag.ShopID = GetLogedInInfo().ShopID;
            return View();
        }

        public ActionResult ShopReceiveGetDCNOByShopID(string ShopID)
        {
            DataTable dt = _buyService.GetDCNoByShopID(ShopID);
            var list = JsonConvert.SerializeObject(new { data = dt }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        public ActionResult ShopReceivGetByDCNOandTransfer(string DCNO)
        {
            DataTable dt = _buyService.GetByDCNOandTransfer(DCNO, "N", GetLogedInInfo().ShopID);
            var list = JsonConvert.SerializeObject(new { data = dt }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        public ActionResult ShopReceiveByDCNO(string DCNO)
        {
            try
            {
                DataTable dt = _buyService.GetByDCNOandTransfer(DCNO, "N", GetLogedInInfo().ShopID);
                if (dt.Rows.Count == 0)
                {
                    return Json(new { result = false, Error = "Data Not Found." }, JsonRequestBehavior.AllowGet);
                }

                decimal ChlnTotal = 0;
                foreach (DataRow dr in dt.Rows)
                {
                    decimal cpu = 0;
                    decimal.TryParse(dr["CPU"].ToString(), out cpu);
                    decimal Qty = 0;
                    decimal.TryParse(dr["Qty"].ToString(), out Qty);
                    ChlnTotal += cpu * Qty;
                }
                foreach (DataRow dr in dt.Rows)
                {
                    decimal temp = 0;
                    rChallanShop rc = new rChallanShop();
                    rc.CmpIDX = dr["CMPIDX"].ToString();
                    rc.sBarCode = dr["sBarCode"].ToString();
                    rc.BarCode = dr["BarCode"].ToString();
                    rc.OrderNo = dr["Chln"].ToString();// RequisitionNo
                    rc.Chln = DCNO;
                    //EXPDT
                    //LastSDT
                    rc.BuyDT = DateTime.Now;
                    
                    decimal.TryParse(dr["CPU"].ToString(), out temp);
                    rc.CPU = temp;
                    decimal.TryParse(dr["RPU"].ToString(), out temp);
                    rc.RPU = temp;
                    rc.VPP = 0;
                    rc.VPU = 0;
                    decimal.TryParse(dr["DiscPrcnt"].ToString(), out temp);
                    rc.DiscPrcnt = temp;
                    decimal.TryParse(dr["VATPrcnt"].ToString(), out temp);
                    rc.VATPrcnt = temp;
                    decimal.TryParse(dr["PrdComm"].ToString(), out temp);
                    rc.PrdComm = temp;
                    decimal.TryParse(dr["Qty"].ToString(), out temp);
                    rc.Qty = temp;
                    decimal.TryParse(dr["bQty"].ToString(), out temp);
                    rc.bQty = temp;
                    decimal.TryParse(dr["sQty"].ToString(), out temp);
                    rc.sQty = temp;
                    decimal.TryParse(dr["cSqty"].ToString(), out temp);
                    rc.cSqty = temp;
                    decimal.TryParse(dr["rQty"].ToString(), out temp);
                    rc.rQty = temp;
                    decimal.TryParse(dr["dmlqty"].ToString(), out temp);
                    rc.dmlqty = temp;
                    rc.ShopID = dr["ShopID"].ToString();
                    rc.Transfer = "N";
                    rc.TotalPrdComm = 0;
                    rc.AddPrdComm = 0;
                    rc.ChlnTotal = ChlnTotal;
                    rc.SupRef = "Ref";
                    rc.UserID = User.Identity.Name;
                    _rchallanShopService.Create(rc);

                    Buy buy = _buyService.GetByCMPIDX(rc.BarCode, rc.ShopID);
                    if (buy != null)
                    {
                        buy.balQty = buy.balQty + rc.Qty;
                        buy.Qty = buy.Qty + rc.Qty;
                        _buyService.Update(buy);
                    }
                    else
                    {
                        Buy b = new Buy();
                        b.CMPIDX = dr["ShopID"].ToString() + dr["BarCode"].ToString();
                        b.sBarCode = dr["sBarCode"].ToString();
                        b.BarCode = dr["BarCode"].ToString();
                        b.Chln = dr["DCNO"].ToString();
                        //LCPU
                        b.sreturn = 0;
                        b.TrfQty = 0;
                        b.SrpQty = 0;
                        b.InvQty = 0;
                        //EXPDT
                        //LastSDT
                        b.BuyDT = DateTime.Now;
                        decimal.TryParse(dr["CPU"].ToString(), out temp);
                        b.CPU = temp;
                        decimal.TryParse(dr["RPU"].ToString(), out temp);
                        b.RPU = temp;
                        decimal.TryParse(dr["RPP"].ToString(), out temp);
                        b.RPP = temp;
                        decimal.TryParse(dr["WSP"].ToString(), out temp);
                        b.WSP = temp;
                        decimal.TryParse(dr["WSQ"].ToString(), out temp);
                        b.WSQ = temp;
                        decimal.TryParse(dr["Point"].ToString(), out temp);
                        b.Point = temp;
                        decimal.TryParse(dr["Reorder"].ToString(), out temp);
                        b.Reorder = temp;
                        decimal.TryParse(dr["DiscPrcnt"].ToString(), out temp);
                        b.DiscPrcnt = temp;
                        decimal.TryParse(dr["VATPrcnt"].ToString(), out temp);
                        b.VATPrcnt = temp;
                        decimal.TryParse(dr["PrdComm"].ToString(), out temp);
                        b.PrdComm = temp;
                        decimal.TryParse(dr["Qty"].ToString(), out temp);
                        b.Qty = temp;
                        b.balQty = temp;
                        decimal.TryParse(dr["bQty"].ToString(), out temp);
                        b.bQty = temp;
                        decimal.TryParse(dr["sQty"].ToString(), out temp);
                        b.sQty = temp;
                        decimal.TryParse(dr["rQty"].ToString(), out temp);
                        b.rQty = temp;
                        decimal.TryParse(dr["dmlqty"].ToString(), out temp);
                        b.dmlqty = temp;
                        b.ZoneID = dr["ZoneID"].ToString();
                        b.ShopID = dr["ShopID"].ToString();
                        b.SupID = dr["SupID"].ToString();
                        b.Transfer = "N";
                        b.SupRef = "Ref";
                        b.UserID = User.Identity.Name;
                        _buyService.Create(b);
                    }
                }
                _iChallanService.UpdatesTransferByDCNO(DCNO, "Y");
                _buyService.Save();
                _rchallanShopService.Save();
                _iChallanService.Save();
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region ====== Package Issue Receive =====
        public ActionResult PackageIssueReceive()
        {
            if (!IsPermissionApply("Shop", "PackageIssueReceive"))
            {
                return RedirectToAction("Index", "Home");
            }
            ViewBag.ShopID = GetLogedInInfo().ShopID;
            return View();
        }

        public ActionResult PackageIssueReceiveGetPINOByShopID(string ShopID)
        {
            DataTable dt = _packageIssueService.PackageIssueNotReceive(ShopID);
            var list = JsonConvert.SerializeObject(new { data = dt }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        public ActionResult PackageIssueGetByPINOandTransfer(string PINO)
        {
            DataTable dt = _packageIssueService.GetAllByPIssueNo(PINO);
            var list = JsonConvert.SerializeObject(new { data = dt }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        public ActionResult PackageIssueReceiveByPINO(string PINO)
        {
            try
            {
                List<PackageIssueDetail> oList = _packageIssueService.GetByPIssueNo(PINO);
                if (oList == null)
                {
                    return Json(new { result = false, Error = "Data Not Found." }, JsonRequestBehavior.AllowGet);
                }

                foreach (PackageIssueDetail pi in oList)
                {
                    PackageIssue pack = _pckPackageIssue.GetByPackageNo(pi.PackageNo).FirstOrDefault();
                    if (pack != null)
                    {
                        pack.PQty += pi.PQty;
                        pack.balPQty += pi.PQty;
                        pack.PIssueNo = pi.PIssueNo;
                        pack.CreateDate = pi.CreateDate;
                        pack.RecvUserId = User.Identity.Name;
                        pack.RecvDate = DateTime.Now;
                        pack.sPQty = 0;
                    }
                    else
                    {
                        PackageIssue p = new PackageIssue();
                        p.PQty = pi.PQty;
                        p.balPQty = pi.PQty;
                        p.PIssueNo = pi.PIssueNo;
                        p.CreateDate = pi.CreateDate;
                        p.PackageName = pi.PackageName;
                        p.PackageNo = pi.PackageNo;
                        p.PackagePrice = pi.PackagePrice;
                        p.RecvUserId = "";
                        p.ShopID = pi.ShopID;
                        p.UserId = User.Identity.Name;
                        p.sPQty = 0;
                        p.CreateDate = DateTime.Now;
                        p.RecvUserId = User.Identity.Name;
                        p.RecvDate = DateTime.Now;
                        p.sPQty = 0;
                        _pckPackageIssue.Create(p);
                    }
                    pi.RecvUserId = User.Identity.Name;
                    pi.RecvDate = DateTime.Now;
                }
                _pckPackageIssue.Save();
                _packageIssueService.Save();
                _packageIssueService.Save();
            }

            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region ==== Menu Permission Check =====
        private bool IsPermissionApply(string Controller, string ActionName)
        {
            List<MenuURLViewModel> lstMenus = null;
            if (Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.SessionMenu] == null)
            {
                lstMenus = new GlobalClass().GetMenuByUserName(User.Identity.Name);
                Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.SessionMenu] = lstMenus;
            }
            else
            {
                lstMenus =
                    Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.SessionMenu] as
                        List<MenuURLViewModel>;
            }
            MenuURLViewModel menu = lstMenus.FindAll(m => m.Controller == Controller && m.ActionName == ActionName).FirstOrDefault();
            if (menu != null)
                return true;
            else
                return false;
        }
        #endregion

    }
}