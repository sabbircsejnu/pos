﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MoreLinq;
using Newtonsoft.Json;
using RetailMaster.POS.Models;
using RetailMaster.POS.Service;
using RetailMaster.POS.Web.BLL;
using RetailMaster.POS.Web.Models;
using RetailMaster.POS.Web.ViewModels;

namespace RetailMaster.POS.Web.Controllers
{
    public class StockReportController : Controller
    {
        private readonly ISupplierService _supplierService;
        private readonly IShopListService _shopListService;
        private readonly IBrandTypeService _brandTypeService;
        private readonly IPGroupService _groupService;
        private readonly ICircularDiscountService _circularDiscountService;
        private readonly IPackageService _packageService;
        private readonly IPackageIssueDetailService _packageIssueService;
        private readonly ICircularPriceChangedService _circularPriceChangedService;
        private readonly IBuyAndGetService _buyAndGetService;
        private readonly IPayLessService _payLessService;

        public StockReportController(ISupplierService supplierService, IShopListService shopListService,
            IBrandTypeService brandTypeService, IPGroupService groupService, ICircularDiscountService circularDiscountService,
            IPackageService packageService, ICircularPriceChangedService circularPriceChangedService, IBuyAndGetService buyAndGetService,
            IPayLessService payLessService, IPackageIssueDetailService packageIssueService)
        {
            this._supplierService = supplierService;
            this._shopListService = shopListService;
            this._brandTypeService = brandTypeService;
            this._groupService = groupService;
            this._circularDiscountService = circularDiscountService;
            this._packageService = packageService;
            this._circularPriceChangedService = circularPriceChangedService;
            this._buyAndGetService = buyAndGetService;
            this._payLessService = payLessService;
            this._packageIssueService = packageIssueService;
        }

        private LogedInInfo GetLogedInInfo()
        {
            LogedInInfo info = new LogedInInfo();
            if (HttpContext.Request.Cookies["POSLogedInInfo"] != null)
            {
                HttpCookie cookie = HttpContext.Request.Cookies.Get("POSLogedInInfo");
                info = Newtonsoft.Json.JsonConvert.DeserializeObject<LogedInInfo>(cookie.Value) as LogedInInfo;
            }
            return info;
        }
        //
        // GET: /StockReport/
        public ActionResult MultipleReportsStock()
        {
            if (!IsPermissionApply("StockReport", "MultipleReportsStock"))
            {
                return RedirectToAction("Index", "Home");
            }

            List<Supplier> supl = _supplierService.Gets().ToList();
            Supplier sp = new Supplier();
            sp.SupID = "";
            sp.Supname = "All";
            supl.Insert(0, sp);
            ViewBag.SupplierList = new SelectList(supl, "SupID", "Supname");

           
            List<ShopList> spl = _shopListService.Gets().ToList();
            string ShopID = GetLogedInInfo().ShopID;
            if (ShopID != "9999")
            {
                ShopList spId = spl.Find(m => m.ShopID == ShopID);
                spl.RemoveAll(m => m.ShopID != ShopID);
            }

            ViewBag.ShopList = new SelectList(spl, "ShopID", "ShopName");

            //Group
            List<PGroup> grouplist = _groupService.Gets().ToList();
            PGroup group = new PGroup();
            group.GroupID = "";
            group.GroupName = "All";
            grouplist.Insert(0, group);
            ViewBag.PGroupList = new SelectList(grouplist, "GroupID", "GroupName");

            //Product
            List<Product> prdlist = new List<Product>();
            Product prd = new Product();
            prd.PrdID = "";
            prd.PrdName = "All";
            prdlist.Insert(0, prd);
            ViewBag.ProductList = new SelectList(prdlist, "PrdID", "PrdName");

            //Brand Type
            List<BrandType> btList = _brandTypeService.Gets().ToList();
            BrandType bt = new BrandType();
            bt.BTID = "";
            bt.BTName = "All";
            btList.Insert(0, bt);
            ViewBag.BrandTypeList = new SelectList(btList, "BTID", "BTName");

            // Style Size
            List<StyleSize> sslist = new List<StyleSize>();
            StyleSize ss = new StyleSize();
            ss.SSID = "";
            ss.SSName = "All";
            sslist.Insert(0, ss);
            ViewBag.StyleSizeList = new SelectList(sslist, "SSID", "SSName");

            return View();
        }
        public ActionResult MultipleReportsPurchaseOrder()
        {
            if (!IsPermissionApply("StockReport", "MultipleReportsPurchaseOrder"))
            {
                return RedirectToAction("Index", "Home");
            }

            List<Supplier> supl = _supplierService.Gets().ToList();
            Supplier sp = new Supplier();
            sp.SupID = "";
            sp.Supname = "All";
            supl.Insert(0, sp);
            ViewBag.SupplierList = new SelectList(supl, "SupID", "Supname");

            List<ShopList> spl = _shopListService.Gets().ToList();
            string ShopID = GetLogedInInfo().ShopID;
            if (ShopID == "9999")
            {
                spl.RemoveAll(m => m.ShopID != ShopID);
            }
            else
            {
                spl.RemoveAll(m => m.ShopID != "9999");
            }
            ViewBag.ShopList = new SelectList(spl, "ShopID", "ShopName");
            return View();
        }
        public ActionResult MultipleReportsPurchaseReceive()
        {
            if (!IsPermissionApply("StockReport", "MultipleReportsPurchaseReceive"))
            {
                return RedirectToAction("Index", "Home");
            }

            List<Supplier> supl = _supplierService.Gets().ToList();
            Supplier sp = new Supplier();
            sp.SupID = "";
            sp.Supname = "All";
            supl.Insert(0, sp);
            ViewBag.SupplierList = new SelectList(supl, "SupID", "Supname");

            List<ShopList> spl = _shopListService.Gets().ToList();
            string ShopID = GetLogedInInfo().ShopID;
            if (ShopID == "9999")
            {
                spl.RemoveAll(m => m.ShopID != ShopID);
            }
            else
            {
                spl.RemoveAll(m => m.ShopID != "9999");
            }
            ViewBag.ShopList = new SelectList(spl, "ShopID", "ShopName");
            return View();
        }
        public ActionResult ShopDeliveryReport()
        {
            if (!IsPermissionApply("StockReport", "ShopDeliveryReport"))
            {
                return RedirectToAction("Index", "Home");
            }

            // login as CS
            string ShopID = GetLogedInInfo().ShopID;
            ViewBag.LogedInShopID = ShopID;
            if (ShopID == "9999")
            {
                List<ShopList> spl = new List<ShopList>();
                ShopList spId = new ShopList();
                spl = _shopListService.Gets().ToList();
                ShopList find = new ShopList();
                find = spl.Find(m => m.ShopID == "9999");
                spl.Remove(find);
                spId.ShopID = "";
                spId.ShopName = "All";
                spl.Insert(0, spId);
                ViewBag.ShopList = new SelectList(spl, "ShopID", "ShopName");
            }

            List<Supplier> supl = _supplierService.Gets().ToList();
            Supplier sp = new Supplier();
            sp.SupID = "";
            sp.Supname = "All";
            supl.Insert(0, sp);
            ViewBag.SupplierList = new SelectList(supl, "SupID", "Supname");

            //Group
            List<PGroup> grouplist = _groupService.Gets().ToList();
            PGroup group = new PGroup();
            group.GroupID = "";
            group.GroupName = "All";
            grouplist.Insert(0, group);
            ViewBag.PGroupList = new SelectList(grouplist, "GroupID", "GroupName");

            //Product
            List<Product> prdlist = new List<Product>();
            Product prd = new Product();
            prd.PrdID = "";
            prd.PrdName = "All";
            prdlist.Insert(0, prd);
            ViewBag.ProductList = new SelectList(prdlist, "PrdID", "PrdName");

            //Brand Type
            List<BrandType> btList = _brandTypeService.Gets().ToList();
            BrandType bt = new BrandType();
            bt.BTID = "";
            bt.BTName = "All";
            btList.Insert(0, bt);
            ViewBag.BrandTypeList = new SelectList(btList, "BTID", "BTName");

            // Style Size
            List<StyleSize> sslist = new List<StyleSize>();
            StyleSize ss = new StyleSize();
            ss.SSID = "";
            ss.SSName = "All";
            sslist.Insert(0, ss);
            ViewBag.StyleSizeList = new SelectList(sslist, "SSID", "SSName");

            return View();
        }
        public ActionResult ShopReceiveReport()
        {
            if (!IsPermissionApply("StockReport", "ShopReceiveReport"))
            {
                return RedirectToAction("Index", "Home");
            }

            // login as CS
            string ShopID = GetLogedInInfo().ShopID;
            ViewBag.LogedInShopID = ShopID;
            if (ShopID == "9999")
            {
                List<ShopList> spl = new List<ShopList>();
                ShopList spId = new ShopList();
                spl = _shopListService.Gets().ToList();
                ShopList find = new ShopList();
                find = spl.Find(m => m.ShopID == "9999");
                spl.Remove(find);
                spId.ShopID = "";
                spId.ShopName = "All";
                spl.Insert(0, spId);
                ViewBag.ShopList = new SelectList(spl, "ShopID", "ShopName");
            }
            else
            {
                // login as shop
                List<ShopList> Fspl = new List<ShopList>();
                List<ShopList> spl = new List<ShopList>();
                Fspl = _shopListService.Gets().ToList();
                ShopList cs = new ShopList();
                cs = Fspl.Find(m => m.ShopID == ShopID);
                spl.Add(cs);
                ViewBag.ShopList = new SelectList(spl, "ShopID", "ShopName");
            }


            //supplier
            List<Supplier> supl = _supplierService.Gets().ToList();
            Supplier sp = new Supplier();
            sp.SupID = "";
            sp.Supname = "All";
            supl.Insert(0, sp);
            ViewBag.SupplierList = new SelectList(supl, "SupID", "Supname");

            //Group
            List<PGroup> grouplist = _groupService.Gets().ToList();
            PGroup group = new PGroup();
            group.GroupID = "";
            group.GroupName = "All";
            grouplist.Insert(0, group);
            ViewBag.PGroupList = new SelectList(grouplist, "GroupID", "GroupName");

            //Product
            List<Product> prdlist = new List<Product>();
            Product prd = new Product();
            prd.PrdID = "";
            prd.PrdName = "All";
            prdlist.Insert(0, prd);
            ViewBag.ProductList = new SelectList(prdlist, "PrdID", "PrdName");

            //Brand Type
            List<BrandType> btList = _brandTypeService.Gets().ToList();
            BrandType bt = new BrandType();
            bt.BTID = "";
            bt.BTName = "All";
            btList.Insert(0, bt);
            ViewBag.BrandTypeList = new SelectList(btList, "BTID", "BTName");

            // Style Size
            List<StyleSize> sslist = new List<StyleSize>();
            StyleSize ss = new StyleSize();
            ss.SSID = "";
            ss.SSName = "All";
            sslist.Insert(0, ss);
            ViewBag.StyleSizeList = new SelectList(sslist, "SSID", "SSName");

            return View();
        }
        public ActionResult ShopTransfer()
        {
            if (!IsPermissionApply("StockReport", "ShopTransfer"))
            {
                return RedirectToAction("Index", "Home");
            }
            // login as CS
            string ShopID = GetLogedInInfo().ShopID;
            ViewBag.LogedInShopID = ShopID;
            if (ShopID == "9999")
            {
                List<ShopList> Fspl = new List<ShopList>();
                List<ShopList> Tspl = new List<ShopList>();
                Fspl = _shopListService.Gets().ToList();
                Tspl = _shopListService.Gets().ToList(); ;
                ShopList spId = new ShopList();
                spId.ShopID = "";
                spId.ShopName = "All";
                Fspl.Insert(0, spId);
                Tspl.Insert(0, spId);
                ShopList cs = new ShopList();
                cs = Fspl.Find(m => m.ShopID == "9999");
                Fspl.Remove(cs);
                ViewBag.FShopList = new SelectList(Fspl, "ShopID", "ShopName");
                ViewBag.TShopList = new SelectList(Tspl, "ShopID", "ShopName");
            }
            else
            {
                // login as shop
                List<ShopList> Fspl = new List<ShopList>();
                List<ShopList> Tspl = new List<ShopList>();
                Fspl = _shopListService.Gets().ToList();
                Tspl = _shopListService.Gets().ToList();

                //Transfer from
                Fspl.RemoveAll(m => m.ShopID != ShopID);
                ViewBag.FShopList = new SelectList(Fspl, "ShopID", "ShopName");

                //to
                ShopList cs = new ShopList();
                cs = Tspl.Find(m => m.ShopID == ShopID);
                Tspl.Remove(cs);

                ShopList spId = new ShopList();
                spId.ShopID = "";
                spId.ShopName = "All";
                Tspl.Insert(0, spId);
                ViewBag.TShopList = new SelectList(Tspl, "ShopID", "ShopName");
            }

            List<Supplier> supl = _supplierService.Gets().ToList();
            Supplier sp = new Supplier();
            sp.SupID = "";
            sp.Supname = "All";
            supl.Insert(0, sp);
            ViewBag.SupplierList = new SelectList(supl, "SupID", "Supname");

            //Group
            List<PGroup> grouplist = _groupService.Gets().ToList();
            PGroup group = new PGroup();
            group.GroupID = "";
            group.GroupName = "All";
            grouplist.Insert(0, group);
            ViewBag.PGroupList = new SelectList(grouplist, "GroupID", "GroupName");

            //Product
            List<Product> prdlist = new List<Product>();
            Product prd = new Product();
            prd.PrdID = "";
            prd.PrdName = "All";
            prdlist.Insert(0, prd);
            ViewBag.ProductList = new SelectList(prdlist, "PrdID", "PrdName");

            //Brand Type
            List<BrandType> btList = _brandTypeService.Gets().ToList();
            BrandType bt = new BrandType();
            bt.BTID = "";
            bt.BTName = "All";
            btList.Insert(0, bt);
            ViewBag.BrandTypeList = new SelectList(btList, "BTID", "BTName");

            // Style Size
            List<StyleSize> sslist = new List<StyleSize>();
            StyleSize ss = new StyleSize();
            ss.SSID = "";
            ss.SSName = "All";
            sslist.Insert(0, ss);
            ViewBag.StyleSizeList = new SelectList(sslist, "SSID", "SSName");

            return View();
        }
        public ActionResult GetTransferToShop(string FromShop)
        {
            string ShopID = GetLogedInInfo().ShopID;

            List<ShopList> spl = new List<ShopList>();
            spl = _shopListService.Gets().ToList();
            if (ShopID == FromShop)
            {
                // if select from shop as login shop
                ShopList FspId = spl.Find(m => m.ShopID == FromShop);
                spl.Remove(FspId);

                ShopList spId = new ShopList();
                spId.ShopID = "";
                spId.ShopName = "All";
                spl.Insert(0, spId);
            }
            else
            {
                ShopList FspId = spl.Find(m => m.ShopID == ShopID);
                spl.RemoveAll(m => m.ShopID != FspId.ShopID);
            }
            var list = JsonConvert.SerializeObject(new { data = spl }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });
            return Content(list, "application/json");
        }
        public ActionResult ShopTransferReceive()
        {
            if (!IsPermissionApply("StockReport", "ShopTransferReceive"))
            {
                return RedirectToAction("Index", "Home");
            }
            // login as CS
            string ShopID = GetLogedInInfo().ShopID;
            ViewBag.LogedInShopID = ShopID;
            if (ShopID == "9999")
            {
                List<ShopList> Fspl = new List<ShopList>();
                List<ShopList> Tspl = new List<ShopList>();
                Fspl = _shopListService.Gets().ToList();
                Tspl = _shopListService.Gets().ToList(); ;
                ShopList spId = new ShopList();
                spId.ShopID = "";
                spId.ShopName = "All";
                Fspl.Insert(0, spId);
                Tspl.Insert(0, spId);
                ShopList cs = new ShopList();
                cs = Fspl.Find(m => m.ShopID == "9999");
                Fspl.Remove(cs);
                ViewBag.FShopList = new SelectList(Fspl, "ShopID", "ShopName");
                ViewBag.TShopList = new SelectList(Tspl, "ShopID", "ShopName");
            }
            else
            {
                // login as shop
                List<ShopList> Fspl = new List<ShopList>();
                List<ShopList> Tspl = new List<ShopList>();
                Fspl = _shopListService.Gets().ToList();
                Tspl = _shopListService.Gets().ToList();

                //Transfer from
                ShopList spId = new ShopList();
                spId.ShopID = "";
                spId.ShopName = "All";
                Fspl.Insert(0, spId);
                ShopList FspId = Fspl.Find(m => m.ShopID == "9999");
                Fspl.Remove(FspId);
                ShopList FspId2 = Fspl.Find(m => m.ShopID == ShopID);
                Fspl.Remove(FspId2);
                ViewBag.FShopList = new SelectList(Fspl, "ShopID", "ShopName");

                //to
                Tspl.RemoveAll(m => m.ShopID != ShopID);
                ViewBag.TShopList = new SelectList(Tspl, "ShopID", "ShopName");
            }

            List<Supplier> supl = _supplierService.Gets().ToList();
            Supplier sp = new Supplier();
            sp.SupID = "";
            sp.Supname = "All";
            supl.Insert(0, sp);
            ViewBag.SupplierList = new SelectList(supl, "SupID", "Supname");

            //Group
            List<PGroup> grouplist = _groupService.Gets().ToList();
            PGroup group = new PGroup();
            group.GroupID = "";
            group.GroupName = "All";
            grouplist.Insert(0, group);
            ViewBag.PGroupList = new SelectList(grouplist, "GroupID", "GroupName");

            //Product
            List<Product> prdlist = new List<Product>();
            Product prd = new Product();
            prd.PrdID = "";
            prd.PrdName = "All";
            prdlist.Insert(0, prd);
            ViewBag.ProductList = new SelectList(prdlist, "PrdID", "PrdName");

            //Brand Type
            List<BrandType> btList = _brandTypeService.Gets().ToList();
            BrandType bt = new BrandType();
            bt.BTID = "";
            bt.BTName = "All";
            btList.Insert(0, bt);
            ViewBag.BrandTypeList = new SelectList(btList, "BTID", "BTName");

            // Style Size
            List<StyleSize> sslist = new List<StyleSize>();
            StyleSize ss = new StyleSize();
            ss.SSID = "";
            ss.SSName = "All";
            sslist.Insert(0, ss);
            ViewBag.StyleSizeList = new SelectList(sslist, "SSID", "SSName");

            return View();
        }
        public ActionResult DamagedLostReport()
        {
            if (!IsPermissionApply("StockReport", "DamagedLostReport"))
            {
                return RedirectToAction("Index", "Home");
            }
            // login as CS
            string ShopID = GetLogedInInfo().ShopID;
            ViewBag.LogedInShopID = ShopID;
            if (ShopID == "9999")
            {
                List<ShopList> spl = _shopListService.Gets().ToList();
                List<ShopList> spId = spl.FindAll(m => m.ShopID == "9999");

                ViewBag.ShopList = new SelectList(spId, "ShopID", "ShopName");
            }

            List<Supplier> supl = _supplierService.Gets().ToList();
            Supplier sp = new Supplier();
            sp.SupID = "";
            sp.Supname = "All";
            supl.Insert(0, sp);
            ViewBag.SupplierList = new SelectList(supl, "SupID", "Supname");

            //Group
            List<PGroup> grouplist = _groupService.Gets().ToList();
            PGroup group = new PGroup();
            group.GroupID = "";
            group.GroupName = "All";
            grouplist.Insert(0, group);
            ViewBag.PGroupList = new SelectList(grouplist, "GroupID", "GroupName");

            //Product
            List<Product> prdlist = new List<Product>();
            Product prd = new Product();
            prd.PrdID = "";
            prd.PrdName = "All";
            prdlist.Insert(0, prd);
            ViewBag.ProductList = new SelectList(prdlist, "PrdID", "PrdName");

            //Brand Type
            List<BrandType> btList = _brandTypeService.Gets().ToList();
            BrandType bt = new BrandType();
            bt.BTID = "";
            bt.BTName = "All";
            btList.Insert(0, bt);
            ViewBag.BrandTypeList = new SelectList(btList, "BTID", "BTName");

            // Style Size
            List<StyleSize> sslist = new List<StyleSize>();
            StyleSize ss = new StyleSize();
            ss.SSID = "";
            ss.SSName = "All";
            sslist.Insert(0, ss);
            ViewBag.StyleSizeList = new SelectList(sslist, "SSID", "SSName");

            return View();
        }
        public ActionResult ReturnToSupplierReport()
        {
            if (!IsPermissionApply("StockReport", "ReturnToSupplierReport"))
            {
                return RedirectToAction("Index", "Home");
            }
            // login as CS
            string ShopID = GetLogedInInfo().ShopID;
            ViewBag.LogedInShopID = ShopID;
            if (ShopID == "9999")
            {
                List<ShopList> spl = _shopListService.Gets().ToList();
                List<ShopList> spId = spl.FindAll(m => m.ShopID == "9999");

                ViewBag.ShopList = new SelectList(spId, "ShopID", "ShopName");
            }

            List<Supplier> supl = _supplierService.Gets().ToList();
            Supplier sp = new Supplier();
            sp.SupID = "";
            sp.Supname = "All";
            supl.Insert(0, sp);
            ViewBag.SupplierList = new SelectList(supl, "SupID", "Supname");

            //Group
            List<PGroup> grouplist = _groupService.Gets().ToList();
            PGroup group = new PGroup();
            group.GroupID = "";
            group.GroupName = "All";
            grouplist.Insert(0, group);
            ViewBag.PGroupList = new SelectList(grouplist, "GroupID", "GroupName");

            //Product
            List<Product> prdlist = new List<Product>();
            Product prd = new Product();
            prd.PrdID = "";
            prd.PrdName = "All";
            prdlist.Insert(0, prd);
            ViewBag.ProductList = new SelectList(prdlist, "PrdID", "PrdName");

            //Brand Type
            List<BrandType> btList = _brandTypeService.Gets().ToList();
            BrandType bt = new BrandType();
            bt.BTID = "";
            bt.BTName = "All";
            btList.Insert(0, bt);
            ViewBag.BrandTypeList = new SelectList(btList, "BTID", "BTName");

            // Style Size
            List<StyleSize> sslist = new List<StyleSize>();
            StyleSize ss = new StyleSize();
            ss.SSID = "";
            ss.SSName = "All";
            sslist.Insert(0, ss);
            ViewBag.StyleSizeList = new SelectList(sslist, "SSID", "SSName");

            return View();
        }
        public ActionResult ShopRequisitionReport()
        {
            if (!IsPermissionApply("StockReport", "ShopRequisitionReport"))
            {
                return RedirectToAction("Index", "Home");
            }
            // login as CS
            string ShopID = GetLogedInInfo().ShopID;
            ViewBag.LogedInShopID = ShopID;
            if (ShopID == "9999")
            {
                List<ShopList> spl = new List<ShopList>();
                ShopList spId = new ShopList();
                spl = _shopListService.Gets().ToList();
                ShopList find = new ShopList();
                find = spl.Find(m => m.ShopID == "9999");
                spl.Remove(find);
                spId.ShopID = "";
                spId.ShopName = "All";
                spl.Insert(0, spId);
                ViewBag.ShopList = new SelectList(spl, "ShopID", "ShopName");
            }
            else
            {
                // login as shop
                List<ShopList> Fspl = new List<ShopList>();
                List<ShopList> spl = new List<ShopList>();
                Fspl = _shopListService.Gets().ToList();
                ShopList cs = new ShopList();
                cs = Fspl.Find(m => m.ShopID == ShopID);
                spl.Add(cs);
                ViewBag.ShopList = new SelectList(spl, "ShopID", "ShopName");
            }


            //supplier
            List<Supplier> supl = _supplierService.Gets().ToList();
            Supplier sp = new Supplier();
            sp.SupID = "";
            sp.Supname = "All";
            supl.Insert(0, sp);
            ViewBag.SupplierList = new SelectList(supl, "SupID", "Supname");

            //Group
            List<PGroup> grouplist = _groupService.Gets().ToList();
            PGroup group = new PGroup();
            group.GroupID = "";
            group.GroupName = "All";
            grouplist.Insert(0, group);
            ViewBag.PGroupList = new SelectList(grouplist, "GroupID", "GroupName");

            //Product
            List<Product> prdlist = new List<Product>();
            Product prd = new Product();
            prd.PrdID = "";
            prd.PrdName = "All";
            prdlist.Insert(0, prd);
            ViewBag.ProductList = new SelectList(prdlist, "PrdID", "PrdName");

            //Brand Type
            List<BrandType> btList = _brandTypeService.Gets().ToList();
            BrandType bt = new BrandType();
            bt.BTID = "";
            bt.BTName = "All";
            btList.Insert(0, bt);
            ViewBag.BrandTypeList = new SelectList(btList, "BTID", "BTName");

            // Style Size
            List<StyleSize> sslist = new List<StyleSize>();
            StyleSize ss = new StyleSize();
            ss.SSID = "";
            ss.SSName = "All";
            sslist.Insert(0, ss);
            ViewBag.StyleSizeList = new SelectList(sslist, "SSID", "SSName");

            return View();
        }
       
        public ActionResult CircularDiscountReport()
        {
            if (!IsPermissionApply("StockReport", "CircularDiscountReport"))
            {
                return RedirectToAction("Index", "Home");
            }
            List<CircularDiscount> oList = CircularDiscounts(DateTime.Now.ToShortDateString(), DateTime.Now.ToShortDateString(), "Active");

            ViewBag.CDNoList = new SelectList(oList, "CDNo", "CDNo");
            return View();
        }
        public ActionResult CirdisDateRangeStatus(string sDate, string eDate, string Status)
        {
            List<CircularDiscount> oList = CircularDiscounts(sDate, eDate, Status);
            oList = oList.DistinctBy(m => m.CDNo).ToList();
            var list = JsonConvert.SerializeObject(new { data = oList }, Formatting.None,
                    new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                    );

            return Content(list, "application/json");
        }
        private List<CircularDiscount> CircularDiscounts(string sDate, string eDate, string Status)
        {
            List<CircularDiscount> oList = new List<CircularDiscount>();
            DataTable dt = _circularDiscountService.GetDateRangeStatus(sDate, eDate, Status);

            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    CircularDiscount o = new CircularDiscount();
                    o.CDNo = dr["CDNo"].ToString();
                    o.CDName = dr["CDNo"].ToString() +"-"+ dr["CDName"].ToString();
                    o.EffectiveDate = Convert.ToDateTime(dr["EffectiveDate"].ToString());
                    o.ExpireDate = Convert.ToDateTime(dr["ExpireDate"].ToString());
                    oList.Add(o);
                }
            }
            oList = oList.DistinctBy(m => m.CDNo).ToList();
            return oList;
        }

        public ActionResult PackageReport()
        {
            if (!IsPermissionApply("StockReport", "PackageReport"))
            {
                return RedirectToAction("Index", "Home");
            }
            List<Package> oList = PackageOList(DateTime.Now.ToShortDateString(), DateTime.Now.ToShortDateString(), "Active");
            oList = oList.DistinctBy(m => m.PackageNo).ToList();
            ViewBag.PackageList = new SelectList(oList, "PackageNo", "PName");
            return View();
        }
        public ActionResult PackageDateRangeStatus(string sDate, string eDate, string Status)
        {
            List<Package> oList = PackageOList(sDate, eDate, Status);

            var list = JsonConvert.SerializeObject(new { data = oList }, Formatting.None,
                    new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                    );

            return Content(list, "application/json");
        }
        private List<Package> PackageOList(string sDate, string eDate, string Status)
        {
            List<Package> oList = new List<Package>();
            DataTable dt = _packageService.GetDateRangeStatus(sDate, eDate, Status);

            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    Package o = new Package();
                    o.PackageNo = dr["PackageNo"].ToString();
                    o.PName = dr["PackageNo"].ToString()+"-"+dr["PName"].ToString();
                    o.StartDate = Convert.ToDateTime(dr["StartDate"].ToString());
                    o.EndDate = Convert.ToDateTime(dr["EndDate"].ToString());
                    oList.Add(o);
                }
            }
            oList = oList.DistinctBy(m => m.PackageNo).ToList();
            return oList;
        }

        public ActionResult CircularPriceChangedReport()
        {
            if (!IsPermissionApply("StockReport", "CircularPriceChangedReport"))
            {
                return RedirectToAction("Index", "Home");
            }
            List<CircularPriceChanged> oList = CPCOList("Y");
            oList = oList.DistinctBy(m => m.CPCNo).ToList();
            ViewBag.CPCNoList = new SelectList(oList, "CPCNo", "CPCName");
            return View();
        }
        public ActionResult CPCDateRangeStatus(string Status)
        {
            List<CircularPriceChanged> oList = CPCOList(Status);

            var list = JsonConvert.SerializeObject(new { data = oList }, Formatting.None,
                    new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                    );

            return Content(list, "application/json");
        }
        private List<CircularPriceChanged> CPCOList(string Status)
        {
            List<CircularPriceChanged> oList = new List<CircularPriceChanged>();
            DataTable dt = _circularPriceChangedService.GetDateRangeStatus(Status);

            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    CircularPriceChanged o = new CircularPriceChanged();
                    o.CPCNo = dr["CPCNo"].ToString();
                    o.CPCName = dr["CPCNo"].ToString() + "-" + dr["CPCName"].ToString();
                    o.EffectiveDate = Convert.ToDateTime(dr["EffectiveDate"].ToString());
                    oList.Add(o);
                }
            }
            oList = oList.DistinctBy(m => m.CPCNo).ToList();
            return oList;
        }

        public ActionResult PromotionReport()
        {
            if (!IsPermissionApply("StockReport", "PromotionReport"))
            {
                return RedirectToAction("Index", "Home");
            }
            List<BuyAndGet> oList = PromotoinOList(DateTime.Now.ToShortDateString(), DateTime.Now.ToShortDateString(), "Active");
            oList = oList.DistinctBy(m => m.BuyGetNo).ToList();
            ViewBag.PromotionList = new SelectList(oList, "BuyGetNo", "BuyGetName");
            return View();
        }
        public ActionResult PromotoinDateRangeStatus(string sDate, string eDate, string Status)
        {
            List<BuyAndGet> oList = PromotoinOList(sDate, eDate, Status);

            var list = JsonConvert.SerializeObject(new { data = oList }, Formatting.None,
                    new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                    );

            return Content(list, "application/json");
        }
        private List<BuyAndGet> PromotoinOList(string sDate, string eDate, string Status)
        {
            List<BuyAndGet> oList = new List<BuyAndGet>();
            DataTable dt = _buyAndGetService.GetDateRangeStatus(sDate, eDate, Status);

            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    BuyAndGet o = new BuyAndGet();
                    o.BuyGetNo = dr["BuyGetNo"].ToString();
                    o.BuyGetName = dr["BuyGetNo"].ToString() + "-" + dr["BuyGetName"].ToString();
                    o.StartDate = Convert.ToDateTime(dr["StartDate"].ToString());
                    o.EndDate = Convert.ToDateTime(dr["EndDate"].ToString());
                    oList.Add(o);
                }
            }
            oList = oList.DistinctBy(m => m.BuyGetNo).ToList();
            return oList;
        }

        public ActionResult PayLessReport()
        {
            if (!IsPermissionApply("StockReport", "PayLessReport"))
            {
                return RedirectToAction("Index", "Home");
            }
            List<PayLess> oList = PayLessOList(DateTime.Now.ToShortDateString(), DateTime.Now.ToShortDateString(), "Active");
            oList = oList.DistinctBy(m => m.PayLessNo).ToList();
            ViewBag.PayLessList = new SelectList(oList, "PayLessNo", "PayLessName");
            return View();
        }
        public ActionResult PayLessDateRangeStatus(string sDate, string eDate, string Status)
        {
            List<PayLess> oList = PayLessOList(sDate, eDate, Status);

            var list = JsonConvert.SerializeObject(new { data = oList }, Formatting.None,
                    new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                    );

            return Content(list, "application/json");
        }
        private List<PayLess> PayLessOList(string sDate, string eDate, string Status)
        {
            List<PayLess> oList = new List<PayLess>();
            DataTable dt = _payLessService.GetDateRangeStatus(sDate, eDate, Status);

            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    PayLess o = new PayLess();
                    o.PayLessNo = dr["PayLessNo"].ToString();
                    o.PayLessName = dr["PayLessNo"].ToString() + "-" + dr["PayLessName"].ToString();
                    o.StartDate = Convert.ToDateTime(dr["StartDate"].ToString());
                    o.EndDate = Convert.ToDateTime(dr["EndDate"].ToString());
                    oList.Add(o);
                }
            }
            oList = oList.DistinctBy(m => m.PayLessNo).ToList();
            return oList;
        }

        public ActionResult PackageIssueReport()
        {
            if (!IsPermissionApply("StockReport", "PackageIssueReport"))
            {
                return RedirectToAction("Index", "Home");
            }
            List<ShopList> spl = new List<ShopList>();
            ShopList spId = new ShopList();
            spl = _shopListService.Gets().ToList();
            ShopList find = new ShopList();
            find = spl.Find(m => m.ShopID == "9999");
            spl.Remove(find);
            spId.ShopID = "";
            spId.ShopName = "All";
            spl.Insert(0, spId);
            ViewBag.ShopList = new SelectList(spl, "ShopID", "ShopName");
            List<PackageIssue> oList = PackageIssueGet(DateTime.Now.ToShortDateString(), DateTime.Now.AddDays(7).ToShortTimeString(), "All");
            
            ViewBag.PackageIssueList = new SelectList(oList, "PIssueNo", "PIssueNo");
            return View();
        }
        private List<PackageIssue> PackageIssueGet(string FromDate, string ToDate, string ShopID)
        {
            DataTable dt = _packageIssueService.PackageDateRangeShopID(FromDate, ToDate, ShopID);
            List<PackageIssue> oList = new List<PackageIssue>();
            if (dt.Rows.Count > 0)
            { 
                foreach (DataRow dr in dt.Rows)
                {
                    PackageIssue obj = new PackageIssue();
                    obj.PIssueNo = dr["PIssueNo"].ToString();
                    oList.Add(obj);
                }
            }
            oList = oList.DistinctBy(m => m.PIssueNo).ToList();
            return oList;
        }
        public ActionResult PackageIssueDateRangeStatus(string sDate, string eDate, string ShopID)
        {
            List<PackageIssue> oList = PackageIssueGet(sDate, eDate, ShopID);

            var list = JsonConvert.SerializeObject(new { data = oList }, Formatting.None,
                    new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                    );

            return Content(list, "application/json");
        }

        public ActionResult PackageIssueReceiveReport()
        {
            if (!IsPermissionApply("StockReport", "PackageIssueReceiveReport"))
            {
                return RedirectToAction("Index", "Home");
            }
            List<PackageIssue> oList = PackageIssueReceiveGet(DateTime.Now.ToShortDateString(), DateTime.Now.AddDays(7).ToShortTimeString(), GetLogedInInfo().ShopID);

            ViewBag.PackageIssueList = new SelectList(oList, "PIssueNo", "PIssueNo");
            return View();
        }
        private List<PackageIssue> PackageIssueReceiveGet(string FromDate, string ToDate, string ShopID)
        {
            DataTable dt = _packageIssueService.PackageReceiveDateRangeShopID(FromDate, ToDate, ShopID);
            List<PackageIssue> oList = new List<PackageIssue>();
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    PackageIssue obj = new PackageIssue();
                    obj.PIssueNo = dr["PIssueNo"].ToString();
                    oList.Add(obj);
                }
            }
            oList = oList.DistinctBy(m => m.PIssueNo).ToList();
            return oList;
        }
        public ActionResult PackageIssueReceiveDateRangeStatus(string sDate, string eDate)
        {
            List<PackageIssue> oList = PackageIssueReceiveGet(sDate, eDate, GetLogedInInfo().ShopID);

            var list = JsonConvert.SerializeObject(new { data = oList }, Formatting.None,
                    new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                    );

            return Content(list, "application/json");
        }

        #region ==== Menu Permission Check =====
        private bool IsPermissionApply(string Controller, string ActionName)
        {
            List<MenuURLViewModel> lstMenus = null;
            if (Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.SessionMenu] == null)
            {
                lstMenus = new GlobalClass().GetMenuByUserName(User.Identity.Name);
                Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.SessionMenu] = lstMenus;
            }
            else
            {
                lstMenus =
                    Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.SessionMenu] as
                        List<MenuURLViewModel>;
            }
            MenuURLViewModel menu = lstMenus.FindAll(m => m.Controller == Controller && m.ActionName == ActionName).FirstOrDefault();
            if (menu != null)
                return true;
            else
                return false;
        }
        #endregion
    }
}