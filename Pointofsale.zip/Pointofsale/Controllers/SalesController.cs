﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI;
using Microsoft.Ajax.Utilities;
using Newtonsoft.Json;
using RetailMaster.POS.Data;
using RetailMaster.POS.Models;
using RetailMaster.POS.Service;
using RetailMaster.POS.Web.BLL;
using RetailMaster.POS.Web.Models;
using RetailMaster.POS.Web.ViewModels;

namespace RetailMaster.POS.Web.Controllers
{
    public class SalesController : Controller
    {
        private readonly ISalesManService _salesManService;
        private readonly ICreditCardService _creditCardService;
        private readonly ISaleService _saleService;
        private readonly ITempSalesVoidService _tempsalevoidService;
        private readonly ICustomerMstService _customerMstService;
        private readonly ITempSalesService _tempSalesService;
        private readonly IBuyService _buyService;
        private readonly ITempSalesHoldService _stTempSalesHoldService;
        private readonly ISsummaryService _ssummaryService;
        private readonly IPackageIssueService _servicePackageIssue;
        private readonly IPackageService _servicePackage;
        private readonly ICircularDiscountDetailService _serviceCircularDiscount;
        private readonly ICustomerLedgerService _customerLedger;
        public SalesController(IBuyService ibuyService, ISalesManService salesManService, ICreditCardService creditCardService, ISaleService saleService,
            ICustomerMstService customerMstService, ITempSalesService tempSalesService, ITempSalesHoldService stTempSalesHoldService,
            ISsummaryService ssummaryService, IPackageIssueService servicePackageIssue, IPackageService servicePackage, ICircularDiscountDetailService serviceCircularDiscount
            , ICustomerLedgerService customerLedger, ITempSalesVoidService tempsalevoidService)
        {
            this._buyService = ibuyService;
            this._salesManService = salesManService;
            this._creditCardService = creditCardService;
            this._saleService = saleService;
            this._customerMstService = customerMstService;
            this._tempSalesService = tempSalesService;
            this._stTempSalesHoldService = stTempSalesHoldService;
            this._ssummaryService = ssummaryService;
            this._servicePackageIssue = servicePackageIssue;
            this._servicePackage = servicePackage;
            this._serviceCircularDiscount = serviceCircularDiscount;
            this._customerLedger = customerLedger;
            this._tempsalevoidService = tempsalevoidService;
        }

        #region ==== Sales ====
        private LogedInInfo GetLogedInInfo()
        {
            LogedInInfo info = new LogedInInfo();
            if (HttpContext.Request.Cookies["POSLogedInInfo"] != null)
            {
                HttpCookie cookie = HttpContext.Request.Cookies.Get("POSLogedInInfo");
                info = Newtonsoft.Json.JsonConvert.DeserializeObject<LogedInInfo>(cookie.Value) as LogedInInfo;
            }
            return info;
        }
        private GlobalSetup getGlobalSetup()
        {
            GlobalSetup info = new GlobalSetup();
            if (HttpContext.Request.Cookies["globalSetup"] != null)
            {
                HttpCookie cookie = HttpContext.Request.Cookies.Get("globalSetup");
                info = Newtonsoft.Json.JsonConvert.DeserializeObject<GlobalSetup>(cookie.Value) as GlobalSetup;
            }
            return info;
        }
        public ActionResult Sale()
        {
            if (!IsPermissionApply("Sales", "Sale"))
            {
                return RedirectToAction("Index", "Home");
            }

            List<CreditCardList> dl = _creditCardService.Gets().ToList();
            CreditCardList find = dl.FindAll(m => m.CardName == "Partial-Credit").FirstOrDefault();
            dl.Remove(find);
            find = dl.FindAll(m => m.CardName == "Full-Credit").FirstOrDefault();
            dl.Remove(find);

            ViewBag.PaymentType = new SelectList(dl, "slno", "CardName");
            ViewBag.hdnAllowMultiScan = getGlobalSetup().AllowMultiScan;
            ViewBag.ShopIDInfo = GetLogedInInfo().ShopName;
            ViewBag.CounterIDInfo = GetLogedInInfo().CounterID;
            // ViewBag.VAT = getGlobalSetup().VAT;
            return View();
        }

        public ActionResult SalesGetPaymentType(string IsCreditAllowed)
        {
            List<CreditCardList> dl = _creditCardService.Gets().ToList();
            if (IsCreditAllowed == "N")
            {
                CreditCardList find = dl.FindAll(m => m.CardName == "Partial-Credit").FirstOrDefault();
                dl.Remove(find);
                find = dl.FindAll(m => m.CardName == "Full-Credit").FirstOrDefault();
                dl.Remove(find);
            }
            var list = JsonConvert.SerializeObject(new { data = dl }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        public ActionResult SalesGetStockListByShopID()
        {
            string ShopID = GetLogedInInfo().ShopID;
            DataTable dt = _saleService.GetShopItem(ShopID);

            var list = JsonConvert.SerializeObject(new { data = dt }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }
        public ActionResult SalesGetStockByShopIDBarCode(string BarCode)
        {
            string ShopID = GetLogedInInfo().ShopID;
            string BalanceaAllowNil = getGlobalSetup().ALLOWBNL;
            DataTable dt = _saleService.GetStockByBarCodeShopID(BarCode, ShopID);
            if (dt.Rows.Count > 0)
            {
                decimal temp = 0;
                decimal.TryParse(dt.Rows[0]["balQty"].ToString(), out temp);
                decimal balQty = temp;
                if (balQty > 0 || BalanceaAllowNil == "Y") // allow balance nil
                {
                    var listin = JsonConvert.SerializeObject(new { data = dt }, Formatting.None,
                        new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                        );
                    return Content(listin, "application/json");
                }
            }
            var list = JsonConvert.SerializeObject(new { data = "Error" }, Formatting.None,
                    new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                    );

            return Content(list, "application/json");
        }
        public ActionResult SalesGetCustomerInfoByID(string CusID)
        {
            CustomerMst cus = _customerMstService.GetByCusID(CusID);
            var list = JsonConvert.SerializeObject(new { data = cus }, Formatting.None,
                    new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                    );

            return Content(list, "application/json");
        }
        public ActionResult SalesGetCustomerInfoByPhone(string CusPhone)
        {
            CustomerMst cus = _customerMstService.GetByCusPhone(CusPhone);
            var list = JsonConvert.SerializeObject(new { data = cus }, Formatting.None,
                    new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                    );

            return Content(list, "application/json");
        }
        public ActionResult SalesGetSMBySMID(string SMID)
        {
            string ShopID = GetLogedInInfo().ShopID;
            List<SalesMan> smList = _salesManService.GetByShopId(ShopID).ToList();
            SalesMan sm = smList.Find(m => m.SMID == SMID);
            var list = JsonConvert.SerializeObject(new { data = sm }, Formatting.None,
                    new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                    );

            return Content(list, "application/json");
        }
        public ActionResult SalesCreateTempSale(TempSale model)
        {
            try
            {
                string ShopID = GetLogedInInfo().ShopID;
                string CounterID = GetLogedInInfo().CounterID;
                string BalanceaAllowNil = getGlobalSetup().ALLOWBNL;
                Buy SelectedItem = _buyService.GetProductInfoByBarcode(model.Barcode, ShopID);

                TempSale otemp = null;

                if (SelectedItem == null)
                {

                    #region try to parse and add package

                    PackageIssue package = _servicePackageIssue.FindByBarcode(model.Barcode);

                    if (package == null)
                    {
                        return Json(new { result = false, Error = "Product Info Not found" }, JsonRequestBehavior.AllowGet);
                    }

                    if (package.balPQty <= 0 && BalanceaAllowNil == "N") // allow balance nil sale
                    {
                        return Json(new { result = false, Error = "Package stock not available" }, JsonRequestBehavior.AllowGet);
                    }

                    if (getGlobalSetup().AllowMultiScan == "N")
                        model.Sqty = 1;

                    List<Package> packageDetails = _servicePackage.Gets(model.Barcode).ToList();
                    //txtDescription.Text
                    string Pack_Description = packageDetails[0].PName;
                    // txtStockQty.Text 
                    decimal Pack_StockQty = Convert.ToDecimal(package.balPQty);
                    //  txtRate.Text 
                    decimal Pack_Rate = Convert.ToDecimal(packageDetails[0].PackagePrice);

                    otemp = new TempSale();

                    otemp.AttendentId = model.AttendentId;
                    otemp.AttendentName = model.AttendentName;
                    otemp.Barcode = model.Barcode;
                    otemp.CounterId = CounterID; //StaticData.CounterId;
                    otemp.CustomerName = model.CustomerName;
                    otemp.PrvCusID = model.PrvCusID;
                    otemp.CustomerMobile = model.CustomerMobile;
                    otemp.EQty = 0;
                    otemp.RPU = Pack_Rate;
                    otemp.CPU = 0;
                    otemp.IsFree = "N";
                    otemp.UserId = User.Identity.Name;

                    #region circular discoount
                    otemp.DiscountPrd = 0;
                    otemp.DiscountPer = 0;
                    otemp.isCircularDiscount = "N";
                    #endregion

                    otemp.VatPer = packageDetails[0].VATPrcen; //
                    otemp.VatPrd = 0; // calculate on sale

                    otemp.Rqty = 0;
                    otemp.SBarocde = model.SBarocde;
                    otemp.ShopId = ShopID;
                    otemp.Sqty = Convert.ToInt32(model.Sqty);
                    otemp.Total = otemp.Sqty * otemp.RPU;
                    otemp.UserId = User.Identity.Name;
                    otemp.ProdcutDescription = Pack_Description;

                    _tempSalesService.CreateUpdate(otemp);
                    _tempSalesService.Save();

                    //CalculateRightSideData();

                    #endregion

                    return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
                }

                //LoadProductInfo();

                if (getGlobalSetup().AllowMultiScan == "N")
                    model.Sqty = 1;

                CircularDiscountDetail circularDiscount = _serviceCircularDiscount.GetCircularDiscountByItemWise(model.Barcode, DateTime.Now);

                if (SelectedItem.balQty <= 0 && BalanceaAllowNil == "N") // allow balance nil sale
                {
                    return Json(new { result = false, Error = "Stock Not available" }, JsonRequestBehavior.AllowGet);
                }

                otemp = new TempSale();

                otemp.AttendentId = model.AttendentId;
                otemp.AttendentName = model.AttendentName;
                otemp.Barcode = model.Barcode;
                otemp.CounterId = CounterID; //StaticData.CounterId;
                otemp.CustomerName = model.CustomerName;
                otemp.PrvCusID = model.PrvCusID;
                otemp.CustomerMobile = model.CustomerMobile;
                otemp.EQty = 0;
                otemp.RPU = Convert.ToDecimal(SelectedItem.RPU);
                otemp.CPU = SelectedItem.CPU;
                otemp.IsFree = "N";
                otemp.UserId = User.Identity.Name;

                #region circular discoount
                if (circularDiscount != null)
                {
                    otemp.DiscountPrd = circularDiscount.DiscountAmount;
                    otemp.DiscountPer = circularDiscount.DiscountPrcnt;
                    otemp.isCircularDiscount = "Y";
                }
                else
                {
                    otemp.DiscountPrd = 0;
                    otemp.DiscountPer = 0;
                    otemp.isCircularDiscount = "N";
                }
                #endregion

                otemp.VatPer = SelectedItem.VATPrcnt;
                otemp.VatPrd = 0; // will be calculate before final save

                otemp.Rqty = 0;
                otemp.SBarocde = SelectedItem.sBarCode;
                otemp.ShopId = ShopID;
                otemp.Sqty = Convert.ToInt32(model.Sqty);
                otemp.Total = otemp.Sqty * otemp.RPU;
                otemp.UserId = User.Identity.Name;
                otemp.ProdcutDescription = SelectedItem.ProductDescription;


                _tempSalesService.CreateUpdate(otemp);
                _tempSalesService.Save();
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }
        public ActionResult SalesTempList()
        {
            string ShopID = GetLogedInInfo().ShopID;
            string CounterID = GetLogedInInfo().CounterID;
            string UserID = User.Identity.Name;
            List<TempSale> tempSales = _tempSalesService.GetTempDataByUser(ShopID, CounterID, UserID);
            var list = JsonConvert.SerializeObject(new { data = tempSales }, Formatting.None,
                    new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                    );

            return Content(list, "application/json");
        }
        public ActionResult SalesGetShopStockByBarCode(string BarCode)
        {
            string ShopID = GetLogedInInfo().ShopID;
            DataTable dt = _saleService.GetStockByBarCodeShopID(BarCode, ShopID);
            var list = JsonConvert.SerializeObject(new { data = dt }, Formatting.None,
                   new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                   );
            return Content(list, "application/json");
        }
        public ActionResult SalesDeleteTempSales(decimal TempSalesId)
        {
            _tempSalesService.RemoveTempId(TempSalesId);
            _tempSalesService.Save();


            var list = JsonConvert.SerializeObject(new { data = "Deleted" }, Formatting.None,
                   new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                   );

            return Content(list, "application/json");
        }
        public ActionResult SalesUpdateQty(decimal TempSalesId, decimal newQty)
        {
            try
            {
                TempSale s = _tempSalesService.GetByTempId(TempSalesId);
                if (s == null)
                {
                    var l = JsonConvert.SerializeObject(new { Result = false, Error = "Product not found." }, Formatting.None,
                      new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                      );

                    return Content(l, "application/json");
                }

                TempSale otemp = new TempSale();
                otemp.Barcode = s.Barcode;
                otemp.SBarocde = s.SBarocde;
                otemp.Sqty = s.Sqty;

                int currentQty = otemp.Sqty.Value;
                if (otemp.Sqty == 0)
                {
                    return Json(new { result = false, Error = "Exchange product cannot be update" }, JsonRequestBehavior.AllowGet);
                }
                otemp.Rqty = 0;
                otemp.EQty = 0;
                otemp.Sqty = int.Parse(newQty.ToString());


                #region checking.....
                Buy SelectedItem = _buyService.GetProductInfoByBarcode(otemp.Barcode, GetLogedInInfo().ShopID);
                if (SelectedItem != null)
                {
                    if (otemp.Sqty > (SelectedItem.balQty + currentQty))
                    {
                        return Json(new { result = false, Error = "Stock not available" }, JsonRequestBehavior.AllowGet);
                    }
                }

                PackageIssue package = _servicePackageIssue.FindByBarcode(s.Barcode);
                if (package != null)
                {
                    if (otemp.Sqty > (package.balPQty + currentQty))
                    {
                        return Json(new { result = false, Error = "Package stock not available" }, JsonRequestBehavior.AllowGet);
                    }
                }
                #endregion

                otemp.CounterId = GetLogedInInfo().CounterID;
                otemp.ShopId = GetLogedInInfo().ShopID;
                otemp.UserId = User.Identity.Name;

                _tempSalesService.Update(otemp);
                _tempSalesService.Save();

                var list = JsonConvert.SerializeObject(new { result = true, data = "SQty Updated" }, Formatting.None,
                       new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                       );

                return Content(list, "application/json");
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }
        public ActionResult SalesInsertIntoHold(Ssummary model)
        {
            try
            {
                string ShopID = GetLogedInInfo().ShopID;
                string CounterID = GetLogedInInfo().CounterID;
                string UserID = User.Identity.Name;
                string prefix = UserID + ShopID;
                string holdNo = new GlobalClass().GetMaxIdWithPrfix("HoldNo", "2", CounterID, "TempSalesHold", prefix);

                _stTempSalesHoldService.HoldInvoice(UserID,
                                            CounterID,
                                            ShopID,
                                            model.AttendentId,
                                            model.Salesman,
                                           model.PrvCusID,
                                            model.CusName,
                                            model.CusMobile,
                                            holdNo);

                _tempSalesService.RemoveAll(ShopID, CounterID, UserID);
                _tempSalesService.Save();

                var list = JsonConvert.SerializeObject(new { result = true, Error = "Saved" }, Formatting.None,
                        new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                        );

                return Content(list, "application/json");
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }
        public ActionResult HoldList()
        {
            string ShopID = GetLogedInInfo().ShopID;
            string CounterID = GetLogedInInfo().CounterID;
            string UserID = User.Identity.Name;
            List<TempSalesHold> olisHold = _stTempSalesHoldService.GetAllHold(UserID, CounterID, ShopID).ToList();

            var list = JsonConvert.SerializeObject(new { data = olisHold }, Formatting.None,
                    new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                    );

            return Content(list, "application/json");
        }
        public ActionResult HoldRecall(string holdno)
        {
            string ShopID = GetLogedInInfo().ShopID;
            string CounterID = GetLogedInInfo().CounterID;
            string UserID = User.Identity.Name;

            _stTempSalesHoldService.RecallInvoice(UserID, CounterID, ShopID, holdno);
            _stTempSalesHoldService.RemoveHold(UserID, CounterID, ShopID, holdno);
            _stTempSalesHoldService.Save();

            var list = JsonConvert.SerializeObject(new { data = "Recalled" }, Formatting.None,
                    new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                    );

            return Content(list, "application/json");
        }
        public ActionResult CalculateRightSideData(string BarCode)
        {
            try
            {
                Boolean btnApplyPromotionEnabled = false;
                Boolean BarcodeEnabled = true;
                string BarcodeText = "";

                string IsVatAfterDiscount = getGlobalSetup().IsVatAfterDiscount;
                string ShopID = GetLogedInInfo().ShopID;
                string CounterID = GetLogedInInfo().CounterID;
                string UserID = User.Identity.Name;
                List<TempSale> tempSales = _tempSalesService.GetTempDataByUser(ShopID, CounterID, UserID);

                List<sp_getPromotionItem> olistPromotion = _tempSalesService.GetPromotionItem(UserID);
                if (olistPromotion.Count == 0)
                {
                    btnApplyPromotionEnabled = false;
                }
                else
                {
                    btnApplyPromotionEnabled = true;
                }

                int totalQty = 0;
                int totalItem = 0;
                decimal totalAmount = 0;
                decimal rTotalAmount = 0;
                bool isCircular = false;
                if (tempSales != null && tempSales.Count > 0)
                {
                    // isDiscPerc = true;
                    // isDiscAmnt = true;

                    #region if ircular discount is applied any product then  discount is disabled

                    foreach (var d in tempSales)
                    {
                        if (d.isCircularDiscount == "Y" && d.Sqty > 0)
                            isCircular = true;
                    }
                    #endregion


                    #region if PromotionApply not more item will be addeed
                    bool PromotionApply = false;
                    foreach (var d in tempSales)
                    {
                        if (d.IsFree == "Y")
                            PromotionApply = true;
                    }
                    if (PromotionApply)
                    {
                        BarcodeEnabled = false;
                        btnApplyPromotionEnabled = false;
                        BarcodeText = "Promotion applied no scan possible";
                    }
                    else
                    {
                        BarcodeEnabled = true;
                        BarcodeText = "";
                    }

                    #endregion

                    foreach (var i in tempSales)
                    {
                        totalQty += i.Sqty.Value;

                        if (i.Sqty.Value > 0 && i.IsFree == "N")
                        {
                            totalAmount += (i.Sqty.Value * i.RPU.Value);
                            totalItem++;
                        }
                        else if (i.Rqty.Value > 0 && i.IsFree == "N")
                        {
                            rTotalAmount += i.Total.Value;
                        }
                    }
                }
                decimal discount = 0;
                decimal vatAmnt = 0;

                decimal rDiscount = 0;
                decimal rVatAmnt = 0;
                decimal netAmount = 0;
                decimal SubTotal = 0;

                // eg. vatAmnt =  ( RPU - Discount) * vatPer
                //  Net = RPU - Discount + VatAmnt
                if (IsVatAfterDiscount == "Y")
                {
                    foreach (TempSale i in tempSales)
                    {
                        decimal tempDiscount = 0;
                        decimal tempVat = 0;
                        if (i.Sqty > 0 && i.IsFree == "N")
                        {
                            tempDiscount = (Convert.ToDecimal(i.Sqty) * Convert.ToDecimal(i.DiscountPrd));

                            tempVat = (((Convert.ToDecimal(i.Sqty) * Convert.ToDecimal(i.RPU)) - tempDiscount) * Convert.ToDecimal(i.VatPer)) / 100;
                            tempVat = decimal.Round(tempVat, 2);

                            discount += tempDiscount;
                            vatAmnt += tempVat;
                        }
                        else if (i.Rqty > 0 && i.IsFree == "N")
                        {
                            tempDiscount = (Convert.ToDecimal(i.Rqty) * Convert.ToDecimal(i.DiscountPrd));

                            tempVat = (Convert.ToDecimal(i.Rqty) * Convert.ToDecimal(i.VatPrd));
                            tempVat = decimal.Round(tempVat, 2);

                            rDiscount += tempDiscount;
                            rVatAmnt += tempVat;
                        }
                    }
                    vatAmnt = Math.Ceiling(vatAmnt);
                    discount = Math.Floor(discount);

                    rVatAmnt = Math.Ceiling(rVatAmnt);
                    rDiscount = Math.Floor(rDiscount);

                    // txtVatAmnt.Text = vatAmnt.ToString("0.0");
                    // txtDiscAmount.Text = discount.ToString("0.0");

                    SubTotal = totalAmount - discount;
                    //txtSubTotal.Text = SubTotal.ToString("0.0");

                    decimal rNetAmnt = rTotalAmount - rDiscount + rVatAmnt;
                    netAmount = (SubTotal + vatAmnt) - rNetAmnt;
                    // NetAmnt = netAmount.ToString("0.0");

                }

                // eg. vatAmnt =  ( RPU ) * vatPer
                //  Net = RPU - Discount + VatAmnt
                else if (IsVatAfterDiscount == "N")
                {
                    foreach (var i in tempSales)
                    {
                        decimal tempVat = 0;
                        decimal tempDiscount = 0;
                        if (i.Sqty > 0 && i.IsFree == "N")
                        {
                            tempVat = ((Convert.ToDecimal(i.Sqty) * Convert.ToDecimal(i.RPU)) * Convert.ToDecimal(i.VatPer)) / 100;
                            tempVat = decimal.Round(tempVat, 2);

                            tempDiscount = (Convert.ToDecimal(i.Sqty.Value) * Convert.ToDecimal(i.DiscountPrd));

                            discount += tempDiscount;
                            vatAmnt += tempVat;
                        }
                        else if (i.Rqty > 0 && i.IsFree == "N")
                        {
                            tempVat = Convert.ToDecimal(i.Rqty) * Convert.ToDecimal(i.VatPrd);
                            tempVat = decimal.Round(tempVat, 2);

                            tempDiscount = (Convert.ToDecimal(i.Rqty) * Convert.ToDecimal(i.DiscountPrd));

                            rDiscount += tempDiscount;
                            rVatAmnt += tempVat;
                        }
                    }

                    //decimal vatAmnt = (SubTotal * StaticData.globalSetup.VAT.Value) / 100;
                    vatAmnt = Math.Ceiling(vatAmnt);
                    discount = Math.Floor(discount);

                    rVatAmnt = Math.Ceiling(rVatAmnt);
                    rDiscount = Math.Floor(rDiscount);

                    // txtVatAmnt.Text = vatAmnt.ToString("0.0");
                    //txtDiscAmount.Text = discount.ToString("0.0");


                    SubTotal = totalAmount + vatAmnt;
                    //txtSubTotal.Text = SubTotal.ToString("0.0");
                    decimal rNetAmnt = rTotalAmount - rDiscount + rVatAmnt;

                    netAmount = SubTotal - discount - rNetAmnt;
                    // txtNetAmount.Text = netAmount.ToString("0.0");
                }

                //   vatAmnt , discount, netAmount,rVatAmnt

                var list = JsonConvert.SerializeObject(new { result = true, TotalPrice = totalAmount, DiscPrc = 0, DiscAmnt = discount, VatAmnt = vatAmnt, NetAmnt = netAmount, isCircular = isCircular, totalQty = totalQty, BarcodeEnabledF = BarcodeEnabled, btnApplyPromotionEnabledF = btnApplyPromotionEnabled, BarcodeTextF = BarcodeText }, Formatting.None,
                        new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                        );
                return Content(list, "application/json");
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }
        public ActionResult DiscAmntTextChanged(string txtDiscAmount, string txtTotalPrice)
        {
            string CounterID = GetLogedInInfo().CounterID;
            string IsVatAfterDiscount = getGlobalSetup().IsVatAfterDiscount;

            decimal DiscAmount = 0;
            decimal totalAmount = 0;
            decimal DiscountPercent = 0;
            totalAmount = decimal.Parse(txtTotalPrice);

            string ShopID = GetLogedInInfo().ShopID;
            string UserID = User.Identity.Name;
            List<TempSale> olis = _tempSalesService.GetTempDataByUser(ShopID, CounterID, UserID);

            decimal discount = decimal.Parse(txtDiscAmount);

            if (discount > totalAmount)
            {
                discount = totalAmount;
                DiscAmount = discount;
            }

            decimal discPercent = (discount * 100) / totalAmount;
            discPercent = decimal.Round(discPercent, 3);
            DiscountPercent = discPercent;

            decimal rTotalAmount = 0;
            decimal netAmount = 0;
            decimal rDiscAmnt = 0;
            decimal rVatAmnt = 0;
            decimal discAmnt = 0;
            decimal vatAmnt = 0;

            // eg. vatAmnt =  ( RPU - Discount) * vatPer
            //  Net = RPU - Discount + VatAmnt
            if (IsVatAfterDiscount == "Y")
            {
                discAmnt = 0;
                vatAmnt = 0;

                rDiscAmnt = 0;
                rVatAmnt = 0;

                foreach (var i in olis)
                {
                    decimal tempDiscount = 0, tempVat = 0;
                    if (i.Sqty > 0 && i.IsFree == "N")
                    {
                        if (i.Barcode.Substring(0, 1) != "P")
                        {
                            tempDiscount = ((i.Sqty.Value * i.RPU.Value) * discPercent) / 100;
                            tempDiscount = decimal.Round(tempDiscount, 2);
                            discAmnt += tempDiscount;
                        }

                        tempVat = (((i.Sqty.Value * i.RPU.Value) - tempDiscount) * i.VatPer.Value) / 100;
                        tempVat = decimal.Round(tempVat, 2);

                        vatAmnt += tempVat;
                    }
                    else if (i.Rqty > 0 && i.IsFree == "N")
                    {
                        tempDiscount = (i.Rqty.Value * i.DiscountPrd.Value);

                        tempVat = (i.Rqty.Value * i.VatPrd.Value);
                        tempVat = decimal.Round(tempVat, 2);

                        rDiscAmnt += tempDiscount;
                        rVatAmnt += tempVat;
                        rTotalAmount += i.Total.Value;
                    }

                }

                discAmnt = Math.Floor(discAmnt);
                vatAmnt = Math.Ceiling(vatAmnt);

                rDiscAmnt = Math.Floor(rDiscAmnt);
                rVatAmnt = Math.Ceiling(rVatAmnt);


                //txtDiscAmount.Text = discAmnt.ToString();
                //txtVatAmnt.Text = vatAmnt.ToString("0.0");


                decimal SubTotal = totalAmount - discAmnt;
                //txtSubTotal.Text = SubTotal.ToString("0.0");

                decimal rNetAmnt = rTotalAmount - rDiscAmnt + rVatAmnt;

                netAmount = SubTotal + vatAmnt - rNetAmnt;
            }
            // eg. vatAmnt =  ( RPU ) * vatPer
            //  Net = RPU - Discount + VatAmnt
            else if (IsVatAfterDiscount == "N")
            {

                discAmnt = 0;
                vatAmnt = 0;

                rDiscAmnt = 0;
                rVatAmnt = 0;

                foreach (var i in olis)
                {

                    decimal tempDiscount = 0, tempVat = 0;
                    if (i.Sqty > 0 && i.IsFree == "N" && i.Barcode.Substring(0, 1) != "P")
                    {
                        tempVat = ((i.Sqty.Value * i.RPU.Value) * i.VatPer.Value) / 100;
                        tempVat = decimal.Round(tempVat, 2);
                        vatAmnt += tempVat;

                        if (i.Barcode.Substring(0, 1) != "P")
                        {
                            tempDiscount = ((i.Sqty.Value * i.RPU.Value) * discPercent) / 100;
                            tempDiscount = decimal.Round(tempDiscount, 2);
                            discAmnt += tempDiscount;
                        }

                    }
                    else if (i.Rqty > 0 && i.IsFree == "N")
                    {
                        tempDiscount = (i.Rqty.Value * i.DiscountPrd.Value);

                        tempVat = (i.Rqty.Value * i.VatPrd.Value);
                        tempVat = decimal.Round(tempVat, 2);

                        rDiscAmnt += tempDiscount;
                        rVatAmnt += tempVat;

                        rTotalAmount += i.Total.Value;
                    }

                }

                discAmnt = Math.Floor(discAmnt);
                vatAmnt = Math.Ceiling(vatAmnt);

                rDiscAmnt = Math.Floor(rDiscAmnt);
                rVatAmnt = Math.Ceiling(rVatAmnt);

                //txtDiscAmount.Text = discAmnt.ToString();
                // txtVatAmnt.Text = vatAmnt.ToString("0.0");


                decimal SubTotal = totalAmount + vatAmnt;
                //txtSubTotal.Text = SubTotal.ToString("0.0");
                decimal rNetAmnt = rTotalAmount - rDiscAmnt + rVatAmnt;
                netAmount = SubTotal - discAmnt - rNetAmnt;
            }
            var list = JsonConvert.SerializeObject(new { result = true, TotalPrice = totalAmount, DiscPrc = discPercent, VatAmnt = vatAmnt, NetAmnt = netAmount }, Formatting.None,
                   new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                   );

            return Content(list, "application/json");
        }
        public ActionResult DiscPrcentTextChanged(string txtDiscountPercent, string txtTotalPrice)
        {
            string IsVatAfterDiscount = getGlobalSetup().IsVatAfterDiscount;
            decimal totalAmount = 0;
            totalAmount = decimal.Parse(txtTotalPrice);

            string ShopID = GetLogedInInfo().ShopID;
            string CounterID = GetLogedInInfo().CounterID;
            string UserID = User.Identity.Name;
            List<TempSale> olis = _tempSalesService.GetTempDataByUser(ShopID, CounterID, UserID);
            decimal rTotalAmount = 0;

            decimal rDiscAmnt = 0;
            decimal rVatAmnt = 0;
            decimal discAmnt = 0;
            decimal vatAmnt = 0;
            decimal netAmount = 0;
            // eg. vatAmnt =  ( RPU - Discount) * vatPer
            //  Net = RPU - Discount + VatAmnt
            if (IsVatAfterDiscount == "Y")
            {
                decimal discPercent;
                discPercent = decimal.Parse(txtDiscountPercent);

                if (discPercent > 100)
                {
                    discPercent = 100;
                }

                discAmnt = 0;
                vatAmnt = 0;

                rDiscAmnt = 0;
                rVatAmnt = 0;

                foreach (var i in olis)
                {
                    decimal tempDiscount = 0, tempVat = 0;
                    if (i.Sqty > 0 && i.IsFree == "N")
                    {
                        if (i.Barcode.Substring(0, 1) != "P")
                        {
                            tempDiscount = ((i.Sqty.Value * i.RPU.Value) * discPercent) / 100;
                            tempDiscount = decimal.Round(tempDiscount, 2);
                            discAmnt += tempDiscount;
                        }

                        tempVat = (((i.Sqty.Value * i.RPU.Value) - tempDiscount) * i.VatPer.Value) / 100;
                        tempVat = decimal.Round(tempVat, 2);

                        vatAmnt += tempVat;
                    }
                    else if (i.Rqty > 0 && i.IsFree == "N")
                    {
                        tempDiscount = (i.Rqty.Value * i.DiscountPrd.Value);

                        tempVat = (i.Rqty.Value * i.VatPrd.Value);
                        tempVat = decimal.Round(tempVat, 2);

                        rDiscAmnt += tempDiscount;
                        rVatAmnt += tempVat;
                        rTotalAmount += i.Total.Value;
                    }
                }

                discAmnt = Math.Floor(discAmnt);
                vatAmnt = Math.Ceiling(vatAmnt);

                rDiscAmnt = Math.Floor(rDiscAmnt);
                rVatAmnt = Math.Ceiling(rVatAmnt);

                // txtDiscAmount.Text = discAmnt.ToString();
                //  txtVatAmnt.Text = vatAmnt.ToString("0.0");


                decimal SubTotal = totalAmount - discAmnt;
                //txtSubTotal.Text = SubTotal.ToString("0.0");

                decimal rNetAmnt = rTotalAmount - rDiscAmnt + rVatAmnt;

                netAmount = SubTotal + vatAmnt - rNetAmnt;
                //txtNetAmount.Text = netAmount.ToString("0.0");
            }
            // eg. vatAmnt =  ( RPU ) * vatPer
            //  Net = RPU - Discount + VatAmnt
            else if (IsVatAfterDiscount == "N")
            {
                decimal discPercent;
                discPercent = decimal.Parse(txtDiscountPercent);

                if (discPercent > 100)
                {
                    discPercent = 100;
                }

                discAmnt = 0;
                vatAmnt = 0;

                rDiscAmnt = 0;
                rVatAmnt = 0;

                foreach (var i in olis)
                {
                    decimal tempVat = 0, tempDiscount = 0;
                    if (i.Sqty > 0 && i.IsFree == "N")
                    {

                        tempVat = ((i.Sqty.Value * i.RPU.Value) * i.VatPer.Value) / 100;
                        tempVat = decimal.Round(tempVat, 2);
                        vatAmnt += tempVat;

                        if (i.Barcode.Substring(0, 1) != "P")
                        {
                            tempDiscount = ((i.Sqty.Value * i.RPU.Value) * discPercent) / 100;
                            tempDiscount = decimal.Round(tempDiscount, 2);
                            discAmnt += tempDiscount;
                        }

                    }
                    else if (i.Rqty > 0 && i.IsFree == "N")
                    {
                        tempDiscount = (i.Rqty.Value * i.DiscountPrd.Value);

                        tempVat = (i.Rqty.Value * i.VatPrd.Value);
                        tempVat = decimal.Round(tempVat, 2);

                        rDiscAmnt += tempDiscount;
                        rVatAmnt += tempVat;

                        rTotalAmount += i.Total.Value;
                    }
                }

                discAmnt = Math.Floor(discAmnt);
                vatAmnt = Math.Ceiling(vatAmnt);

                rDiscAmnt = Math.Floor(rDiscAmnt);
                rVatAmnt = Math.Ceiling(rVatAmnt);

                //  txtDiscAmount.Text = discAmnt.ToString();
                // txtVatAmnt.Text = vatAmnt.ToString("0.0");


                decimal SubTotal = totalAmount + vatAmnt;
                //txtSubTotal.Text = SubTotal.ToString("0.0");
                decimal rNetAmnt = rTotalAmount - rDiscAmnt + rVatAmnt;

                netAmount = SubTotal - discAmnt - rNetAmnt;
                //txtNetAmount.Text = netAmount.ToString("0.0");
            }
            var list = JsonConvert.SerializeObject(new { result = true, TotalPrice = totalAmount, DiscAmnt = discAmnt, VatAmnt = vatAmnt, NetAmnt = netAmount }, Formatting.None,
                   new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                   );

            return Content(list, "application/json");
        }
        public ActionResult SalesCreate(Ssummary model)
        {
            string invoieNO = "";
            string ShopID = "";
            try
            {
                Buy SelectedItem;

                string IsVatAfterDiscount = getGlobalSetup().IsVatAfterDiscount;
                ShopID = GetLogedInInfo().ShopID;
                string CounterID = GetLogedInInfo().CounterID;
                string UserID = User.Identity.Name;
                List<TempSale> dgvItems = _tempSalesService.GetTempDataByUser(ShopID, CounterID, UserID);

                #region checking
                if (model.AttendentId == "" || model.Salesman == "")
                {
                    return Json(new { result = false, Error = "Enter Attendence data" }, JsonRequestBehavior.AllowGet);
                }

                if (dgvItems == null || dgvItems.Count == 0)
                {
                    return Json(new { result = false, Error = "No data for save" }, JsonRequestBehavior.AllowGet);
                }

                decimal payAmount;
                decimal.TryParse(model.PaidAmt.ToString(), out payAmount);

                decimal NetAmount;
                decimal.TryParse(model.NetAmt.ToString(), out NetAmount);

                decimal cashAmount;
                decimal.TryParse(model.CshAmt.ToString(), out cashAmount);

                decimal cardAmount;
                decimal.TryParse(model.CrdAmt.ToString(), out cardAmount);

                if (model.CreditAmt == null || model.CreditAmt == 0)
                {

                    if ((cashAmount + cardAmount) < NetAmount)
                    {
                        return Json(new { result = false, Error = "Enter Pay Amount" }, JsonRequestBehavior.AllowGet);
                    }

                    if (payAmount == 0 && NetAmount > 0)
                    {

                        return Json(new { result = false, Error = "Enter Pay Amount" }, JsonRequestBehavior.AllowGet);
                    }
                }

                //if (cbPaymentType.Checked)
                //{
                //    if (cmbPayType.SelectedIndex == 0)
                //    {
                //        return Json(new { result = false, Error = "Select Payment type" }, JsonRequestBehavior.AllowGet);
                //    }
                //}

                if (model.AttendentId != "")
                {
                    SalesMan sm = _salesManService.GetBySMID(model.AttendentId);
                    if (sm == null)
                    {
                        return Json(new { result = false, Error = "Attendent is invalid" }, JsonRequestBehavior.AllowGet);
                    }
                }
                #endregion

                CustomerMst customer = new CustomerMst();
                customer.PrvCusID = model.PrvCusID;
                if (model.PrvCusID == "" && (model.PrvCus != "" && model.CusMobile != ""))
                {
                    customer.PrvCusID = new GlobalClass().GetMaxIdWithPrfix("PrvCusID", "5", "00001", "CustomerMst", ShopID);
                    customer.CusName = model.PrvCus;
                    customer.Phone = model.CusMobile;
                    customer.DOE = DateTime.Now;
                    customer.IsTransfer = "N";
                    customer.BirthDt = DateTime.Now.AddYears(-50);
                    _customerMstService.Create(customer);
                }

                string prefix = string.Format("{0}{1}{2}{3}{4}",
                                                DateTime.Now.Month.ToString("00"),
                                                DateTime.Now.Day.ToString("00"),
                                                DateTime.Now.Year.ToString(),
                                                ShopID,
                                                CounterID);
                invoieNO = new GlobalClass().GetMaxIdWithPrfix("Invoice", "4", "0001", "Ssummary", prefix);

                List<TempSale> olis = _tempSalesService.GetTempDataByUser(ShopID, CounterID, User.Identity.Name).OrderBy(m => m.Sqty).ToList();

                decimal totalCost = 0;
                decimal disAmntPrd = decimal.Round(Convert.ToDecimal(model.DiscAmt) / Convert.ToInt32(model.TotalItems), 0);
                decimal disAmntPrdTotal = 0;


                //decimal VatAmntPrd = decimal.Round(decimal.Parse(txtVatAmnt.Text) / int.Parse(txtTotalItem.Text), 0);
                decimal VatAmntPrdTotal = 0;
                decimal _totalAmnt = 0;

                bool isCircularDiscount = false;
                foreach (var s in olis)
                {
                    totalCost += (s.Sqty * s.CPU).Value;
                    if (s.isCircularDiscount == "Y")
                    {
                        isCircularDiscount = true;
                    }
                }

                int count = 1;
                string packageNo = "";
                foreach (var s in olis)
                {
                    #region Normal Item
                    if (s.Barcode.Substring(0, 1) != "P")
                    {
                        Sale sale = new Sale();
                        sale.SaleDT = DateTime.Now;

                        //sale.CmpIDX = invoieNO + s.SBarocde; //auto increament value
                        sale.SupID = s.SupId;
                        sale.Qty = 0;
                        sale.CPU = s.CPU;
                        sale.RPP = 0;
                        sale.RPU = s.RPU;
                        sale.VPP = 0;
                        sale.VPU = 0;
                        sale.WSP = 0;
                        sale.WSQ = 0;

                        sale.sBarCode = s.SBarocde;
                        sale.BarCode = s.Barcode;
                        sale.SQty = s.Sqty;
                        sale.rQty = s.Rqty;
                        sale.rAmt = 0;
                        sale.rVat = 0;
                        sale.rDisc = 0;
                        sale.IsCircularDiscount = s.isCircularDiscount;

                        if (!string.IsNullOrEmpty(s.cInvoice))
                        {
                            Sale _cInvoice = _saleService.GetItemInforForExchage(s.cInvoice, s.Barcode);
                            if (_cInvoice == null)
                            {
                                return Json(new { result = false, Error = "Exchange invoice ref not found" }, JsonRequestBehavior.AllowGet);
                            }

                            _cInvoice.Returned = "Y";
                            _cInvoice.Flag = "N";

                            sale.rVat = s.VatPrd * s.Rqty;
                            sale.rDisc = s.DiscountPrd * s.Rqty;
                            sale.rAmt = (s.Rqty * _cInvoice.RPU) - sale.rDisc + sale.rVat;
                            sale.TotalCost = (sale.rQty * sale.CPU);
                            sale.TotalAmt = 0;
                        }

                        sale.cInvoice = s.cInvoice;
                        sale.ShopID = ShopID;
                        if (model.CrdAmt > 0)
                        {
                            sale.PayType = "CASH & CARD";
                        }
                        else
                        {
                            sale.PayType = model.PayType;
                        }

                        #region discount set

                        if (string.IsNullOrEmpty(s.cInvoice))
                        {
                            if (isCircularDiscount == true)
                            {
                                sale.DiscAmtPrd = (s.DiscountPrd * s.Sqty);
                                sale.DiscPrcnt = s.DiscountPer;

                            }
                            else if (isCircularDiscount == false)
                            {

                                if (s.IsFree == "Y")
                                {
                                    sale.DiscPrcnt = 0;
                                    sale.DiscAmtPrd = 0;
                                }
                                else
                                {
                                    sale.DiscPrcnt = Convert.ToDecimal(model.Discount);
                                    sale.DiscAmtPrd = disAmntPrd;
                                    disAmntPrdTotal += disAmntPrd;

                                    if (count == olis.Count && olis.Count > 1)
                                    {
                                        if (disAmntPrdTotal > Convert.ToDecimal(model.DiscAmt))
                                        {
                                            sale.DiscAmtPrd = disAmntPrd - (disAmntPrdTotal - Convert.ToDecimal(model.DiscAmt));
                                        }
                                        else if (disAmntPrdTotal < Convert.ToDecimal(model.DiscAmt))
                                        {
                                            sale.DiscAmtPrd = disAmntPrd + (Convert.ToDecimal(model.DiscAmt) - disAmntPrdTotal);
                                        }
                                    }
                                }

                            }

                        }
                        else
                        {
                            sale.DiscPrcnt = 0;
                            sale.DiscAmtPrd = 0;
                        }

                        sale.DiscAmt = Convert.ToDecimal(model.DiscAmt);

                        #endregion

                        #region vat amount set

                        if (string.IsNullOrEmpty(s.cInvoice))
                        {
                            if (s.IsFree == "Y")
                            {
                                sale.VATPrd = 0;
                                sale.VATPrcnt = 0;
                            }
                            else
                            {
                                // eg. vatAmnt =  ( RPU - Discount) * vatPer
                                //  Net = RPU - Discount + VatAmnt
                                if (IsVatAfterDiscount == "Y")
                                {
                                    decimal tempDiscount = sale.DiscAmtPrd.Value;//(s.Sqty.Value * s.DiscountPrd.Value);
                                    decimal tempVat = (((s.Sqty.Value * s.RPU.Value) - tempDiscount) * s.VatPer.Value) / 100;
                                    tempVat = Math.Ceiling(tempVat);

                                    VatAmntPrdTotal += tempVat;

                                    sale.VATPrd = tempVat;
                                    sale.VATPrcnt = s.VatPer;

                                }
                                // eg. vatAmnt =  ( RPU ) * vatPer
                                //  Net = RPU - Discount + VatAmnt
                                else if (IsVatAfterDiscount == "N")
                                {
                                    decimal tempVat = ((s.Sqty.Value * s.RPU.Value) * s.VatPer.Value) / 100;
                                    tempVat = decimal.Round(tempVat, 2);

                                    VatAmntPrdTotal += tempVat;

                                    sale.VATPrd = tempVat;
                                    sale.VATPrcnt = s.VatPer;
                                }

                                //sale.VATPrd = VatAmntPrd;
                                //VatAmntPrdTotal += VatAmntPrd;
                                if (count == olis.Count && olis.Count > 1)
                                {
                                    if (VatAmntPrdTotal > Convert.ToDecimal(model.VAT))
                                    {
                                        sale.VATPrd = sale.VATPrd - (VatAmntPrdTotal - Convert.ToDecimal(model.VAT));
                                    }
                                    else if (VatAmntPrdTotal < Convert.ToDecimal(model.VAT))
                                    {
                                        sale.VATPrd = sale.VATPrd + (Convert.ToDecimal(model.VAT) - VatAmntPrdTotal);
                                    }
                                }
                            }

                        }
                        else
                        {
                            sale.VATPrd = 0;
                            sale.VATPrcnt = 0;
                        }
                        sale.VAT = Convert.ToDecimal(model.VAT);
                        #endregion

                        if (s.IsFree == "Y")
                        {
                            sale.TotalAmt = 0;
                            sale.TotalCost = 0;
                        }
                        else
                        {
                            if (string.IsNullOrEmpty(s.cInvoice))
                            {
                                sale.TotalAmt = (sale.SQty * sale.RPU) - sale.DiscAmtPrd + sale.VATPrd;
                                sale.TotalCost = (sale.SQty * sale.CPU);
                            }

                            _totalAmnt += sale.TotalAmt.Value;
                        }

                        sale.NetAmt = Convert.ToDecimal(model.NetAmt);
                        sale.PrdSlNo = "";
                        sale.CshAmt = Convert.ToDecimal(model.CshAmt);
                        sale.CrdAmt = Convert.ToDecimal(model.CrdAmt);

                        SalesMan sm = _salesManService.GetBySMID(model.AttendentId);
                        if (sm != null)
                            sale.Salesman = sm.ID.ToString();
                        else
                            sale.Salesman = model.AttendentId;

                        sale.Invoice = invoieNO;
                        sale.CardName = model.CardName;
                        sale.CardNo = "";
                        sale.CounterID = CounterID;
                        sale.PrvCusID = customer.PrvCusID;
                        sale.CusName = model.CusName;
                        sale.Posted = "N";
                        sale.Returned = "N";
                        sale.ReturnedType = "N";
                        sale.ReturnedDt = DateTime.Parse("01/01/1900");
                        sale.Flag = "N";
                        sale.Point = 0;
                        sale.UserId = User.Identity.Name;
                        if (sale.SQty == 0)
                        {
                            sale.CmpIDX = sale.Invoice.ToString() + sale.BarCode.ToString() + "1";
                        }
                        else
                        {
                            sale.CmpIDX = sale.Invoice.ToString() + sale.BarCode.ToString();
                        }
                        _saleService.CreateUpdate(sale);

                        if (!string.IsNullOrEmpty(s.cInvoice))
                        {
                            _buyService.RemoveSaleQty(sale.BarCode, sale.ShopID, sale.rQty.Value);
                        }
                        else
                        {
                            _buyService.AddSaleQty(sale.BarCode, sale.ShopID, sale.SQty.Value);
                        }
                    }
                    #endregion

                    #region Package item Item
                    else if (s.Barcode.Substring(0, 1) == "P")
                    {

                        List<Package> packageDetails = _servicePackage.Gets(s.Barcode).ToList();


                        decimal PackageVat = s.Sqty.Value * Math.Ceiling((packageDetails[0].PackagePrice.Value * packageDetails[0].VATPrcen.Value) / 100);
                        decimal PackageVatPrd = 0;
                        int countPackage = 1;

                        foreach (var p in packageDetails)
                        {

                            SelectedItem = _buyService.GetProductInfoByBarcode(p.BarCode, ShopID);

                            if (SelectedItem == null)
                            {
                                return Json(new { result = false, Error = "Package Product Not found in stock. " + p.BarCode }, JsonRequestBehavior.AllowGet);
                            }

                            if (SelectedItem.balQty < 0)
                            {
                                return Json(new { result = false, Error = "on of Package Product Stock is zero" }, JsonRequestBehavior.AllowGet);
                            }

                            Sale sale = new Sale();
                            sale.SaleDT = DateTime.Now;

                            //sale.CmpIDX = invoieNO + s.SBarocde; //auto increament value
                            sale.SupID = SelectedItem.SupID;
                            sale.Qty = 0;
                            sale.CPU = p.CPU;
                            sale.RPP = 0;
                            sale.RPU = p.PckRPU;
                            sale.VPP = 0;
                            sale.VPU = 0;
                            sale.WSP = 0;
                            sale.WSQ = 0;

                            sale.sBarCode = SelectedItem.sBarCode;
                            sale.BarCode = SelectedItem.BarCode;
                            sale.PackageNo = p.PackageNo;
                            packageNo = p.PackageNo;

                            sale.SQty = (s.Sqty * p.Qty);
                            sale.rQty = s.Rqty;
                            sale.rAmt = 0;
                            sale.rVat = 0;
                            sale.rDisc = 0;
                            sale.IsCircularDiscount = s.isCircularDiscount;


                            sale.cInvoice = s.cInvoice;
                            sale.ShopID = ShopID;
                            if (model.CrdAmt > 0)
                            {
                                sale.PayType = "CASH & CARD";
                            }
                            else
                            {
                                sale.PayType = model.PayType;
                            }

                            #region discount set

                            sale.DiscPrcnt = 0;
                            sale.DiscAmtPrd = 0;
                            sale.DiscAmt = Convert.ToDecimal(model.DiscAmt);

                            #endregion

                            #region vat amount set


                            sale.VATPrcnt = p.VATPrcen;
                            decimal tempVat = ((sale.SQty.Value * sale.RPU.Value) * sale.VATPrcnt.Value) / 100;
                            tempVat = decimal.Round(tempVat, 2);
                            //tempVat = tempVat * sale.SQty.Value;

                            PackageVatPrd += tempVat;

                            sale.VATPrd = tempVat;


                            //sale.VATPrd = VatAmntPrd;
                            //VatAmntPrdTotal += VatAmntPrd;
                            if (countPackage == packageDetails.Count && packageDetails.Count > 1)
                            {
                                if (PackageVatPrd > PackageVat)
                                {
                                    sale.VATPrd = sale.VATPrd - (PackageVatPrd - PackageVat);
                                }
                                else if (VatAmntPrdTotal < Convert.ToDecimal(model.VAT))
                                {
                                    sale.VATPrd = sale.VATPrd + (PackageVat - PackageVatPrd);
                                }
                            }


                            sale.VAT = Convert.ToDecimal(model.VAT);
                            #endregion


                            sale.TotalAmt = (sale.SQty * sale.RPU) - sale.DiscAmtPrd + sale.VATPrd;
                            sale.TotalCost = (sale.SQty * sale.CPU);

                            _totalAmnt += sale.TotalAmt.Value;


                            sale.NetAmt = Convert.ToDecimal(model.NetAmt);
                            sale.PrdSlNo = "";
                            sale.CshAmt = Convert.ToDecimal(model.CshAmt);
                            sale.CrdAmt = Convert.ToDecimal(model.CrdAmt);

                            SalesMan sm = _salesManService.GetBySMID(model.AttendentId);
                            if (sm != null)
                                sale.Salesman = sm.ID.ToString();
                            else
                                sale.Salesman = model.AttendentId;

                            sale.Invoice = invoieNO;
                            sale.CardName = model.CardName;
                            sale.CardNo = "";
                            sale.CounterID = CounterID;
                            sale.PrvCusID = customer.PrvCusID;
                            sale.CusName = model.CusName;
                            sale.Posted = "N";
                            sale.Returned = "N";
                            sale.ReturnedType = "N";
                            sale.ReturnedDt = DateTime.Parse("01/01/1900");
                            sale.Flag = "N";
                            sale.Point = 0;
                            sale.UserId = User.Identity.Name;
                            if (sale.SQty == 0)
                            {
                                sale.CmpIDX = sale.Invoice.ToString() + sale.BarCode.ToString()+"1";
                            }
                            else
                            {
                                sale.CmpIDX = sale.Invoice.ToString() + sale.BarCode.ToString(); 
                            }
                            
                            _saleService.CreateUpdate(sale);

                            if (!string.IsNullOrEmpty(s.cInvoice))
                            {
                                _buyService.RemoveSaleQty(sale.BarCode, sale.ShopID, sale.rQty.Value);
                            }
                            else
                            {
                                _buyService.AddSaleQty(sale.BarCode, sale.ShopID, sale.SQty.Value);
                            }
                            countPackage++;
                        }
                        if (!string.IsNullOrEmpty(s.cInvoice))
                        {
                            _servicePackageIssue.RemovePackageSSaleQty(s.Barcode, ShopID, Convert.ToInt32(s.Sqty));
                        }
                        else
                        {
                            _servicePackageIssue.RemovePackageSSaleQty(s.Barcode, ShopID, Convert.ToInt32(s.Sqty));
                        }

                        VatAmntPrdTotal += PackageVat;

                    }

                    #endregion

                    count++;
                }
                Ssummary summary = new Ssummary();
                summary.SaleDT = DateTime.Now;
                summary.Invoice = invoieNO;
                summary.TotalCost = totalCost;
                summary.TotalAmt = _totalAmnt;//decimal.Parse(txtTotalPrice.Text);
                summary.Discount = Convert.ToDecimal(model.Discount);
                summary.DiscAmt = Convert.ToDecimal(model.DiscAmt);
                summary.VAT = Convert.ToDecimal(model.VAT);
                summary.NetAmt = Convert.ToDecimal(model.NetAmt);
                summary.CshAmt = Convert.ToDecimal(model.CshAmt);
                summary.CrdAmt = Convert.ToDecimal(model.CrdAmt);
                summary.UserId = User.Identity.Name;
                summary.IsPrinted = "N";
                if (model.CrdAmt > 0)
                {
                    summary.PayType = "CASH & CARD";
                }
                else
                {
                    summary.PayType = model.PayType;
                }

                summary.Salesman = model.Salesman;
                summary.ShopID = ShopID; ;
                summary.CounterID = CounterID;
                summary.CardName = model.CardName;
                summary.CardNo = "";
                summary.PrvCus = "T";
                summary.CusName = model.CusName;
                summary.PrvCusID = customer.PrvCusID;
                summary.ReturnedAmt = 0;
                summary.rTotalCost = 0;
                summary.cInvoice = "";
                summary.ReturnedType = "N";
                summary.Flag = "N";
                summary.PaidAmt = Convert.ToDecimal(model.PaidAmt);
                summary.ChangeAmt = Convert.ToDecimal(model.ReturnedAmt);
                summary.Point = 0;

                summary.PrevDue = 0;
                summary.CurDue = 0;
                if (model.CreditAmt != null)
                {
                    summary.CreditAmt = model.CreditAmt;
                    CustomerLedger o = _customerLedger.GetSummaryByPrvCusID(customer.PrvCusID);
                    if (o != null)
                    {
                        summary.PrevDue = o.PrevDue;
                    }
                    else
                        summary.PrevDue = 0;

                    summary.CurDue = summary.PrevDue + summary.CreditAmt;

                    if (customer.PrvCusID != null)
                    {
                        string CusLedgerNo = new GlobalClass().GetMaxIdWithPrfix("CusLedgerNo", "5", "00001",
                            "CustomerLedger", customer.PrvCusID);

                        CustomerLedger cl = new CustomerLedger();
                        cl.CreateBy = User.Identity.Name;
                        cl.Credit = model.CreditAmt;
                        cl.Debit = 0;
                        cl.ShopID = ShopID;
                        if (model.CrdAmt > 0)
                        {
                            cl.PayMode = "CASH & CARD";
                        }
                        else
                        {
                            cl.PayMode = model.PayType;
                        }
                        cl.PrvCusID = customer.PrvCusID;
                        cl.Reason = "";
                        cl.CreateDate = DateTime.Now;
                        cl.InvoiceNo = invoieNO;
                        cl.CusLedgerNo = CusLedgerNo;
                        _customerLedger.Create(cl);
                    }
                }
                else
                {
                    summary.PrevDue = 0;
                    summary.CurDue = 0;
                    summary.CreditAmt = 0;
                }
                summary.PackageNo = packageNo;
                _ssummaryService.CreateUpdate(summary);
                _saleService.Save();
                _tempSalesService.RemoveAll(ShopID, CounterID, User.Identity.Name);
                _tempSalesService.Save();
                _ssummaryService.Save();
                _customerLedger.Save();
                _servicePackageIssue.Save();
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, invoieNO = invoieNO, ShopID = ShopID }, JsonRequestBehavior.AllowGet);
        }
        public ActionResult GetItemInforForExchage(string InvoiceNo, string BarCode)
        {
            Sale osale = _saleService.GetItemInforForExchage(InvoiceNo, BarCode);

            var list = JsonConvert.SerializeObject(new { data = osale }, Formatting.None,
                    new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                    );

            return Content(list, "application/json");
        }
        public ActionResult ApplySaleExchange(string InvoiceNo, string BarCode, string SQty, string EQty)
        {
            try
            {
                Sale sale = _saleService.GetItemInforForExchage(InvoiceNo, BarCode);

                string ShopID = GetLogedInInfo().ShopID;
                string CounterID = GetLogedInInfo().CounterID;
                string UserID = User.Identity.Name;

                TempSale tempPrv = _tempSalesService.GetTempDataByUser(ShopID, CounterID, UserID).Where(m => m.cInvoice == InvoiceNo && m.Barcode == BarCode).FirstOrDefault();
                if (tempPrv != null)
                {
                    return Json(new { result = false, Error = "This data already enter" }, JsonRequestBehavior.AllowGet);
                }

                TempSale otemp = new TempSale();

                // otemp.AttendentId = txtAttendentId.Text;
                // otemp.AttendentName = txtAttendentName.Text;
                otemp.Barcode = sale.BarCode;
                otemp.cInvoice = sale.Invoice;
                otemp.CounterId = CounterID;
                // otemp.CustomerName = txtCustomerName.Text;
                // otemp.PrvCusID = txtCustomerId.Text;
                // otemp.CustomerMobile = txtCustomerMobile.Text;

                otemp.Rqty = Convert.ToInt32(EQty);
                otemp.RPU = sale.RPU;
                otemp.CPU = sale.CPU;
                otemp.DiscountPrd = sale.DiscAmtPrd / sale.SQty;
                otemp.DiscountPer = sale.DiscPrcnt;
                otemp.VatPer = sale.VATPrcnt;
                otemp.VatPrd = sale.VATPrd / sale.SQty;

                otemp.EQty = 0;
                otemp.IsFree = "N";
                otemp.SBarocde = sale.sBarCode;
                otemp.ShopId = ShopID;
                otemp.Sqty = 0;
                otemp.Total = decimal.Round(otemp.Rqty.Value * otemp.RPU.Value, 0);
                otemp.UserId = UserID;
                otemp.ProdcutDescription = sale.ProductDescription;
                otemp.isCircularDiscount = sale.IsCircularDiscount;

                _tempSalesService.CreateUpdate(otemp);
                _tempSalesService.Save();

            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message.ToString() }, JsonRequestBehavior.AllowGet);
            }

            return Json(new { result = true, Error = "Save" }, JsonRequestBehavior.AllowGet);
        }
        public ActionResult LoadPromotionData()
        {
            List<sp_getPromotionItem> olistPromotion = _tempSalesService.GetPromotionItem(User.Identity.Name);
            var list = JsonConvert.SerializeObject(new { data = olistPromotion }, Formatting.None,
                    new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                    );

            return Content(list, "application/json");
        }
        public ActionResult GetTopSalesItem()
        {
            string ShopID = GetLogedInInfo().ShopID;
            if (ShopID == "9999") ShopID = "All";
            List<Sale> olist = _saleService.GetTopSalesItem(DateTime.Now.AddDays(-7).ToShortDateString(), DateTime.Now.ToShortDateString(), ShopID);
            var list = JsonConvert.SerializeObject(new { data = olist }, Formatting.None,
                    new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                    );

            return Content(list, "application/json");
        }

        public ActionResult GetTodaysSalesAmount()
        {
            string ShopID = GetLogedInInfo().ShopID;
            List<Sale> olist = _saleService.GetTodaysSalesAmount(DateTime.Now.ToShortDateString());
            if (ShopID != "9999")
                olist = olist.FindAll(m => m.ShopID == ShopID).ToList();

            var list = JsonConvert.SerializeObject(new { data = olist }, Formatting.None,
                    new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                    );

            return Content(list, "application/json");
        }

        #endregion

        #region ==== Sale Void =====
        public ActionResult Salevoid()
        {
            if (!IsPermissionApply("Sales", "Salevoid"))
            {
                return RedirectToAction("Index", "Home");
            }
            return View();
        }
        public ActionResult SalesvoidByInvoice(string Invoice)
        {
            try
            {
                string ShopID = GetLogedInInfo().ShopID;
                string CounterID = GetLogedInInfo().CounterID;
                List<Sale> saleList = _saleService.GetItemInforForVoid(Invoice);
                if (saleList == null || saleList.Count == 0)
                {
                    return Json(new { result = false, Error = "Invoice not found" }, JsonRequestBehavior.AllowGet);
                }

                List<TempSalesVoid> oSalesVoids = _tempsalevoidService.GetItemInforForVoid(Invoice);

                if (oSalesVoids.Count > 0)
                {
                    return Json(new { result = true, Error = "Invoice already in temp table" }, JsonRequestBehavior.AllowGet);
                }

                foreach (var s in saleList)
                {
                    if (s.Returned == "Y")
                    {
                        return Json(new { result = false, Error = "Invoice Already void" }, JsonRequestBehavior.AllowGet);
                    }
                    if (s.rQty > 0)
                    {
                        return Json(new { result = false, Error = "Exchange invoice can not be void" }, JsonRequestBehavior.AllowGet);
                    }
                    if (!string.IsNullOrEmpty(s.PackageNo))
                    {
                        return Json(new { result = false, Error = "Package item cannot be void" }, JsonRequestBehavior.AllowGet);
                    }
                    if (s.IsCircularDiscount == "Y")
                    {
                        return Json(new { result = false, Error = "Promotional item cannot be void" }, JsonRequestBehavior.AllowGet);
                    }
                }

                foreach (var d in saleList)
                {
                    Buy SelectedItem = _buyService.GetProductInfoByBarcode(d.BarCode, ShopID);
                    //LoadProductInfo();
                    if (SelectedItem == null)
                    {
                        return Json(new { result = false, Error = "Product Info Not found" }, JsonRequestBehavior.AllowGet);
                    }
                    TempSalesVoid otemp = new TempSalesVoid();
                    otemp.Barcode = d.BarCode;
                    otemp.SBarocde = d.sBarCode;
                    otemp.CounterId = CounterID;
                    otemp.CustomerName = d.CusName;
                    otemp.PrvCusID = d.PrvCusID;
                    otemp.CustomerMobile = "";
                    otemp.EQty = 0;
                    otemp.RPU = d.RPU;
                    otemp.CPU = d.CPU;

                    otemp.Rqty = int.Parse(d.SQty.Value.ToString("0"));
                    otemp.SBarocde = d.sBarCode;
                    otemp.ShopId = ShopID;
                    otemp.Sqty = Convert.ToInt32(d.SQty);
                    otemp.Total = otemp.Rqty * otemp.RPU;
                    otemp.UserId = User.Identity.Name;
                    otemp.ProdcutDescription = SelectedItem.ProductDescription;
                    otemp.cInvoice = Invoice;
                    //otemp.VatAmnt = d.VAT;
                    otemp.VatAmntPrd = (d.VATPrd / d.SQty);
                    otemp.VatPer = 0;
                    //otemp.DiscAmnt = d.DiscAmt;
                    otemp.DiscAmntPrd = (d.DiscAmtPrd / d.SQty);
                    _tempsalevoidService.CreateUpdate(otemp);
                }
                _tempsalevoidService.Save();

                return Json(new { result = true, Error = "Save" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }
        public ActionResult SalesvoidByInvoiceList(string Invoice)
        {
            try
            {
                string ShopID = GetLogedInInfo().ShopID;
                string CounterID = GetLogedInInfo().CounterID;
                List<TempSalesVoid> saleList = _tempsalevoidService.GetTempDataByUser(ShopID, CounterID, User.Identity.Name).FindAll(m => m.cInvoice == Invoice).ToList();
                var list = JsonConvert.SerializeObject(new { data = saleList }, Formatting.None,
                    new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                    );

                return Content(list, "application/json");
            }
            catch (Exception ex)
            {
                List<TempSalesVoid> saleList = new List<TempSalesVoid>();
                return Json(new { result = false, data = saleList }, JsonRequestBehavior.AllowGet);
            }
        }
        public ActionResult SalevoidCalculateRightSideData(string BarCodeList, string Invoice)
        {
            try
            {
                List<string> barcodeList = BarCodeList.Split(',').ToList();
                string TotalItem = "0";
                string TotalQty = "0";
                string TotalPrice = "0";

                string VatAmnt = "0";
                string DiscAmount = "0";
                string NetAmount = "0";
                string DiscountPercent = "0";

                string CustomerId = "0";
                string CustomerName = "0";
                string CustomerMobile = "0";

                string AttendentId = "0";
                string AttendentName = "0";

                List<TempSalesVoid> olis = _tempsalevoidService.GetTempDataByUser(GetLogedInInfo().ShopID, GetLogedInInfo().CounterID, User.Identity.Name);

                olis = olis.Where(o => barcodeList.Contains(o.Barcode)).ToList();

                int totalQty = 0;
                int totalItem = 0;
                decimal totalAmount = 0;
                if (olis != null && olis.Count > 0)
                {
                    CustomerId = olis[0].PrvCusID;
                    CustomerName = olis[0].CustomerName;
                    CustomerMobile = olis[0].CustomerMobile;
                    AttendentId = olis[0].AttendentId;
                    AttendentName = olis[0].AttendentName;
                    decimal TotalDiscount = 0;
                    decimal TotalVat = 0;
                    decimal netAmount = 0;
                    foreach (var i in olis)
                    {
                        totalQty += i.Rqty.Value;
                        totalAmount += (i.Rqty.Value * i.RPU.Value);
                        totalItem++;
                    }
                    TotalItem = totalItem.ToString();
                    TotalQty = totalQty.ToString();
                    TotalPrice = totalAmount.ToString();

                    if (string.IsNullOrEmpty(olis[0].cInvoice))
                    {
                        foreach (var i in olis)
                        {
                            if (getGlobalSetup().IsVatAfterDiscount == "Y")
                            {
                                decimal tempDiscount = 0, tempVat = 0;
                                TotalDiscount += tempDiscount;
                                tempVat = (((i.Rqty.Value * i.RPU.Value) - tempDiscount) * i.VatPer.Value) / 100;
                                tempVat = decimal.Round(tempVat, 2);
                                TotalVat += tempVat;
                            }
                            else if (getGlobalSetup().IsVatAfterDiscount == "N")
                            {

                                decimal tempVat = 0, tempDiscount = 0;

                                tempVat = ((i.Rqty.Value * i.RPU.Value) * i.VatPer.Value) / 100;
                                tempVat = decimal.Round(tempVat, 2);
                                TotalVat += tempVat;
                                TotalDiscount += tempDiscount;
                            }
                        }
                        netAmount = totalAmount + TotalVat - TotalDiscount;

                    }
                    else
                    {
                        decimal discPer = 0;
                        DiscountPercent = discPer.ToString("0.0");

                        foreach (var i in olis)
                        {
                            TotalVat += (i.VatAmntPrd.Value * i.Rqty.Value);
                            TotalDiscount += (i.DiscAmntPrd.Value * i.Rqty.Value);
                        }
                        netAmount = totalAmount + TotalVat - TotalDiscount;
                    }
                    VatAmnt = TotalVat.ToString("0.0");
                    DiscAmount = TotalDiscount.ToString("0.0");
                    NetAmount = netAmount.ToString("0.0");
                }
                return Json(new { result = true, TotalItem = TotalItem, TotalQty = TotalQty, TotalPrice = TotalPrice, DiscountPercent = DiscountPercent, DiscAmount = DiscAmount, VatAmnt = VatAmnt, NetAmount = NetAmount }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }
        public ActionResult SalesDeleteTempSalesvoid(decimal TempId)
        {
            _tempsalevoidService.RemoveTempId(TempId);
            _tempsalevoidService.Save();

            var list = JsonConvert.SerializeObject(new { data = "Deleted" }, Formatting.None,
                   new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                   );

            return Content(list, "application/json");
        }

        public ActionResult SalesvoidPrintSave(Ssummary ssummary)
        {
            try
            {
                string Invoice = ssummary.cInvoice;
                string CustomerId = ssummary.PrvCusID;
                string Mobile = ssummary.CusMobile;
                string AttendentId = ssummary.AttendentId;
                string AttendentName = ssummary.Salesman;
                string DiscountPercent = ssummary.Discount.ToString();
                string DiscAmount = ssummary.DiscAmt.ToString();
                string VatAmnt = ssummary.VAT.ToString();
                string NetAmount = ssummary.NetAmt.ToString();

                List<string> barcodeList = ssummary.PayType.Split(',').ToList();
                List<TempSalesVoid> olis = _tempsalevoidService.GetTempDataByUser(GetLogedInInfo().ShopID, GetLogedInInfo().CounterID, User.Identity.Name);
                olis = olis.Where(o => barcodeList.Contains(o.Barcode)).OrderBy(m => m.Sqty).ToList();
                string CustomerName = "";

                #region checking

                if (AttendentId == "")
                {
                    return Json(new { result = true, Error = "Enter Attendence data" }, JsonRequestBehavior.AllowGet);
                }


                if (olis.Count == 0)
                {
                    return Json(new { result = true, Error = "No data for save" }, JsonRequestBehavior.AllowGet);
                }


                if (CustomerId != null)
                {
                    CustomerMst customerCheck = _customerMstService.Get(CustomerId);
                    if (customerCheck == null)
                    {
                        return Json(new { result = true, Error = "Customer is invalid" }, JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        CustomerName = customerCheck.CusName;
                    }
                }

                if (AttendentId != "")
                {
                    SalesMan sm = _salesManService.GetBySMID(AttendentId);
                    if (sm == null)
                    {
                        return Json(new { result = true, Error = "Attendent is invalid" }, JsonRequestBehavior.AllowGet);
                    }
                }
                #endregion

                string ShopID = GetLogedInInfo().ShopID;
                string CounterID = GetLogedInInfo().CounterID;

                string prefix = string.Format("CR{0}", ShopID);
                string invoieNO = new GlobalClass().GetMaxIdWithPrfix("Invoice", "6", "000001", "Ssummary", prefix);


                #region invoice void

                decimal totalCost = 0;

                foreach (var ss in olis)
                {
                    totalCost += (ss.Rqty * ss.CPU).Value;
                }

                int count = 1;
                decimal TotalDiscount = 0;
                decimal TotalVat = 0;
                decimal TotalRAmount = 0;

                foreach (var s in olis)
                {
                    Sale sale = new Sale();
                    sale.SaleDT = DateTime.Now;
                    //sale.CmpIDX = invoieNO + s.SBarocde;
                    sale.SupID = s.SupId;
                    sale.Qty = 0;
                    sale.CPU = s.CPU;
                    sale.RPP = 0;
                    sale.RPU = s.RPU;
                    sale.VPP = 0;
                    sale.VPU = 0;
                    sale.WSP = 0;
                    sale.WSQ = 0;

                    sale.sBarCode = s.SBarocde;
                    sale.BarCode = s.Barcode;
                    sale.SQty = 0;
                    sale.rQty = s.Rqty;

                    sale.DiscAmtPrd = 0;
                    sale.DiscAmt = 0;
                    sale.DiscPrcnt = decimal.Parse(DiscountPercent);
                    sale.VATPrd = 0;
                    sale.VAT = 0;

                    //invoice void
                    //vat already calculated

                    sale.rVat = (s.VatAmntPrd * s.Rqty);
                    sale.rDisc = (s.DiscAmntPrd * s.Rqty);
                    sale.rAmt = (s.Rqty * s.RPU) - sale.rDisc + sale.rVat;

                    TotalVat += sale.rVat.Value;
                    TotalDiscount += sale.rDisc.Value;
                    TotalVat += sale.rAmt.Value;

                    sale.VATPrcnt = getGlobalSetup().VAT;

                    if (count == olis.Count && olis.Count > 1)
                    {
                        if (TotalVat > decimal.Parse(VatAmnt))
                        {
                            sale.rVat = sale.rVat - (TotalVat - decimal.Parse(VatAmnt));
                        }
                        else if (TotalVat < decimal.Parse(VatAmnt))
                        {
                            sale.rVat = sale.rVat + (decimal.Parse(VatAmnt) - TotalVat);
                        }

                        if (TotalDiscount > decimal.Parse(DiscAmount))
                        {
                            sale.rDisc = sale.rDisc - (TotalDiscount - decimal.Parse(DiscAmount));
                        }
                        else if (TotalDiscount < decimal.Parse(DiscAmount))
                        {
                            sale.rDisc = sale.rDisc + (decimal.Parse(DiscAmount) - TotalDiscount);
                        }

                        if (TotalRAmount > decimal.Parse(NetAmount))
                        {
                            sale.rAmt = sale.rAmt - (TotalRAmount - decimal.Parse(NetAmount));
                        }
                        else if (TotalRAmount < decimal.Parse(NetAmount))
                        {
                            sale.rAmt = sale.rAmt + (decimal.Parse(NetAmount) - TotalRAmount);
                        }
                    }

                    sale.cInvoice = s.cInvoice;
                    sale.ShopID = ShopID;
                    if (ssummary.CrdAmt > 0)
                    {
                        sale.PayType = "CASH & CARD";
                    }
                    else
                    {
                        sale.PayType = ssummary.PayType;
                    }
                    sale.TotalCost = totalCost;
                    sale.TotalAmt = 0;

                    sale.NetAmt = decimal.Parse(NetAmount);
                    sale.PrdSlNo = "";
                    sale.CshAmt = decimal.Parse(NetAmount);
                    sale.CrdAmt = 0;
                    sale.Salesman = AttendentName;
                    sale.Invoice = invoieNO;
                    sale.CardName = "CASH";
                    sale.CardNo = "";
                    sale.CounterID = CounterID;
                    sale.PrvCusID = s.PrvCusID;
                    sale.CusName = s.CustomerName;
                    sale.Posted = "N";
                    sale.Returned = "Y";
                    sale.ReturnedType = "V";
                    sale.ReturnedDt = DateTime.Now;
                    sale.Flag = "N";
                    sale.Point = 0;
                    _saleService.CreateUpdate(sale);
                    _buyService.RemoveSaleQty(sale.BarCode, sale.ShopID, sale.rQty.Value);
                }

                Ssummary summary = new Ssummary();
                summary.SaleDT = DateTime.Now;
                summary.Invoice = invoieNO;
                summary.TotalCost = 0;
                summary.rTotalCost = totalCost;

                summary.TotalAmt = 0;
                summary.Discount = 0;
                summary.DiscAmt = 0;
                summary.VAT = 0;
                summary.NetAmt = 0;
                summary.ReturnedAmt = decimal.Parse(NetAmount);
                summary.CshAmt = 0;
                summary.CrdAmt = 0;
                if (ssummary.CrdAmt > 0)
                {
                    summary.PayType = "CASH & CARD";
                }
                else
                {
                    summary.PayType = ssummary.PayType;
                }
                summary.Salesman = AttendentName;
                summary.ShopID = ShopID;
                summary.CounterID = CounterID;
                summary.CardName = summary.CardName;

                summary.CardNo = "";
                summary.PrvCus = "T";
                summary.CusName = CustomerName;
                summary.PrvCusID = olis[0].PrvCusID;
                summary.cInvoice = "";
                summary.ReturnedType = "N";
                summary.Flag = "N";
                summary.PaidAmt = decimal.Parse(NetAmount);
                summary.ChangeAmt = 0;
                summary.Point = 0;
                summary.IsPrinted = "N";
                summary.UserId = User.Identity.Name;
                _ssummaryService.CreateUpdate(summary);

                _tempsalevoidService.RemoveAll(User.Identity.Name, CounterID, ShopID, Invoice);
                _saleService.SetInvoiceVoidStatus(olis[0].cInvoice);

                _tempsalevoidService.Save();
                _saleService.Save();
                _ssummaryService.Save();
                _buyService.Save();

                #endregion

                return Json(new { result = true, invoieNO = invoieNO, ShopID = ShopID }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        #endregion

        #region ==== Credit Collection ====

        public ActionResult CreditCollection()
        {
            if (!IsPermissionApply("Sales", "CreditCollection"))
            {
                return RedirectToAction("Index", "Home");
            }

            List<CreditCardList> dl = _creditCardService.Gets().ToList();
            ViewBag.PaymentType = new SelectList(dl, "slno", "CardName");
            return View();
        }

        public ActionResult GetSummaryList()
        {
            List<CustomerLedger> PrvCusIDList = new List<CustomerLedger>();
            List<CustomerLedger> tempolist = new List<CustomerLedger>();
            List<CustomerLedger> olist = _customerLedger.GetSummaryList(GetLogedInInfo().ShopID).OrderBy(m => m.PrvCusID).ToList();
            PrvCusIDList = olist.DistinctBy(m => m.PrvCusID).ToList();

            List<CustomerLedger> finalList = new List<CustomerLedger>();
            CustomerLedger ledger = new CustomerLedger();

            foreach (var c in PrvCusIDList)
            {
                tempolist = olist.FindAll(m => m.PrvCusID == c.PrvCusID).ToList();

                decimal sumOfDebit = 0;
                decimal sumOfCredit = 0;
                decimal temp = 0;
                foreach (CustomerLedger l in tempolist)
                {
                    decimal.TryParse(l.Debit.ToString(), out temp);
                    sumOfDebit += temp;
                    decimal.TryParse(l.Credit.ToString(), out temp);
                    sumOfCredit += temp;
                }
                ledger = tempolist.OrderByDescending(m => m.CreateDate).FirstOrDefault();
                if (ledger != null)
                {
                    ledger.Credit = sumOfCredit;
                    ledger.Debit = sumOfDebit;
                    if (sumOfDebit < sumOfCredit)
                        ledger.PrevDue = sumOfCredit - sumOfDebit;
                    else
                        ledger.PrevDue = 0;
                }
                finalList.Add(ledger);
            }

            var list = JsonConvert.SerializeObject(new { data = finalList }, Formatting.None,
                    new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                    );

            return Content(list, "application/json");
        }
        public ActionResult CreditGetByCusID(string CusID)
        {
            CustomerLedger cs = _customerLedger.GetSummaryByPrvCusID(CusID);
            var list = JsonConvert.SerializeObject(new { data = cs }, Formatting.None,
                    new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                    );

            return Content(list, "application/json");
        }

        public ActionResult GetCreditByCusID(string CusID)
        {
            List<CustomerLedger> cs = _customerLedger.GetByPrvCusID(CusID).OrderBy(m => m.CreateDate).ToList();
            var list = JsonConvert.SerializeObject(new { data = cs }, Formatting.None,
                    new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                    );

            return Content(list, "application/json");
        }

        public ActionResult CreditGetByMobile(string Mobile)
        {
            CustomerLedger cs = _customerLedger.GetSummaryByMobile(Mobile);
            var list = JsonConvert.SerializeObject(new { data = cs }, Formatting.None,
                    new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                    );

            return Content(list, "application/json");
        }

        public ActionResult CreditCollectionSave(CustomerLedger model)
        {
            string ID = "";
            try
            {
                string cusLedgerNo = new GlobalClass().GetMaxIdWithPrfix("CusLedgerNo", "5", "00001",
                       "CustomerLedger", "r" + model.PrvCusID);

                decimal temp = 0;
                decimal.TryParse(model.Debit.ToString(), out temp);
                model.Debit = temp;
                decimal.TryParse(model.CardAmount.ToString(), out temp);
                model.CardAmount = temp;
                decimal.TryParse(model.CashAmount.ToString(), out temp);
                model.CashAmount = temp;
                model.PrvCusID = model.PrvCusID;
                model.CreateBy = User.Identity.Name;
                model.CreateDate = DateTime.Now;
                model.CusLedgerNo = cusLedgerNo;
                model.ShopID = GetLogedInInfo().ShopID;
                _customerLedger.Create(model);
                _customerLedger.Save();

                ID = new GlobalClass().GetCurrentMaxId("ID", "CustomerLedger");
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Save", ID = ID }, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region ==== Menu Permission Check =====
        private bool IsPermissionApply(string Controller, string ActionName)
        {
            List<MenuURLViewModel> lstMenus = null;
            if (Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.SessionMenu] == null)
            {
                lstMenus = new GlobalClass().GetMenuByUserName(User.Identity.Name);
                Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.SessionMenu] = lstMenus;
            }
            else
            {
                lstMenus =
                    Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.SessionMenu] as
                        List<MenuURLViewModel>;
            }
            MenuURLViewModel menu = lstMenus.FindAll(m => m.Controller == Controller && m.ActionName == ActionName).FirstOrDefault();
            if (menu != null)
                return true;
            else
                return false;
        }
        #endregion
    }
}