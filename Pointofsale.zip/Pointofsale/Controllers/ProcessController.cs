﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;
using AutoMapper;
using Newtonsoft.Json;
using RetailMaster.POS.Data;
using RetailMaster.POS.Models;
using RetailMaster.POS.Service;
using RetailMaster.POS.Web.BLL;
using RetailMaster.POS.Web.ViewModels;
using WebGrease.Css.Visitor;

namespace RetailMaster.POS.Web.Controllers
{
    public class ProcessController : Controller
    {

        private readonly IBuyOrderService _buyOrderService;
        private readonly IBuyOrderTempService _buyOrderTempService;
        private readonly ISupplierService _supplierService;
        private readonly IBuyCentralService _buyCentralService;
        private readonly IAccountsChlnService _accountsChlnService;
        private readonly IrChallanService _rchallanService;
        private readonly ITempTableValueService _tempTableValueService;
        private readonly IStyleSizeService _styleSizeService;
        private readonly IShopListService _shopListService;
        private readonly IiChallanService _iChallanService;
        private readonly IiChallanTempService _iChallanTempService;
        private readonly IBuyRequisitionService _buyRequisitionService;
        private readonly IBuyRequisitionTempService _buyRequisitionTempService;

        public ProcessController(IBuyOrderService buyOrderService, ISupplierService supplierService, IBuyOrderTempService buyOrderTempService
            , IBuyCentralService buyCentralService, IAccountsChlnService accountsChlnService, IrChallanService rchallanService,
            ITempTableValueService tempTableValueService, IStyleSizeService styleSizeService, IShopListService shopListService,
            IiChallanTempService iChallanTempService, IiChallanService iChallanService, IBuyRequisitionService buyRequisitionService, IBuyRequisitionTempService buyRequisitionTempService)
        {
            this._buyOrderService = buyOrderService;
            this._supplierService = supplierService;
            this._buyOrderTempService = buyOrderTempService;
            this._buyCentralService = buyCentralService;
            this._accountsChlnService = accountsChlnService;
            this._rchallanService = rchallanService;
            this._tempTableValueService = tempTableValueService;
            this._styleSizeService = styleSizeService;
            this._shopListService = shopListService;
            this._iChallanService = iChallanService;
            this._iChallanTempService = iChallanTempService;
            this._buyRequisitionService = buyRequisitionService;
            this._buyRequisitionTempService = buyRequisitionTempService;
        }


        #region StyleSize
        private StyleSizeViewModel FindByCMPIDX(string cMPIDX)
        {
            StyleSizeViewModel result = null;
            StyleSize datas = _styleSizeService.GetstyleSizeByCMPIDX(cMPIDX);
            result = Mapper.Map<StyleSize, StyleSizeViewModel>(datas); ;
            return result;
        }
        #endregion

        #region Purchase Order / BuyOder
        public ActionResult PurchaseOrder()
        {
            if (!IsPermissionApply("Process", "PurchaseOrder"))
            {
                return RedirectToAction("Index", "Home");
            }

            List<SupplierViewModel> resultSupplier = null;
            IEnumerable<Supplier> dataSupplier = _supplierService.Gets();
            resultSupplier = Mapper.Map<IEnumerable<Supplier>, IEnumerable<SupplierViewModel>>(dataSupplier).ToList();

            SupplierViewModel obj = new SupplierViewModel();
            obj.SupID = "";
            obj.Supname = "Select";
            resultSupplier.Insert(0, obj);

            ViewBag.SuppliersList = new SelectList(resultSupplier, "SupID", "Supname");
            return View();
        }

        [HttpPost]
        public ActionResult CreatePurchaseOrder(BuyOrderViewModel model)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    BuyOrder dbModel = new BuyOrder();
                    dbModel = Mapper.Map<BuyOrderViewModel, BuyOrder>(model);

                    #region duplicate check
                    //for new item duplicate check  primary key must be zero
                    dbModel.CmpIDX = "0";
                    dbModel.UserID = User.Identity.Name;
                    if (_buyOrderService.IsDuplicate(dbModel))
                    {
                        return Json(new { result = false, Error = "Duplicate Data" }, JsonRequestBehavior.AllowGet);
                    }
                    #endregion

                    // id generation here

                    //get primary key value
                    dbModel.CmpIDX = new GlobalClass().GetMaxId("CmpIDX", "BuyOrder");
                    if (dbModel.CmpIDX == "1")
                        dbModel.CmpIDX = "101";

                    _buyOrderService.Create(dbModel);
                    _buyOrderService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult UpdatePurchaseOrder(BuyOrderViewModel model)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    var data = _buyOrderService.Get(model.CmpIDX);
                    if (_buyOrderService.IsDuplicate(data))
                    {
                        return Json(new { result = false, Error = "Duplicate Data" }, JsonRequestBehavior.AllowGet);
                    }

                    _buyOrderService.Update(data);
                    _buyOrderService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "Updated" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult DeletePurchaseOrder(BuyOrderViewModel model)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    var data = _buyOrderService.Get(model.CmpIDX);
                    _buyOrderService.Remove(data);
                    _buyOrderService.Save();

                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult PurchaseOrderList()
        {
            IEnumerable<BuyOrderViewModel> result = null;
            IEnumerable<BuyOrder> datas = _buyOrderService.Gets();
            result = Mapper.Map<IEnumerable<BuyOrder>, IEnumerable<BuyOrderViewModel>>(datas);

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        public ActionResult PurchaseOrderFindByCmpIDX(string cmpIDX)
        {
            DataTable dt = _buyOrderService.GetBuyOrderByCmpIDX(cmpIDX);

            var list = JsonConvert.SerializeObject(new { data = dt }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        public ActionResult PurchaseOrderFindByChln(string chln)
        {
            DataTable datas = _buyOrderService.GetNotRecPOStyleByChln(chln);

            var list = JsonConvert.SerializeObject(new { data = datas }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        public ActionResult PurchaseOrderChlnNoFindBySupID(string supID)
        {
            string NewChlnNo = new GlobalClass().GetMaxIdByWhereVar("Chln", "BuyOrder", "SupID", supID);
            if (NewChlnNo == "1")
                NewChlnNo = supID + "00000";

            var list = JsonConvert.SerializeObject(new { data = NewChlnNo }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }
        #endregion

        #region Purchase Order Temp / BuyOder Temp
        public ActionResult PurchaseOrderTemp()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CreatePurchaseOrderTemp(BuyOrderTempViewModel model)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    BuyOrderTemp dbModel = new BuyOrderTemp();
                    dbModel = Mapper.Map<BuyOrderTempViewModel, BuyOrderTemp>(model);

                    string NewChlnNo = new GlobalClass().GetMaxIdByWhereVar("Chln", "BuyOrder", "SupID", dbModel.SupID);
                    if (NewChlnNo == "1")
                        NewChlnNo = dbModel.SupID + "00000";
                    dbModel.Chln = "T" + NewChlnNo;
                    dbModel.CmpIDX = dbModel.Chln + dbModel.BarCode;
                    dbModel.sQty = 0;
                    BuyOrderTemp data = _buyOrderTempService.Get(dbModel.CmpIDX);
                    if (data != null)
                    {
                        data.Qty = dbModel.Qty + data.Qty;
                        data.UserID = User.Identity.Name;
                        _buyOrderTempService.Update(data);
                    }
                    else
                    {
                        dbModel.UserID = User.Identity.Name;
                        _buyOrderTempService.Create(dbModel);
                    }

                    _buyOrderTempService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult UpdatePurchaseOrderTemp(BuyOrderTempViewModel model)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    var data = _buyOrderTempService.Get(model.CmpIDX);
                    data.Qty = model.Qty;

                    if (_buyOrderTempService.IsDuplicate(data))
                    {
                        return Json(new { result = false, Error = "Duplicate Data" }, JsonRequestBehavior.AllowGet);
                    }

                    _buyOrderTempService.Update(data);
                    _buyOrderTempService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "Updated" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult DeletePurchaseOrderTemp(string CmpIDX)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var data = _buyOrderTempService.Get(CmpIDX);
                    _buyOrderTempService.Remove(data);
                    _buyOrderTempService.Save();

                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult PurchaseOrderTempList()
        {
            DataTable dt = _buyOrderTempService.GetBuyOrderTempList();

            var list = JsonConvert.SerializeObject(new { data = dt }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        public ActionResult PurchaseOrderTempFindByCmpIDX(string cMPIDX)
        {
            DataTable dt = _buyOrderTempService.GetBuyOrderTempByCmpIDX(cMPIDX);

            var list = JsonConvert.SerializeObject(new { data = dt }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        public ActionResult GetBuyOrderTempByChln(string chln)
        {
            DataTable dt = _buyOrderTempService.GetBuyOrderTempByChln(chln);

            var list = JsonConvert.SerializeObject(new { data = dt }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        public ActionResult GetBuyOrderTempBySupID(string supID)
        {
            DataTable dt = _buyOrderTempService.GetBuyOrderTempBySupID(supID);

            var list = JsonConvert.SerializeObject(new { data = dt }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        public ActionResult CheckPOTempByBarCodeSupID(string barcode)
        {
            var list = "ok";
            DataTable dt = _buyOrderTempService.GetBuyOrderTempByBarCode(barcode);
            if (dt.Rows.Count > 0)
            {
                //exits in buy order temp
                list = JsonConvert.SerializeObject(new { data = "Temp", result = true }, Formatting.None,
                      new JsonSerializerSettings()
                      {
                          ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                      });
            }
            else
            {
                DataTable dtPO = _buyOrderService.GetNotRecieveByBarCode(barcode);
                if (dtPO.Rows.Count > 0)
                {
                    //yet not receive this PO
                    list = JsonConvert.SerializeObject(new { data = "BuyOrder", result = true }, Formatting.None,
                       new JsonSerializerSettings()
                       {
                           ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                       });
                }
                else
                {
                    list = JsonConvert.SerializeObject(new { data = "AddNew", result = true }, Formatting.None,
                     new JsonSerializerSettings()
                     {
                         ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                     });
                }
            }

            return Content(list, "application/json");
        }

        private IEnumerable<StyleSizeViewModel> mStyleSizeGetBySupID(string supID)
        {
            IEnumerable<StyleSizeViewModel> result = null;
            IEnumerable<StyleSize> datas = _styleSizeService.GetstyleSizeBySupID(supID);
            result = Mapper.Map<IEnumerable<StyleSize>, IEnumerable<StyleSizeViewModel>>(datas);
            return result;
        }

        public ActionResult GetBuyOrderTotalAmount(string supID)
        {
            DataTable dt = _buyOrderTempService.GetBuyOrderTempBySupID(supID);
            decimal TotalOrderAmount = 0;
            foreach (DataRow dr in dt.Rows)
            {
                if (dr["Qty"] != null && dr["CPU"] != null)
                {
                    TotalOrderAmount += Convert.ToDecimal(dr["Qty"].ToString()) * Convert.ToDecimal(dr["CPU"].ToString());
                }
            }

            var list = JsonConvert.SerializeObject(new { data = TotalOrderAmount }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        public ActionResult PurchaseOrderTempGetDistinctChln(string a)
        {
            var chlnList = new GlobalClass().GetDistinctValue("Chln", "BuyOrderTemp");
            var list = JsonConvert.SerializeObject(new { data = chlnList }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        public ActionResult InsertBuyOrderFromTemp(List<BuyOrderTempViewModel> model)
        {
            string chlnNo = string.Empty;
            foreach (BuyOrderTempViewModel modelData in model)
            {
                DataTable dt = _buyOrderTempService.GetBuyOrderTempByChln(modelData.Chln);
                List<BuyOrder> map = mapBuyOrderTempToBuyOrders(dt);
                foreach (BuyOrder buyOrder in map)
                {
                    chlnNo = buyOrder.Chln;
                    _buyOrderService.Create(buyOrder);
                }
            }

            _buyOrderService.Save();

            try
            {
                foreach (BuyOrderTempViewModel modelData in model)
                {
                    DataTable dt = _buyOrderTempService.GetBuyOrderTempByChln(modelData.Chln);
                    foreach (DataRow dr in dt.Rows)
                    {
                        _buyOrderTempService.DeleteBuyOrderTempByCmpIDX(dr["CmpIDX"].ToString());
                    }
                }

                //return rest of the things
                IEnumerable<BuyOrderTempViewModel> result = null;
                IEnumerable<BuyOrderTemp> datas = _buyOrderTempService.Gets();
                result = Mapper.Map<IEnumerable<BuyOrderTemp>, IEnumerable<BuyOrderTempViewModel>>(datas);

                var list = JsonConvert.SerializeObject(new { data = result, Error = "Saved", chln = chlnNo }, Formatting.None,
                            new JsonSerializerSettings()
                            {
                                ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                            });

                return Content(list, "application/json");
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        private List<BuyOrder> mapBuyOrderTempToBuyOrders(DataTable dt)
        {
            List<BuyOrder> boList = new List<BuyOrder>();
            string Chln = "0";

            if (dt.Rows.Count > 0)
            {
                Chln = new GlobalClass().GetMaxIdByWhereVar("Chln", "BuyOrder", "SupID", dt.Rows[0]["SupID"].ToString());
                if (Chln == "1")
                    Chln = dt.Rows[0]["SupID"].ToString() + "00000";
            }

            foreach (DataRow dr in dt.Rows)
            {
                BuyOrder bo = new BuyOrder();
                bo.BarCode = dr["BarCode"].ToString();
                bo.CPU = dr["DiscPrcnt"] != null ? Convert.ToDecimal(dr["DiscPrcnt"].ToString()) : 0;
                bo.CPU = dr["VATPrcnt"] != null ? Convert.ToDecimal(dr["VATPrcnt"].ToString()) : 0;
                bo.CPU = dr["PrdComm"] != null ? Convert.ToDecimal(dr["PrdComm"].ToString()) : 0;
                bo.CPU = dr["CPU"] != null ? Convert.ToDecimal(dr["CPU"].ToString()) : 0;
                bo.RPU = dr["RPU"] != null ? Convert.ToDecimal(dr["RPU"].ToString()) : 0;
                bo.sBarCode = dr["sBarCode"].ToString();
                bo.sBarCode = dr["sBarCode"].ToString();
                bo.Chln = Chln;
                bo.CmpIDX = dr["sBarCode"].ToString().Remove(0);
                bo.BuyDT = dr["BuyDT"].ToString() == "" ? DateTime.Now : Convert.ToDateTime(dr["BuyDT"].ToString());
                bo.EXPDT = dr["EXPDT"].ToString() == "" ? DateTime.Now : Convert.ToDateTime(dr["EXPDT"].ToString());
                bo.CmpIDX = Chln + dr["BarCode"].ToString();
                bo.Qty = dr["Qty"] == "" ? 0 : Convert.ToDecimal(dr["Qty"].ToString());
                bo.SupID = dr["SupID"].ToString();
                bo.sQty = 0;
                bo.UserID = dr["UserID"].ToString();
                boList.Add(bo);
            }
            return boList;
        }

        private ActionResult mDeleteBuyOrderTemp(List<BuyOrderTempViewModel> model, string MsgType)
        {
            try
            {
                foreach (BuyOrderTempViewModel modelData in model)
                {
                    DataTable dt = _buyOrderTempService.GetBuyOrderTempByChln(modelData.Chln);
                    foreach (DataRow dr in dt.Rows)
                    {
                        _buyOrderTempService.DeleteBuyOrderTempByCmpIDX(dr["CmpIDX"].ToString());
                    }
                }

                //return rest of the things
                IEnumerable<BuyOrderTempViewModel> result = null;
                IEnumerable<BuyOrderTemp> datas = _buyOrderTempService.Gets();
                result = Mapper.Map<IEnumerable<BuyOrderTemp>, IEnumerable<BuyOrderTempViewModel>>(datas);

                var list = JsonConvert.SerializeObject(new { data = result, Error = MsgType }, Formatting.None,
                            new JsonSerializerSettings()
                            {
                                ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                            });

                return Content(list, "application/json");
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult DeleteBuyOrderFromTemp(List<BuyOrderTempViewModel> model)
        {
            return mDeleteBuyOrderTemp(model, "Deleted");
        }

        #endregion

        #region Purchase Receive / BuyCentral
        public ActionResult PurchaseReceive()
        {
            if (!IsPermissionApply("Process", "PurchaseReceive"))
            {
                return RedirectToAction("Index", "Home");
            }

            List<SupplierViewModel> resultSupplier = null;
            IEnumerable<Supplier> dataSupplier = _supplierService.Gets();
            resultSupplier = Mapper.Map<IEnumerable<Supplier>, IEnumerable<SupplierViewModel>>(dataSupplier).ToList();
            SupplierViewModel obj = new SupplierViewModel();
            obj.SupID = "";
            obj.Supname = "Select";
            resultSupplier.Insert(0, obj);

            ViewBag.SuppliersList = new SelectList(resultSupplier, "SupID", "Supname");

            return View();
        }

        [HttpPost]
        public ActionResult CreatePurchaseReceive(BuyCentralViewModel model)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    BuyCentral dbModel = new BuyCentral();
                    dbModel = Mapper.Map<BuyCentralViewModel, BuyCentral>(model);

                    #region duplicate check
                    //for new item duplicate check  primary key must be zero
                    dbModel.CMPIDX = "0";
                    if (_buyCentralService.IsDuplicate(dbModel))
                    {
                        return Json(new { result = false, Error = "Duplicate Data" }, JsonRequestBehavior.AllowGet);
                    }
                    #endregion

                    _buyCentralService.Create(dbModel);
                    _buyCentralService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult UpdateBuyCentral(BuyCentralViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var data = _buyCentralService.Get(model.CMPIDX);
                    // data.GroupName = model.GroupName;
                    if (_buyCentralService.IsDuplicate(data))
                    {
                        return Json(new { result = false, Error = "Duplicate Data" }, JsonRequestBehavior.AllowGet);
                    }

                    _buyCentralService.Update(data);
                    _buyCentralService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult DeleteBuyCentral(BuyCentralViewModel model)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    var data = _buyCentralService.Get(model.CMPIDX);
                    _buyCentralService.Remove(data);
                    _buyCentralService.Save();

                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetCSByBarCode(string BarCode)
        {
            string balQty = "0";
            DataTable dt = _buyCentralService.GetCSByBarCode(BarCode);
            if (dt.Rows.Count > 0)
            {
                balQty = dt.Rows[0]["balQty"].ToString();
            }
            var list = JsonConvert.SerializeObject(new { data = balQty }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }
        public ActionResult BuyCentralList()
        {
            IEnumerable<BuyCentralViewModel> result = null;
            IEnumerable<BuyCentral> datas = _buyCentralService.Gets();
            result = Mapper.Map<IEnumerable<BuyCentral>, IEnumerable<BuyCentralViewModel>>(datas);

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        public ActionResult GetCentralStockByType(string Type)
        {
            // type= All or NonZero or Zero
            DataTable datas = _buyCentralService.GetCentralStockByType(Type);
            var list = JsonConvert.SerializeObject(new { data = datas }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        public ActionResult BuyCentralFindByBarcode(string BarCode)
        {
            DataTable datas = _buyCentralService.GetByBarCode(BarCode);

            var list = JsonConvert.SerializeObject(new { data = datas }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        public ActionResult BuyCentralFindByCmpIDX(string cMPIDX)
        {
            BuyCentralViewModel result = mBuyCentralFindBycMPIDX(cMPIDX);

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        private BuyCentralViewModel mBuyCentralFindBycMPIDX(string cMPIDX)
        {
            BuyCentralViewModel result = null;
            BuyCentral datas = _buyCentralService.Get(cMPIDX);
            result = Mapper.Map<BuyCentral, BuyCentralViewModel>(datas);
            return result;
        }

        public ActionResult BuyCentralChlnNoFindBySupID(string supID)
        {
            var NewChlnNo = GetPurchaseReceiveID(supID);

            var list = JsonConvert.SerializeObject(new { data = NewChlnNo }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        private static string GetPurchaseReceiveID(string supID)
        {
            string NewChlnNo = new GlobalClass().GetMaxIdWithPrfix("Chln", "5", "00000", "rChallan", supID);
            if (NewChlnNo == "1")
                NewChlnNo = supID + "00000";
            return NewChlnNo;
        }

        #endregion

        #region ============ rChallan ============

        public ActionResult rChallan()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CreaterChallan(List<rChallanViewModel> model)
        {
            string chlnNo = "";
            try
            {
                List<TempTableValue> datas = _tempTableValueService.Gets().ToList();
                //delete from rChallan Temp
                List<rChallanViewModel> result = new List<rChallanViewModel>();
                TempTableValue isFound = datas.FirstOrDefault(m => m.TableOperation == "rChallanTemp");
                if (isFound != null)
                {
                    result = Newtonsoft.Json.JsonConvert.DeserializeObject<List<rChallanViewModel>>(isFound.TableValue);
                    if (result != null)
                    {
                        foreach (rChallanViewModel modelData in model)
                        {
                            //get from temp 
                            List<rChallanViewModel> findList = result.FindAll(m => m.Chln == modelData.Chln);
                            rChallanViewModel findOne = result.FirstOrDefault(m => m.Chln == modelData.Chln);
                            string chln = GetPurchaseReceiveID(findList[0].SupID);
                            chlnNo = chln;

                            decimal temp = 0;
                            decimal nTotalChallanVal = 0;
                            foreach (rChallanViewModel val in findList)
                            {
                                val.Chln = chln;
                                val.CmpIDX = chln + val.BarCode;
                                decimal.TryParse(val.ChlnTotal.ToString(), out temp);
                                rChallan nList = Mapper.Map<rChallanViewModel, rChallan>(val);
                                _rchallanService.Create(nList);
                            }

                            AccountsChln objAccountsChln = new AccountsChln();
                            objAccountsChln.Chln = chln;
                            objAccountsChln.BuyDt = findOne.BuyDT;
                            objAccountsChln.SupRef = findOne.SupRef;
                            objAccountsChln.SupName = findOne.SupName;
                            objAccountsChln.SupID = findOne.SupID;
                            objAccountsChln.TotalPrdComm = 0;

                            if (findOne.ChlnTotal == 0 && findOne.AddPrdComm == null)
                            {
                                decimal ChlnTotal = 0;
                                foreach (rChallanViewModel rc in findList)
                                {
                                    ChlnTotal += Convert.ToDecimal(rc.CPU*rc.Qty);
                                }
                                objAccountsChln.ChlnTotal = ChlnTotal;
                                objAccountsChln.AddPrdComm = 0;
                            }
                            else
                            {
                                objAccountsChln.ChlnTotal = findOne.ChlnTotal;
                                objAccountsChln.AddPrdComm = findOne.AddPrdComm;
                            }
                            objAccountsChln.UserID = findOne.UserID;
                            objAccountsChln.Transfer = findOne.Transfer;
                            _accountsChlnService.Create(objAccountsChln);

                            //for BuyCentral

                            #region BuyCentral

                            foreach (rChallanViewModel rc in findList)
                            {
                                rc.Chln = chln;
                                BuyCentral buyCentralValue = new BuyCentral();
                                buyCentralValue = _buyCentralService.GetObjByBarcode(rc.BarCode);
                                if (buyCentralValue != null)
                                {
                                    //avg calculation
                                    decimal oldsum = Convert.ToDecimal(buyCentralValue.Qty) * Convert.ToDecimal(buyCentralValue.CPU);
                                    decimal newSum = Convert.ToDecimal(rc.Qty) * Convert.ToDecimal(rc.CPU);
                                    decimal avgCPU=(oldsum+newSum)/(Convert.ToDecimal(rc.Qty)+Convert.ToDecimal(buyCentralValue.Qty));

                                    buyCentralValue.LCPU = buyCentralValue.CPU; // old cpu in LCPU
                                    buyCentralValue.CPU = Math.Round(avgCPU,2); // new Avg CPU
                                    buyCentralValue.Chln = rc.Chln;
                                    buyCentralValue.Qty = buyCentralValue.Qty + rc.Qty + rc.bQty;
                                    buyCentralValue.bQty = buyCentralValue.bQty + rc.bQty;
                                    buyCentralValue.balQty = buyCentralValue.balQty + rc.Qty + rc.bQty;
                                    buyCentralValue.EXPDT = rc.EXPDT;
                                    buyCentralValue.BuyDT = rc.BuyDT;
                                    buyCentralValue.VATPrcnt = rc.VATPrcnt;
                                    buyCentralValue.DiscPrcnt = rc.DiscPrcnt;
                                    buyCentralValue.PrdComm = rc.PrdComm;
                                    buyCentralValue.LastSDT = rc.LastSDT;
                                    buyCentralValue.ShopID = rc.ShopID;
                                    buyCentralValue.Transfer = rc.Transfer;
                                    buyCentralValue.RPU = rc.RPU;
                                    _buyCentralService.Update(buyCentralValue);
                                }
                                else
                                {
                                    BuyCentral buyCentralValue2 = new BuyCentral();
                                    buyCentralValue2.CMPIDX = string.Concat(rc.sBarCode, rc.BarCode);
                                    buyCentralValue2.Chln = rc.Chln;
                                    buyCentralValue2.sBarCode = rc.sBarCode;
                                    buyCentralValue2.CPU = rc.CPU;
                                    buyCentralValue2.RPU = rc.RPU;
                                    buyCentralValue2.BarCode = rc.BarCode;
                                    buyCentralValue2.LCPU = 0;
                                    buyCentralValue2.Qty = rc.Qty;
                                    buyCentralValue2.bQty = rc.bQty;
                                    buyCentralValue2.ShopReturn = 0;
                                    buyCentralValue2.sreturn = 0;

                                    buyCentralValue2.wSqty = 0;
                                    buyCentralValue2.sQty = rc.sQty;
                                    buyCentralValue2.rQty = 0;
                                    buyCentralValue2.srpQty = 0;
                                    buyCentralValue2.dmlqty = 0;
                                    buyCentralValue2.InvQty = 0;
                                    buyCentralValue2.balQty = rc.Qty;
                                    buyCentralValue2.BuyDT = rc.BuyDT;
                                    buyCentralValue2.EXPDT = rc.EXPDT;
                                    buyCentralValue2.LastSDT = rc.LastSDT;
                                    buyCentralValue2.ShopID = rc.ShopID;
                                    buyCentralValue2.Transfer = rc.Transfer;

                                    buyCentralValue2.VATPrcnt = rc.VATPrcnt;
                                    buyCentralValue2.DiscPrcnt = rc.DiscPrcnt;
                                    buyCentralValue2.PrdComm = rc.PrdComm;

                                    _buyCentralService.Create(buyCentralValue2);
                                }
                            }
                            #endregion

                            result.RemoveAll(m => m.Chln == chln);

                        }
                    }
                    _accountsChlnService.Save();
                    _rchallanService.Save();
                    _buyCentralService.Save();
                    TempTableValue obj = new TempTableValue();
                    obj.TableID = isFound.TableID;
                    obj.TableOperation = "rChallanTemp";
                    obj.TableValue = Newtonsoft.Json.JsonConvert.SerializeObject(result, Newtonsoft.Json.Formatting.None);

                    _tempTableValueService.Remove(isFound);
                    _tempTableValueService.Create(obj);
                    _tempTableValueService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Saved", chlnNo = chlnNo }, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult DeleterChallan(List<rChallanViewModel> model)
        {
            try
            {
                List<string> newList = new List<string>();
                foreach (rChallanViewModel modelData in model)
                {
                    newList.Add(modelData.Chln);
                }
                List<string> Listchln = new List<string>();
                Listchln.AddRange(newList.Distinct());

                //delete from rChallan Temp
                List<rChallanViewModel> result = new List<rChallanViewModel>();
                List<TempTableValue> datas = _tempTableValueService.Gets().ToList();
                TempTableValue isFound = datas.FirstOrDefault(m => m.TableOperation == "rChallanTemp");
                if (isFound != null)
                {
                    result = Newtonsoft.Json.JsonConvert.DeserializeObject<List<rChallanViewModel>>(isFound.TableValue);
                    if (result != null)
                    {
                        foreach (string chln in Listchln)
                        {
                            result.RemoveAll(m => m.Chln == chln);
                        }
                    }

                    TempTableValue obj = new TempTableValue();
                    obj.TableID = isFound.TableID;
                    obj.TableOperation = "rChallanTemp";
                    obj.TableValue = Newtonsoft.Json.JsonConvert.SerializeObject(result, Newtonsoft.Json.Formatting.None);

                    _tempTableValueService.Remove(isFound);
                    _tempTableValueService.Create(obj);
                    _tempTableValueService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult rChallanList()
        {
            IEnumerable<rChallanViewModel> result = null;
            IEnumerable<rChallan> datas = _rchallanService.Gets();
            result = Mapper.Map<IEnumerable<rChallan>, IEnumerable<rChallanViewModel>>(datas);

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        public ActionResult rChallanFindByCmpIDX(string cmpIDX)
        {
            rChallanViewModel result = mrChallanFindByCmpIDX(cmpIDX);

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        private rChallanViewModel mrChallanFindByCmpIDX(string cmpIDX)
        {
            rChallanViewModel result = null;
            rChallan datas = _rchallanService.Get(cmpIDX);
            result = Mapper.Map<rChallan, rChallanViewModel>(datas);
            return result;
        }

        public ActionResult rChallanChlnNoFindBySupID(string supID)
        {
            string NewChlnNo = new GlobalClass().GetMaxIdByWhereVar("Chln", "AccountsChln", "SupID", supID);
            if (NewChlnNo == "1")
                NewChlnNo = supID + "00000";

            var list = JsonConvert.SerializeObject(new { data = NewChlnNo }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        public ActionResult rChallanFindByChln(string chln)
        {
            IEnumerable<rChallanViewModel> result = null;
            IEnumerable<rChallan> datas = _rchallanService.GetrChallanByChln(chln);
            result = Mapper.Map<IEnumerable<rChallan>, IEnumerable<rChallanViewModel>>(datas);

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });
            return Content(list, "application/json");
        }

        #endregion

        #region =============== rChallan Temp Data ==========
        [HttpPost]
        public ActionResult CreaterChallanTemp(rChallanViewModel dbModel)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    List<rChallanViewModel> result = null;
                    List<TempTableValue> datas = _tempTableValueService.Gets().ToList();

                    TempTableValue isFound = datas.FirstOrDefault(m => m.TableOperation == "rChallanTemp");

                    if (isFound != null)
                    {
                        if (isFound.TableValue == "[]")
                        {
                            _tempTableValueService.Remove(isFound);
                            isFound = null;
                        }
                    }

                    string NewChlnNo = new GlobalClass().GetMaxIdByWhereVar("Chln", "AccountsChln", "SupID", dbModel.SupID);
                    if (NewChlnNo == "1")
                        NewChlnNo = dbModel.SupID + "00000";
                    dbModel.Chln = "T" + NewChlnNo;
                    decimal AddRecvQty = 0;
                    if (isFound != null)
                    {
                        AddRecvQty = Convert.ToDecimal(dbModel.Qty);
                        result = Newtonsoft.Json.JsonConvert.DeserializeObject<List<rChallanViewModel>>(isFound.TableValue);
                        dbModel.CmpIDX = dbModel.Chln + dbModel.BarCode;
                        var checkExists = result.FindAll(m => m.CmpIDX == dbModel.CmpIDX);
                        if (checkExists.Count > 0)
                        {
                            // if exists then add previous bQty and Qty with new inserted value
                            rChallanViewModel tempTableExists = result.Find(m => m.CmpIDX == dbModel.CmpIDX);
                            dbModel.Qty = dbModel.Qty + tempTableExists.Qty;
                            dbModel.bQty = dbModel.bQty + tempTableExists.bQty;
                            result.Remove(tempTableExists);
                        }

                        if (dbModel.bQty == null)
                            dbModel.bQty = 0;
                        dbModel.BuyDT = DateTime.Now;
                        dbModel.ACPU = dbModel.CPU;
                        dbModel.ShopID = "CS";
                        dbModel.Transfer = "N";
                        dbModel.UserID = User.Identity.Name;

                        dbModel.cSqty = 0;
                        dbModel.dmlqty = 0;
                        dbModel.rQty = 0;
                        dbModel.sQty = 0;
                        dbModel.VPP = 0;
                        dbModel.VPU = 0;
                        result.Add(dbModel);

                        TempTableValue obj = new TempTableValue();
                        obj.TableID = isFound.TableID;
                        obj.TableOperation = "rChallanTemp";
                        obj.TableValue = Newtonsoft.Json.JsonConvert.SerializeObject(result,
                            Newtonsoft.Json.Formatting.None);

                        _tempTableValueService.Remove(isFound);

                        _tempTableValueService.Create(obj);
                        _tempTableValueService.Save();
                    }
                    else
                    {
                        if (dbModel.bQty == null)
                            dbModel.bQty = 0;
                        dbModel.CmpIDX = dbModel.Chln + dbModel.BarCode;
                        dbModel.ShopID = "CS";
                        dbModel.Transfer = "N";
                        dbModel.UserID = User.Identity.Name;
                        dbModel.ACPU = dbModel.CPU;
                        dbModel.cSqty = 0;
                        dbModel.dmlqty = 0;
                        dbModel.rQty = 0;
                        dbModel.sQty = 0;
                        dbModel.TotalPrdComm = 0;
                        dbModel.VPP = 0;
                        dbModel.VPU = 0;
                        AddRecvQty = Convert.ToDecimal(dbModel.Qty);
                        List<rChallanViewModel> objChln = new List<rChallanViewModel>();
                        objChln.Add(dbModel);

                        TempTableValue obj = new TempTableValue();
                        obj.TableID = decimal.Parse(new GlobalClass().GetMaxId("TableID", "TempTableValue"));
                        obj.TableOperation = "rChallanTemp";
                        obj.TableValue = Newtonsoft.Json.JsonConvert.SerializeObject(objChln,
                            Newtonsoft.Json.Formatting.None);
                        _tempTableValueService.Create(obj);
                        _tempTableValueService.Save();
                    }

                    string OrderNo = dbModel.OrderNo;
                    string barCode = dbModel.BarCode;
                    if (OrderNo != "")
                    {
                        _buyOrderService.UpdatesQty(OrderNo, barCode, AddRecvQty, "Add");
                        _buyOrderService.Save();
                    }
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult PurchaseReceiveTempCommCalc(string SupID, string ChalnTotal, string DiscPrc, string DiscAmnt, string SupTotal, string AddCost, string NetAmnt)
        {
            try
            {
                List<TempTableValue> datas = _tempTableValueService.Gets().ToList();
                List<rChallanViewModel> result = new List<rChallanViewModel>();
                TempTableValue isFound = datas.FirstOrDefault(m => m.TableOperation == "rChallanTemp");
                if (isFound != null)
                {
                    result = Newtonsoft.Json.JsonConvert.DeserializeObject<List<rChallanViewModel>>(isFound.TableValue);
                    if (result != null)
                    {
                        decimal ChalnTotald = Convert.ToDecimal(ChalnTotal);
                        decimal DiscPrcd = Convert.ToDecimal(DiscPrc);
                        decimal DiscAmntd = Convert.ToDecimal(DiscAmnt);
                        decimal SupTotald = Convert.ToDecimal(SupTotal);
                        decimal AddCostd = Convert.ToDecimal(AddCost);
                        decimal NetAmntd = Convert.ToDecimal(NetAmnt);

                        decimal cngCPU = 0;
                        decimal diffAmnt = 0;
                        if (ChalnTotald > NetAmntd)
                        {
                            diffAmnt = ChalnTotald - NetAmntd;
                        }
                        else
                        {
                            diffAmnt = NetAmntd - ChalnTotald;
                        }

                        //get by supID
                        List<rChallanViewModel> findList = result.FindAll(m => m.SupID == SupID);
                        foreach (rChallanViewModel r in findList)
                        {
                            result.Remove(r);
                        }

                        foreach (rChallanViewModel val in findList)
                        {
                            decimal ownTotalCpu = Convert.ToDecimal(val.ACPU)*Convert.ToDecimal(val.Qty);
                            decimal contribution = Math.Round((diffAmnt*ownTotalCpu)/ChalnTotald,2);
                            cngCPU = Math.Round(contribution / Convert.ToDecimal(val.Qty),2);
                            if (ChalnTotald > NetAmntd)
                            {
                                val.ACPU = Math.Round(Convert.ToDecimal(val.ACPU), 2);
                                val.CPU = Math.Round(Convert.ToDecimal(val.ACPU), 2)-cngCPU;
                                val.ChlnTotal = SupTotald;
                                val.AddPrdComm = DiscAmntd;
                                val.AddiCost = AddCostd;
                            }
                            else
                            {
                                val.ACPU = Math.Round(Convert.ToDecimal(val.ACPU), 2);
                                val.CPU = Math.Round(Convert.ToDecimal(val.ACPU), 2) + cngCPU;
                                val.ChlnTotal = SupTotald;
                                val.AddPrdComm = DiscAmntd;
                                val.AddiCost = AddCostd;
                            }
                            result.Add(val);
                        }
                    }

                    TempTableValue obj = new TempTableValue();
                    obj.TableID = isFound.TableID;
                    obj.TableOperation = "rChallanTemp";
                    obj.TableValue = Newtonsoft.Json.JsonConvert.SerializeObject(result, Newtonsoft.Json.Formatting.None);

                    _tempTableValueService.Remove(isFound);
                    _tempTableValueService.Create(obj);
                    _tempTableValueService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult SameAsPOCreaterChallanTemp(string PO)
        {
            try
            {
                DataTable dtStyleSize = _buyOrderService.GetNotRecPOStyleByChln(PO);
                foreach (DataRow dr in dtStyleSize.Rows)
                {
                    DataTable dtStyleSizeDetails = _buyOrderService.GetBuyOrderByCmpIDX(dr["CmpIDX"].ToString());
                    foreach (DataRow drDetails in dtStyleSizeDetails.Rows)
                    {
                        decimal temp;
                        rChallanViewModel rc = new rChallanViewModel();
                        rc.OrderNo = PO;
                        rc.CmpIDX = drDetails["CmpIDX"].ToString();
                        rc.sBarCode = drDetails["sBarCode"].ToString();
                        rc.BarCode = drDetails["BarCode"].ToString();
                        rc.EXPDT = DateTime.Now;
                        rc.BuyDT = DateTime.Now;
                        rc.SSName = drDetails["SSName"].ToString();
                        rc.GroupName = drDetails["GroupName"].ToString();
                        rc.Prdname = drDetails["Prdname"].ToString();
                        rc.BTname = drDetails["BTname"].ToString();
                        decimal.TryParse(drDetails["PrdComm"].ToString(), out temp);
                        rc.PrdComm = temp;
                        decimal.TryParse(drDetails["WSP"].ToString(), out temp);
                        rc.WSP = temp;
                        decimal.TryParse(drDetails["WSQ"].ToString(), out temp);
                        rc.WSQ = temp;
                        decimal.TryParse(drDetails["DiscPrcnt"].ToString(), out temp);
                        rc.DiscPrcnt = temp;
                        decimal.TryParse(drDetails["VATPrcnt"].ToString(), out temp);
                        rc.VATPrcnt = temp;
                        decimal.TryParse(drDetails["Qty"].ToString(), out temp);
                        rc.POQty = temp;
                        decimal.TryParse(drDetails["Qty"].ToString(), out temp);
                        rc.Qty = temp;
                        rc.SupID = drDetails["SupID"].ToString();
                        rc.SupName = drDetails["SupName"].ToString();
                        decimal.TryParse(drDetails["Reorder"].ToString(), out temp);
                        rc.Reorder = temp;
                        rc.ZoneID = drDetails["ZoneID"].ToString();
                        decimal.TryParse(drDetails["Point"].ToString(), out temp);
                        rc.Point = temp;
                        rc.SupRef = "Nil";
                        decimal.TryParse(drDetails["RPP"].ToString(), out temp);
                        rc.RPP = temp;
                        rc.bQty = 0;
                        rc.BuyDT = DateTime.Now;
                        decimal.TryParse(drDetails["CPU"].ToString(), out temp);
                        rc.CPU = temp;
                        rc.ACPU = temp;
                        decimal.TryParse(drDetails["RPU"].ToString(), out temp);
                        rc.RPU = temp;
                        rc.AddPrdComm = 0;
                        rc.AddiCost = 0;
                        rc.ChlnTotal = rc.Qty * rc.ACPU;
                        SameAsPOInsert(rc);
                    }
                }
                return Json(new { result = false, Error = "Saved" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        private void SameAsPOInsert(rChallanViewModel dbModel)
        {
            List<rChallanViewModel> result = null;
            List<TempTableValue> datas = _tempTableValueService.Gets().ToList();

            TempTableValue isFound = datas.FirstOrDefault(m => m.TableOperation == "rChallanTemp");

            if (isFound != null)
            {
                if (isFound.TableValue == "[]")
                {
                    _tempTableValueService.Remove(isFound);
                    isFound = null;
                }
            }

            string NewChlnNo = new GlobalClass().GetMaxIdByWhereVar("Chln", "AccountsChln", "SupID", dbModel.SupID);
            if (NewChlnNo == "1")
                NewChlnNo = dbModel.SupID + "00000";
            dbModel.Chln = "T" + NewChlnNo;
            if (isFound != null)
            {
                result = Newtonsoft.Json.JsonConvert.DeserializeObject<List<rChallanViewModel>>(isFound.TableValue);
                dbModel.CmpIDX = dbModel.Chln + dbModel.BarCode;
                var checkExists = result.FindAll(m => m.CmpIDX == dbModel.CmpIDX);
                if (checkExists.Count > 0)
                {
                    // if exists then add previous bQty and Qty with new inserted value
                    rChallanViewModel tempTableExists = result.Find(m => m.CmpIDX == dbModel.CmpIDX);
                    dbModel.Qty = dbModel.Qty + tempTableExists.Qty;
                    dbModel.bQty = dbModel.bQty + tempTableExists.bQty;
                    result.Remove(tempTableExists);
                }

                foreach (rChallanViewModel rc in result)
                {
                    rc.TotalPrdComm = dbModel.TotalPrdComm;
                    rc.AddPrdComm = dbModel.AddPrdComm;
                }

                if (dbModel.bQty == null)
                    dbModel.bQty = 0;

                dbModel.ShopID = "CS";
                dbModel.Transfer = "N";
                dbModel.UserID = User.Identity.Name;

                dbModel.cSqty = 0;
                dbModel.dmlqty = 0;
                dbModel.rQty = 0;
                dbModel.sQty = 0;
                dbModel.TotalPrdComm = 0;
                dbModel.VPP = 0;
                dbModel.VPU = 0;
                result.Add(dbModel);

                TempTableValue obj = new TempTableValue();
                obj.TableID = isFound.TableID;
                obj.TableOperation = "rChallanTemp";
                obj.TableValue = Newtonsoft.Json.JsonConvert.SerializeObject(result,
                    Newtonsoft.Json.Formatting.None);

                _tempTableValueService.Remove(isFound);

                _tempTableValueService.Create(obj);
                _tempTableValueService.Save();
            }
            else
            {
                if (dbModel.bQty == null)
                    dbModel.bQty = 0;
                dbModel.CmpIDX = dbModel.Chln + dbModel.BarCode;
                dbModel.ShopID = "CS";
                dbModel.Transfer = "N";
                dbModel.UserID = User.Identity.Name;

                dbModel.cSqty = 0;
                dbModel.dmlqty = 0;
                dbModel.rQty = 0;
                dbModel.sQty = 0;
                dbModel.TotalPrdComm = 0;
                dbModel.VPP = 0;
                dbModel.VPU = 0;

                List<rChallanViewModel> objChln = new List<rChallanViewModel>();
                objChln.Add(dbModel);

                TempTableValue obj = new TempTableValue();
                obj.TableID = decimal.Parse(new GlobalClass().GetMaxId("TableID", "TempTableValue"));
                obj.TableOperation = "rChallanTemp";
                obj.TableValue = Newtonsoft.Json.JsonConvert.SerializeObject(objChln,
                    Newtonsoft.Json.Formatting.None);
                _tempTableValueService.Create(obj);
                _tempTableValueService.Save();
            }

            string OrderNo = dbModel.OrderNo;
            string barCode = dbModel.BarCode;
            if (OrderNo != "")
            {
                _buyOrderService.UpdatesQty(OrderNo, barCode, Convert.ToDecimal(dbModel.Qty), "Add");
                _buyOrderService.Save();
            }
        }

        public ActionResult UpdateQtyChallanTemp(string CmpIDX, string Qty)
        {
            try
            {
                List<rChallanViewModel> result = null;
                List<TempTableValue> datas = _tempTableValueService.Gets().ToList();

                TempTableValue isFound = datas.FirstOrDefault(m => m.TableOperation == "rChallanTemp");
                if (isFound != null)
                {
                    result = Newtonsoft.Json.JsonConvert.DeserializeObject<List<rChallanViewModel>>(isFound.TableValue);
                    if (result != null)
                    {
                        rChallanViewModel isFoundrChallan = result.FirstOrDefault(m => m.CmpIDX == CmpIDX);
                        string SupID = isFoundrChallan.SupID;
                        decimal oldQty = Convert.ToDecimal(isFoundrChallan.Qty);
                        decimal newQty = Convert.ToDecimal(Qty);
                        result.Remove(isFoundrChallan);

                        // updatea rChallan row value
                        rChallanViewModel objrChallan = new rChallanViewModel();
                        objrChallan.CmpIDX = isFoundrChallan.CmpIDX;
                        objrChallan.Chln = isFoundrChallan.Chln;
                        objrChallan.OrderNo = isFoundrChallan.OrderNo;
                        objrChallan.sBarCode = isFoundrChallan.sBarCode;
                        objrChallan.BarCode = isFoundrChallan.BarCode;
                        objrChallan.CPU = isFoundrChallan.ACPU;
                        objrChallan.ACPU = isFoundrChallan.ACPU;
                        objrChallan.RPU = isFoundrChallan.RPU;
                        objrChallan.VPP = isFoundrChallan.VPP;
                        objrChallan.VPU = isFoundrChallan.VPU;
                        objrChallan.Qty = newQty;
                        objrChallan.sQty = isFoundrChallan.sQty;
                        objrChallan.bQty = isFoundrChallan.bQty;
                        objrChallan.cSqty = isFoundrChallan.cSqty;
                        objrChallan.rQty = isFoundrChallan.rQty;
                        objrChallan.dmlqty = isFoundrChallan.dmlqty;
                        objrChallan.EXPDT = isFoundrChallan.EXPDT;
                        objrChallan.LastSDT = isFoundrChallan.LastSDT;
                        objrChallan.ShopID = isFoundrChallan.ShopID;
                        objrChallan.Transfer = isFoundrChallan.Transfer;
                        objrChallan.TotalPrdComm = 0;
                        objrChallan.ChlnTotal = 0;
                        objrChallan.SupRef = isFoundrChallan.SupRef;
                        objrChallan.UserID = isFoundrChallan.UserID;

                        objrChallan.AddPrdComm = 0;
                        objrChallan.balQty = isFoundrChallan.balQty;
                        objrChallan.BTname = isFoundrChallan.BTname;
                        objrChallan.BuyDT = isFoundrChallan.BuyDT;
                        objrChallan.DiscPrcnt = isFoundrChallan.DiscPrcnt;

                        objrChallan.GroupName = isFoundrChallan.GroupName;
                        objrChallan.LastSDT = isFoundrChallan.LastSDT;
                        objrChallan.Point = isFoundrChallan.Point;
                        objrChallan.POQty = isFoundrChallan.POQty;
                        objrChallan.PrdComm = isFoundrChallan.PrdComm;
                        objrChallan.Prdname = isFoundrChallan.Prdname;
                        objrChallan.Reorder = isFoundrChallan.Reorder;
                        objrChallan.RPP = isFoundrChallan.RPP;

                        objrChallan.SSName = isFoundrChallan.SSName;
                        objrChallan.SupID = isFoundrChallan.SupID;
                        objrChallan.SupName = isFoundrChallan.SupName;
                        objrChallan.VATPrcnt = isFoundrChallan.VATPrcnt;
                        objrChallan.WSP = isFoundrChallan.WSP;
                        objrChallan.WSQ = isFoundrChallan.WSQ;
                        objrChallan.ZoneID = isFoundrChallan.ZoneID;

                        //add updated row into rChallanList
                        result.Add(objrChallan);

                        if (oldQty != newQty)
                        {
                            //update BuyOrder sQty for this order no 
                            if (oldQty > newQty)
                            {
                                _buyOrderService.UpdatesQty(isFoundrChallan.OrderNo, isFoundrChallan.BarCode,
                                    oldQty - newQty, "Delete");
                                _buyOrderService.Save();
                            }
                            else if (newQty > oldQty)
                            {
                                _buyOrderService.UpdatesQty(isFoundrChallan.OrderNo, isFoundrChallan.BarCode,
                                    newQty - oldQty, "Add");
                                _buyOrderService.Save();
                            }
                        }
                        List<rChallanViewModel> oList = result.FindAll(m => m.SupID == SupID);
                        foreach (var rc in oList)
                        {
                            rc.CPU = rc.ACPU;
                        }
                    }

                    TempTableValue obj = new TempTableValue();
                    obj.TableID = isFound.TableID;
                    obj.TableOperation = "rChallanTemp";
                    obj.TableValue = Newtonsoft.Json.JsonConvert.SerializeObject(result, Newtonsoft.Json.Formatting.None);

                    _tempTableValueService.Remove(isFound);
                    _tempTableValueService.Create(obj);
                    _tempTableValueService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Updated" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult DeletePurchaseReceiveTemp(string cmpIDX)
        {
            try
            {
                if (cmpIDX != "")
                {
                    List<rChallanViewModel> result = null;
                    List<TempTableValue> datas = _tempTableValueService.Gets().ToList();

                    TempTableValue isFound = datas.FirstOrDefault(m => m.TableOperation == "rChallanTemp");
                    if (isFound != null)
                    {
                        result = Newtonsoft.Json.JsonConvert.DeserializeObject<List<rChallanViewModel>>(isFound.TableValue);
                        if (result != null)
                        {
                            rChallanViewModel getDeleteValue = result.FirstOrDefault(m => m.CmpIDX == cmpIDX);
                            string SupID = getDeleteValue.SupID;
                            result.RemoveAll(m => m.CmpIDX == cmpIDX);
                            string OrderNo = getDeleteValue.OrderNo;
                            string barCode = getDeleteValue.BarCode;
                            if (OrderNo != "")
                            {
                                _buyOrderService.UpdatesQty(OrderNo, barCode, Convert.ToDecimal(getDeleteValue.Qty), "Delete");
                                _buyOrderService.Save();
                            }

                            List<rChallanViewModel> oList = result.FindAll(m => m.SupID == SupID);
                            foreach (var rc in oList)
                            {
                                rc.CPU = rc.ACPU;
                            }
                        }

                        TempTableValue obj = new TempTableValue();
                        obj.TableID = isFound.TableID;
                        obj.TableOperation = "rChallanTemp";
                        obj.TableValue = Newtonsoft.Json.JsonConvert.SerializeObject(result, Newtonsoft.Json.Formatting.None);

                        _tempTableValueService.Remove(isFound);
                        _tempTableValueService.Create(obj);
                        _tempTableValueService.Save();
                    }
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult ChallanTempGetBySupID(string supID)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    List<rChallanViewModel> result = null;
                    List<TempTableValue> datas = _tempTableValueService.Gets().ToList();

                    TempTableValue isFound = datas.FirstOrDefault(m => m.TableOperation == "rChallanTemp");
                    if (isFound != null)
                    {
                        result = Newtonsoft.Json.JsonConvert.DeserializeObject<List<rChallanViewModel>>(isFound.TableValue);

                        List<rChallanViewModel> isFoundrChallan = result.FindAll(m => m.SupID == supID);

                        var list = JsonConvert.SerializeObject(new { data = isFoundrChallan }, Formatting.None,
                         new JsonSerializerSettings()
                         {
                             ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                         });

                        return Content(list, "application/json");
                    }
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ChallanTempGetByCmpIDX(string cmpIDX)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    List<rChallanViewModel> result = null;
                    List<TempTableValue> datas = _tempTableValueService.Gets().ToList();

                    TempTableValue isFound = datas.FirstOrDefault(m => m.TableOperation == "rChallanTemp");
                    if (isFound != null)
                    {
                        result = Newtonsoft.Json.JsonConvert.DeserializeObject<List<rChallanViewModel>>(isFound.TableValue);

                        rChallanViewModel isFoundrChallan = result.Find(m => m.CmpIDX == cmpIDX);
 
                        //get PObalQty from buyOrder
                        BuyOrder bo= new BuyOrder();
                        if (isFoundrChallan.OrderNo != "DIRECT")
                        {
                            bo = _buyOrderService.GetByChlnBarCode(isFoundrChallan.OrderNo, isFoundrChallan.BarCode);
                            isFoundrChallan.PObalQty = bo.Qty - bo.sQty;
                        }
                        var list = JsonConvert.SerializeObject(new { result = true, data = isFoundrChallan }, Formatting.None,
                         new JsonSerializerSettings()
                         {
                             ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                         });

                        return Content(list, "application/json");
                    }
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }
        public ActionResult PurchaseReceiveChlnNoFindBySupID(string supID)
        {
            string NewChlnNo = new GlobalClass().GetMaxIdByWhereVarChallan("Chln", "AccountsChln", "SupID", supID);

            if (NewChlnNo == "1")
                NewChlnNo = supID + "00000";

            var list = JsonConvert.SerializeObject(new { data = NewChlnNo }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        public ActionResult PurchaseReceiveChlnNoFindByPO(string pOrder)
        {
            try
            {
                DataTable dt = _buyOrderService.GetByChln(pOrder);
                if (dt.Rows.Count == 0)
                {
                    return Json(new { result = false, Error = "No data fount" }, JsonRequestBehavior.AllowGet);
                }

                string supID = dt.Rows[0]["SupID"].ToString();

                string NewChlnNo = new GlobalClass().GetMaxIdByWhereVarChallan("Chln", "AccountsChln", "SupID", supID);

                if (NewChlnNo == "1")
                    NewChlnNo = supID + "00000";

                var list = JsonConvert.SerializeObject(new { data = NewChlnNo, supID }, Formatting.None,
                    new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                    );

                return Content(list, "application/json");
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult PurchaseReceiveTempFindBySupID(string supID)
        {
            List<rChallanViewModel> isFoundrChallan = new List<rChallanViewModel>();
            List<rChallanViewModel> result = null;
            List<TempTableValue> datas = _tempTableValueService.Gets().ToList();

            TempTableValue isFound = datas.FirstOrDefault(m => m.TableOperation == "rChallanTemp");
            if (isFound != null)
            {
                result = Newtonsoft.Json.JsonConvert.DeserializeObject<List<rChallanViewModel>>(isFound.TableValue);
                isFoundrChallan = result.FindAll(m => m.SupID == supID);
            }

            var list = JsonConvert.SerializeObject(new { data = isFoundrChallan }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        public ActionResult PurchaseReceiveTotalChallanFindBySupID(string supID)
        {

            List<rChallanViewModel> isFoundrChallan = new List<rChallanViewModel>();
            List<rChallanViewModel> result = null;
            List<TempTableValue> datas = _tempTableValueService.Gets().ToList();
            decimal chlnVal = 0;
            decimal netChalVal = 0;
            decimal TotalPrdComm = 0;
            decimal AddPrdComm = 0;
            TempTableValue isFound = datas.FirstOrDefault(m => m.TableOperation == "rChallanTemp");
            if (isFound != null)
            {
                decimal temp = 0;
                result = Newtonsoft.Json.JsonConvert.DeserializeObject<List<rChallanViewModel>>(isFound.TableValue);
                isFoundrChallan = result.FindAll(m => m.SupID == supID);
                if (isFoundrChallan != null)
                {
                    foreach (rChallanViewModel rc in isFoundrChallan)
                    {
                        decimal.TryParse(rc.ChlnTotal.ToString(), out temp);
                        chlnVal = chlnVal + temp;
                        decimal.TryParse(rc.AddPrdComm.ToString(), out temp);
                        AddPrdComm = temp;
                        decimal.TryParse(rc.TotalPrdComm.ToString(), out temp);
                        TotalPrdComm = temp;
                    }
                    netChalVal = chlnVal - (TotalPrdComm + AddPrdComm);
                }
            }

            var list = JsonConvert.SerializeObject(new { chlnVal, netChalVal, TotalPrdComm, AddPrdComm }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        public ActionResult PurchaseReceiveTempFindByChln(string chln)
        {
            List<rChallanViewModel> isFoundrChallan = new List<rChallanViewModel>();
            List<rChallanViewModel> result = null;
            List<TempTableValue> datas = _tempTableValueService.Gets().ToList();

            TempTableValue isFound = datas.FirstOrDefault(m => m.TableOperation == "rChallanTemp");
            if (isFound != null)
            {
                result = Newtonsoft.Json.JsonConvert.DeserializeObject<List<rChallanViewModel>>(isFound.TableValue);
                isFoundrChallan = result.FindAll(m => m.Chln == chln);
            }

            var list = JsonConvert.SerializeObject(new { data = isFoundrChallan }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }

        public ActionResult rChallanListTemp()
        {
            List<rChallanViewModel> result = GetListTempTableValue();

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        private List<rChallanViewModel> GetListTempTableValue()
        {
            List<rChallanViewModel> result = null;
            List<TempTableValue> datas = _tempTableValueService.Gets().ToList();

            TempTableValue isFound = datas.FirstOrDefault(m => m.TableOperation == "rChallanTemp");
            if (isFound != null)
            {
                result = Newtonsoft.Json.JsonConvert.DeserializeObject<List<rChallanViewModel>>(isFound.TableValue);
            }
            return result;
        }

        public ActionResult PurchaseReceiveTempGetDistinctChln()
        {
            List<string> newList = new List<string>();
            List<rChallanViewModel> chlnList = GetListTempTableValue();
            foreach (rChallanViewModel rChallanViewModel in chlnList)
            {
                newList.Add(rChallanViewModel.Chln);
            }
            List<string> List = new List<string>();
            List.AddRange(newList.Distinct());


            var list = JsonConvert.SerializeObject(new { data = List }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }
        public ActionResult GetstyleSizeByOrderNo(string pruchaseOrderNo)
        {
            List<StyleSize> objStyleSizes = new List<StyleSize>();
            objStyleSizes = _styleSizeService.GetstyleSizeByBuyOrderNo(pruchaseOrderNo);

            var list = JsonConvert.SerializeObject(new { data = objStyleSizes }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }
        public ActionResult PurchaseReceiveGetPOBySupID(string supID)
        {
            DataTable dt = _buyOrderService.GetPOBySupID(supID);

            var list = JsonConvert.SerializeObject(new { data = dt }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        #endregion

        #region ========= AccountsChln ============
        public ActionResult AccountsChln()
        {
            return View();
        }
        #endregion

        #region ====== Delivery to Shop / iChallan =======
        public ActionResult DeliveryToShop()
        {
            if (!IsPermissionApply("Process", "DeliveryToShop"))
            {
                return RedirectToAction("Index", "Home");
            }
            ShopList resultShop = null;
            List<ShopList> dataShop = _shopListService.Gets().ToList();
            resultShop = dataShop.Find(c => c.ShopID == "9999");
            dataShop.Remove(resultShop);
            List<ShopList> newList = new List<ShopList>();
            ShopList ss = new ShopList();
            ss.ShopID = "";
            ss.ShopName = "Select";
            newList.Add(ss);
            foreach (ShopList sl in dataShop)
            {
                ShopList s = new ShopList();
                s.ShopID = sl.ShopID;
                s.ShopName = sl.ShopID + "-" + sl.ShopName;
                newList.Add(s);
            }
            ViewBag.shopList = new SelectList(newList, "ShopID", "ShopName");
            return View();
        }
        public ActionResult iChallanTempGetCodeDCNO(string ShopID)
        {
            string DCNO = _iChallanTempService.GetCode(ShopID).ToString();
            var list = JsonConvert.SerializeObject(new { data = DCNO }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }
        public ActionResult CreateiChallanTemp(iChallanTempViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    iChallanTemp dbModel = new iChallanTemp();
                    dbModel = Mapper.Map<iChallanTempViewModel, iChallanTemp>(model);
                  //string GetCodeDCNO = _iChallanTempService.GetCode(dbModel.ShopID).ToString();
                    string GetCodeDCNO = new GlobalClass().GetMaxIdWithPrfix("DCNO", "6", "000001", "iChallan", "DC" + dbModel.ShopID);
                    dbModel.DCNO = "T" + GetCodeDCNO;
                    dbModel.CMPIDX = dbModel.DCNO + dbModel.BarCode;
                    iChallanTemp data = _iChallanTempService.Get(dbModel.CMPIDX);
                    if (data != null)
                    {
                        data.Qty = dbModel.Qty + data.Qty;
                        data.UserID = User.Identity.Name;
                        _iChallanTempService.Update(data);
                    }
                    else
                    {
                        dbModel.UserID = User.Identity.Name;
                        _iChallanTempService.Create(dbModel);
                    }
                    //need reduce from central stoke
                    _buyCentralService.UpdatebalQty(dbModel.BarCode, Convert.ToDecimal(dbModel.Qty), "Delete");
                    if (dbModel.Chln != "DIRECT")
                    {
                        _buyRequisitionService.UpdatebalQty(dbModel.Chln + dbModel.BarCode, Convert.ToDecimal(dbModel.Qty), "Delete");
                        _buyRequisitionService.Save();
                    }
                    //if Delivery by Requisition then  Reduce the balQt of BuyReuisition

                    _iChallanTempService.Save();
                    _buyCentralService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }
        public ActionResult iChallanTempByShopID(string ShopID)
        {
            IEnumerable<iChallanTemp> datas = _iChallanTempService.GetByShopID(ShopID);
            var list = JsonConvert.SerializeObject(new { data = datas }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }
        public ActionResult iChallanTempByGetByDCNO(string DCNO)
        {
            IEnumerable<iChallanTemp> datas = _iChallanTempService.GetByDCNO(DCNO);
            var list = JsonConvert.SerializeObject(new { data = datas }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }
        public ActionResult iChallanTempGetByCMPIDX(string CMPIDX)
        {
            iChallanTemp datas = _iChallanTempService.Get(CMPIDX);
            var list = JsonConvert.SerializeObject(new { data = datas }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }
        public ActionResult DeleteiChallanTemp(string CMPIDX)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var data = _iChallanTempService.Get(CMPIDX);
                    if (data.Chln != "DIRECT")
                    {
                        _buyRequisitionService.UpdatebalQty(data.Chln + data.BarCode, Convert.ToDecimal(data.Qty), "Add");
                        _buyRequisitionService.Save();
                    }
                    _iChallanTempService.Remove(data);
                    _buyCentralService.UpdatebalQty(data.BarCode, Convert.ToDecimal(data.Qty), "Add");
                    _iChallanTempService.Save();
                    _buyCentralService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }
        public ActionResult iChallanTempGetDCNO()
        {
            DataTable dt = _iChallanTempService.GetNonPostingDCNO();
            var list = JsonConvert.SerializeObject(new { data = dt }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }
        public ActionResult iChallanTempList()
        {
            IEnumerable<iChallanTemp> data = _iChallanTempService.Gets();

            var list = JsonConvert.SerializeObject(new { data = data }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }
        public ActionResult InsertiChallanFromTemp(string DCNO)
        {
            IEnumerable<iChallanTemp> tempData = _iChallanTempService.GetByDCNO(DCNO);
            iChallanTemp getone = tempData.FirstOrDefault();
           // string NewDCNO = _iChallanTempService.GetCode(getone.ShopID).ToString();
            string NewDCNO = new GlobalClass().GetMaxIdWithPrfix("DCNO", "6", "000001", "iChallan", "DC" + getone.ShopID);
            foreach (iChallanTemp icT in tempData)
            {
                iChallan ic = new iChallan();
                ic.DCNO = NewDCNO;
                ic.CMPIDX = NewDCNO + icT.BarCode;
                ic.Chln = icT.Chln;
                ic.BarCode = icT.BarCode;
                ic.sBarCode = icT.sBarCode;
                ic.BuyDT = icT.BuyDT;
                ic.UserID = icT.UserID;
                ic.CPU = icT.CPU;
                ic.DCDt = DateTime.Now;
                ic.DiscPrcnt = icT.DiscPrcnt;
                ic.EXPDT = icT.EXPDT;
                ic.LastSDT = icT.LastSDT;
                ic.Point = icT.Point;
                ic.PrdComm = icT.PrdComm;
                ic.Qty = icT.Qty;
                ic.RPP = icT.RPP;
                ic.RPU = icT.RPU;
                ic.Reorder = icT.Reorder;
                ic.ShopID = icT.ShopID;
                ic.SupID = icT.SupID;
                ic.Transfer = icT.Transfer;
                ic.VATPrcnt = icT.VATPrcnt;
                ic.WSP = icT.WSP;
                ic.WSQ = icT.WSQ;
                ic.ZoneID = icT.ZoneID;
                ic.bQty = icT.bQty;
                ic.rQty = icT.rQty;
                ic.balQty = icT.balQty;
                ic.cSqty = icT.cSqty;
                ic.dmlqty = icT.dmlqty;
                ic.rQty = icT.rQty;
                ic.sQty = icT.sQty;
                _iChallanService.Create(ic);
            }
            _iChallanService.Save();

            try
            {
                //delete from temp
                foreach (iChallanTemp rcTemp in tempData)
                {
                    _iChallanTempService.Remove(rcTemp);
                }
                _iChallanTempService.Save();

                //return rest of the things
                IEnumerable<iChallanTempViewModel> result = null;
                IEnumerable<iChallanTemp> datas = _iChallanTempService.Gets();
                result = Mapper.Map<IEnumerable<iChallanTemp>, IEnumerable<iChallanTempViewModel>>(datas);

                var list = JsonConvert.SerializeObject(new { data = result, Error = "Saved", NewDCNO = NewDCNO }, Formatting.None,
                            new JsonSerializerSettings()
                            {
                                ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                            });

                return Content(list, "application/json");
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }
        public ActionResult iChallanTempDelByDCNO(string DCNO)
        {
            try
            {
                IEnumerable<iChallanTemp> tempData = _iChallanTempService.GetByDCNO(DCNO);
                foreach (iChallanTemp rcTemp in tempData)
                {
                    _iChallanTempService.Remove(rcTemp);
                }
                _iChallanTempService.Save();

                return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }
        public ActionResult BuyRequisitionGetReqNoByShopID(string ShopID)
        {
            DataTable dt = _buyRequisitionService.GetReqNoByShopID(ShopID);

            var list = JsonConvert.SerializeObject(new { data = dt }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }
        public ActionResult GetNotDeliveryByRequisitionNo(string RequisitionNo)
        {
            DataTable datas = _buyRequisitionService.GetNotDeliveryByRequisitionNo(RequisitionNo);

            var list = JsonConvert.SerializeObject(new { data = datas }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }
        public ActionResult SameAsReqCreaterBuyRequisitionTemp(string SR)
        {
            try
            {
                DataTable dtStyleSize = _buyRequisitionService.GetNotDeliveryByRequisitionNo(SR);
                foreach (DataRow drDetails in dtStyleSize.Rows)
                {
                    decimal temp;
                    iChallanTempViewModel rc = new iChallanTempViewModel();
                    rc.CMPIDX = drDetails["CmpIDX"].ToString();
                    rc.Chln = SR;
                    rc.DCDt = DateTime.Now;
                    rc.sBarCode = drDetails["sBarCode"].ToString();
                    rc.BarCode = drDetails["BarCode"].ToString();
                    decimal.TryParse(drDetails["CPU"].ToString(), out temp);
                    rc.CPU = temp;
                    decimal.TryParse(drDetails["RPU"].ToString(), out temp);
                    rc.RPU = temp;
                    decimal.TryParse(drDetails["WSP"].ToString(), out temp);
                    rc.WSP = temp;
                    decimal.TryParse(drDetails["WSQ"].ToString(), out temp);
                    rc.WSQ = temp;
                    decimal.TryParse(drDetails["DiscPrcnt"].ToString(), out temp);
                    rc.DiscPrcnt = temp;
                    decimal.TryParse(drDetails["VATPrcnt"].ToString(), out temp);
                    rc.VATPrcnt = temp;
                    decimal.TryParse(drDetails["PrdComm"].ToString(), out temp);
                    rc.PrdComm = temp;
                    decimal.TryParse(drDetails["balQty"].ToString(), out temp);
                    rc.Qty = temp;
                    rc.balQty = temp;
                    rc.bQty = 0;
                    rc.sQty = 0;
                    rc.Transfer = "N";
                    rc.cSqty = 0;
                    rc.rQty = 0;
                    rc.dmlqty = 0;
                    rc.SupID = drDetails["SupID"].ToString();
                    rc.ShopID = drDetails["ShopID"].ToString();
                    rc.SSName = drDetails["SSName"].ToString();
                    rc.GroupName = drDetails["GroupName"].ToString();
                    rc.PrdName = drDetails["PrdName"].ToString();
                    rc.BTName = drDetails["BTName"].ToString();
                    rc.SSName = drDetails["SSName"].ToString();
                    rc.SupName = drDetails["SupName"].ToString();
                    decimal.TryParse(drDetails["Reorder"].ToString(), out temp);
                    rc.Reorder = temp;
                    rc.ZoneID = drDetails["ZoneID"].ToString();
                    decimal.TryParse(drDetails["Point"].ToString(), out temp);
                    rc.Point = temp;
                    SameAsSRInsert(rc);
                }
                return Json(new { result = false, Error = "Saved" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        private void SameAsSRInsert(iChallanTempViewModel model)
        {
            iChallanTemp dbModel = new iChallanTemp();
            dbModel = Mapper.Map<iChallanTempViewModel, iChallanTemp>(model);
           // string GetCodeDCNO = _iChallanTempService.GetCode(dbModel.ShopID).ToString();
            string GetCodeDCNO = new GlobalClass().GetMaxIdWithPrfix("DCNO", "6", "000001", "iChallan", "DC" + dbModel.ShopID);
            dbModel.DCNO = "T" + GetCodeDCNO;
            dbModel.CMPIDX = dbModel.DCNO + dbModel.BarCode;
            iChallanTemp data = _iChallanTempService.Get(dbModel.CMPIDX);
            if (data != null)
            {
                data.Qty = dbModel.Qty + data.Qty;
                data.UserID = User.Identity.Name;
                _iChallanTempService.Update(data);
            }
            else
            {
                dbModel.UserID = User.Identity.Name;
                _iChallanTempService.Create(dbModel);
            }
            //need reduce from central stoke
            _buyCentralService.UpdatebalQty(dbModel.BarCode, Convert.ToDecimal(dbModel.Qty), "Delete");
            if (dbModel.Chln != "DIRECT")
            {
                _buyRequisitionService.UpdatebalQty(dbModel.Chln + dbModel.BarCode, Convert.ToDecimal(dbModel.Qty), "Delete");
                _buyRequisitionService.Save();
            }
            //if Delivery by Requisition then  Reduce the balQt of BuyReuisition

            _iChallanTempService.Save();
            _buyCentralService.Save();
        }
        #endregion

        #region ====== Buy Requisition Approval =====
        public ActionResult ShopRequisitionApproval()
        {
            if (!IsPermissionApply("Process", "ShopRequisitionApproval"))
            {
                return RedirectToAction("Index", "Home");
            }

            ShopList resultShop = null;
            List<ShopList> dataShop = _shopListService.Gets().ToList();
            resultShop = dataShop.Find(c => c.ShopID == "9999");
            dataShop.Remove(resultShop);
            List<ShopList> newList = new List<ShopList>();
            ShopList ss = new ShopList();
            ss.ShopID = "";
            ss.ShopName = "Select";
            newList.Add(ss);
            foreach (ShopList sl in dataShop)
            {
                ShopList s = new ShopList();
                s.ShopID = sl.ShopID;
                s.ShopName = sl.ShopID + "-" + sl.ShopName;
                newList.Add(s);
            }
            ViewBag.ShopList = new SelectList(newList, "ShopID", "ShopName");
            return View();
        }
        public ActionResult GetRequisitioNoByShopID(string ShopID)
        {
            List<string> datas = _buyRequisitionService.GetRequisitionNoByShopID(ShopID);
            var list = JsonConvert.SerializeObject(new { data = datas }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }
        public ActionResult BuyRequisitionByCmpIDX(string CmpIDX)
        {
            DataTable dt = _buyRequisitionService.GetByCmpIDX(CmpIDX);
            var list = JsonConvert.SerializeObject(new { data = dt }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }
        public ActionResult BuyRequisitionByRequisitionNo(string RequisitionNo)
        {
            DataTable dt = _buyRequisitionService.GetByRequisitionNodt(RequisitionNo);
            var list = JsonConvert.SerializeObject(new { data = dt }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }
        [HttpPost]
        public ActionResult ShopRequisitionApproval(List<BuyRequisitionViewModel> model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    foreach (BuyRequisitionViewModel br in model)
                    {
                        BuyRequisition db = _buyRequisitionService.Get(br.RequisitionNo + br.BarCode);
                        if (db != null)
                        {
                            db.balQty = br.ApproveQtY;
                            db.ApproveQtY = br.ApproveQtY;
                            db.ApprovedBy = User.Identity.Name;
                            db.IsApproved = "Y";
                            _buyRequisitionService.Update(db);
                        }
                    }
                    _buyRequisitionService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }


            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region ==== Menu Permission Check =====
        private bool IsPermissionApply(string Controller, string ActionName)
        {
            List<RetailMaster.POS.Web.ViewModels.MenuURLViewModel> lstMenus = null;
            if (Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.SessionMenu] == null)
            {
                lstMenus = new GlobalClass().GetMenuByUserName(User.Identity.Name);
                Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.SessionMenu] = lstMenus;
            }
            else
            {
                lstMenus =
                    Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.SessionMenu] as
                        List<RetailMaster.POS.Web.ViewModels.MenuURLViewModel>;
            }
            MenuURLViewModel menu = lstMenus.FindAll(m => m.Controller == Controller && m.ActionName == ActionName).FirstOrDefault();
            if (menu != null)
                return true;
            else
                return false;
        }
        #endregion
    }
}