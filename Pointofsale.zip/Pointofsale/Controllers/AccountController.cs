﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using DotNetOpenAuth.AspNet;
using Microsoft.Web.WebPages.OAuth;
using Newtonsoft.Json;
using RetailMaster.POS.Models;
using RetailMaster.POS.Service;
using RetailMaster.POS.Web.BLL;
using RetailMaster.POS.Web.Filters;
using RetailMaster.POS.Web.Models;
using WebMatrix.WebData;

namespace RetailMaster.POS.Web.Controllers
{
    [Authorize]
    [InitializeSimpleMembership]
    public class AccountController : Controller
    {
        private readonly IShopListService _shopListService;
        private readonly IGlobalSetupService _globalSetupService;
        private readonly ILoggedInConferenceService _loggedInConference;

        public AccountController(IShopListService shopListService, IGlobalSetupService golSetupService, ILoggedInConferenceService loggedInConference)
        {
            this._shopListService = shopListService;
            this._globalSetupService = golSetupService;
            this._loggedInConference = loggedInConference;
        }

        private LogedInInfo GetLogedInInfo()
        {
            LogedInInfo info = new LogedInInfo();
            if (HttpContext.Request.Cookies["POSLogedInInfo"] != null)
            {
                HttpCookie cookie = HttpContext.Request.Cookies.Get("POSLogedInInfo");
                info = Newtonsoft.Json.JsonConvert.DeserializeObject<LogedInInfo>(cookie.Value) as LogedInInfo;
            }
            return info;
        }

        #region ==== LoggedIn Conference ====

        public ActionResult LoggedInConference()
        {
            return View();
        }
        public ActionResult GetLoggedInUserList()
        {
            List<LoggedInConference> olist = _loggedInConference.Gets();
            var list = JsonConvert.SerializeObject(new { data = olist }, Formatting.None,
                       new JsonSerializerSettings()
                       {
                           ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                       });

            return Content(list, "application/json");
        }

        public ActionResult DeleteLoggedInConference(string Id)
        {
            try
            {
                LoggedInConference oliList = _loggedInConference.Gets().Find(m => m.Id == Convert.ToInt32(Id));
                _loggedInConference.Remove(oliList);
                _loggedInConference.Save();
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult DeleteSelectedLoggedInConference(string UserNameList)
        {
            try
            {
                List<string> oList = UserNameList.Split(',').ToList();
                List<LoggedInConference> olist = _loggedInConference.Gets();
                foreach (string UserName in oList)
                {
                    LoggedInConference oliList = olist.Find(m => m.UserName == UserName);
                    _loggedInConference.Remove(oliList);
                }
                _loggedInConference.Save();
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }

        #endregion

        [AllowAnonymous]
        public ActionResult Login(string returnUrl)
        {
            var counterList = LoginModelCounterIds();

            ViewBag.CounterIDList = new SelectList(counterList, "CounterID", "CounterName");

            ViewBag.ReturnUrl = returnUrl;
            return View();
        }

        private static List<LoginModelCounterID> LoginModelCounterIds()
        {
            List<LoginModelCounterID> counterList = new List<LoginModelCounterID>()
            {
                new LoginModelCounterID("01", "Counter - 01"),
                new LoginModelCounterID("02", "Counter - 02"),
                new LoginModelCounterID("03", "Counter - 03"),
                new LoginModelCounterID("04", "Counter - 04"),
                new LoginModelCounterID("05", "Counter - 05"),
                new LoginModelCounterID("06", "Counter - 06"),
                new LoginModelCounterID("07", "Counter - 07"),
                new LoginModelCounterID("08", "Counter - 08"),
                new LoginModelCounterID("09", "Counter - 09"),
                new LoginModelCounterID("10", "Counter - 10"),
                new LoginModelCounterID("11", "Counter - 11"),
                new LoginModelCounterID("12", "Counter - 12"),
                new LoginModelCounterID("13", "Counter - 13"),
                new LoginModelCounterID("14", "Counter - 14"),
                new LoginModelCounterID("15", "Counter - 15"),
                new LoginModelCounterID("16", "Counter - 16"),
                new LoginModelCounterID("17", "Counter - 17"),
                new LoginModelCounterID("18", "Counter - 18"),
                new LoginModelCounterID("19", "Counter - 19"),
                new LoginModelCounterID("20", "Counter - 20")
            };
            return counterList;
        }

        public ActionResult GetUser()
        {
            List<ShopList> dataShop = _shopListService.Gets().ToList();
            string ShopId = GetLogedInInfo().ShopID;
            List<ShopList> newList = new List<ShopList>();
            if (ShopId != "9999")
            {
                ShopList s = new ShopList();
                s = dataShop.FindAll(m => m.ShopID == ShopId).FirstOrDefault();
                s.ShopName = s.ShopID + "-" + s.ShopName;
                newList.Add(s);
            }
            else
            {
                foreach (ShopList sl in dataShop)
                {
                    ShopList s = new ShopList();
                    s.ShopID = sl.ShopID;
                    s.ShopName = sl.ShopID + "-" + sl.ShopName;
                    newList.Add(s);
                }
            }

            ViewBag.shopList = new SelectList(newList, "ShopID", "ShopName");
            return View();
        }

        [AllowAnonymous]
        public ActionResult GetUserList()
        {
            string ShopId = GetLogedInInfo().ShopID;
            string _selectQuery = "";
            if (ShopId == "9999")
            {
                _selectQuery = "EXECUTE usp_UserProfile_GetList ''";
            }
            else
            {
                _selectQuery = "EXECUTE usp_UserProfile_GetListByShopId '" + ShopId + "'";
            }

            SQLDALService dal = new SQLDALService();
            var result = dal.Select(_selectQuery).Data;

            var list = JsonConvert.SerializeObject(new { data = result }, Formatting.None,
                new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                );

            return Content(list, "application/json");
        }
        public ActionResult FindUserByUserName(string userName)
        {
            string _selectQuery = "EXECUTE usp_UserProfile_GetList '" + userName + "'";

            SQLDALService dal = new SQLDALService();
            DataTable dt = dal.Select(_selectQuery).Data;

            var list = JsonConvert.SerializeObject(new { data = dt }, Formatting.None,
                 new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore }
                 );

            return Content(list, "application/json");
        }

        public ActionResult CreateUser(RegisterModel model)
        {
            if (ModelState.IsValid)
            {
                // Attempt to register the user
                try
                {
                    // var roles = (SimpleRoleProvider)Roles.Provider;
                    // var users = (SimpleMembershipProvider)Membership.Provider;
                    //roles.AddUsersToRoles(new[] { model.UserName }, new[] { model.ShopID });

                    // WebSecurity.CreateUserAndAccount(model.UserName, model.Password);
                    //WebSecurity.Login(model.UserName, model.Password);
                    //WebSecurity.Login(model.UserName, model.Password);
                    // return RedirectToAction("Index", "Home");

                    if (model.Password != model.ConfirmPassword)
                    {
                        ModelState.AddModelError("", "Password does not match!");
                        return View();
                    }
                    if (!WebSecurity.UserExists(model.UserName))
                    {
                        WebSecurity.CreateUserAndAccount(model.UserName, model.Password, new { model.ShopID });
                    }
                    else
                    {
                        ModelState.AddModelError("", "A user has been already exists with this name!");
                        return View();
                    }
                }
                catch (MembershipCreateUserException e)
                {
                    return Json(new { result = false, Error = ErrorCodeToString(e.StatusCode) }, JsonRequestBehavior.AllowGet);
                }
            }

            return Json(new { result = true, Error = "Saved" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult UpdateUser(RegisterModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    if (model.Password != model.ConfirmPassword)
                    {
                        ModelState.AddModelError("", "Password does not match!");
                        return View();
                    }
                    if (WebSecurity.UserExists(model.UserName))
                    {
                        // WebSecurity.ChangePassword(model.UserName, model.old, );
                        // WebSecurity.Login(model.UserName, model.Password);
                        return RedirectToAction("Index", "Home");
                    }
                    else
                    {
                        ModelState.AddModelError("", "A user has been already exists with this name!");
                        return View();
                    }
                }
                catch (MembershipCreateUserException e)
                {
                    ModelState.AddModelError("", ErrorCodeToString(e.StatusCode));
                }
            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }

        public ActionResult DeleteUser(RegisterModel model)
        {
            if (WebSecurity.UserExists(model.UserName))
            {
                // Attempt to register the user
                try
                {
                    ((SimpleMembershipProvider)Membership.Provider).DeleteAccount(model.UserName);
                    ((SimpleMembershipProvider)Membership.Provider).DeleteUser(model.UserName, true);
                }
                catch (MembershipCreateUserException e)
                {
                    return Json(new { result = false, Error = ErrorCodeToString(e.StatusCode) }, JsonRequestBehavior.AllowGet);
                }
            }

            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ChangePassword()
        {
            return View();
        }

        //
        // POST: /Account/Login

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult Login(LoginModel model, string returnUrl)
        {
            try
            {
                //LocalPasswordModel modell = new LocalPasswordModel();
                //MembershipUser u = Membership.GetUser(model.UserName, false);
                //modell.OldPassword = u.GetPassword();

                LogedInInfo info = new GlobalClass().GetLogedInInfo(model.UserName);
                //info.ShopID = "9999";
                bool loginCheck = false;
                if (info.ShopID == "9999")
                {
                    loginCheck = true;
                }
                else
                {
                   // if already login then _loggedInConference return true
                    loginCheck = _loggedInConference.IsLoggedIn(model.UserName, info.ShopID, model.CounterID);
                    if (loginCheck)
                        loginCheck = false;
                    else
                        loginCheck = true;
                }
                //
                if (loginCheck)
                {
                    if (WebSecurity.Login(model.UserName, model.Password, persistCookie: model.RememberMe))
                    {
                        #region create Conference
                        LoggedInConference conference = new LoggedInConference();
                        conference.ShopID = info.ShopID;
                        conference.CounterID = model.CounterID;
                        conference.UserName = info.UserName;
                        conference.LoggedInTime = DateTime.Now;
                        conference.IsLoggedIn = "Y";
                        _loggedInConference.Create(conference);
                        _loggedInConference.Save();
                        #endregion

                        //_loggedInConference.Create();
                        info.CounterID = model.CounterID;
                        var json = JsonConvert.SerializeObject(info);
                        HttpCookie cookie = new HttpCookie("POSLogedInInfo", json);
                        cookie.Expires = DateTime.Now.AddDays(30);
                        HttpContext.Response.Cookies.Add(cookie);
                        //Response.Cookies.Add(cookie);
                        //HttpContext.Response.Cookies.Remove("some_cookie_name");
                        //HttpContext.Response.SetCookie(cookie);

                        //menu url
                        List<RetailMaster.POS.Web.ViewModels.MenuURLViewModel> lstMenus = null;
                        lstMenus = new GlobalClass().GetMenuByUserName(model.UserName);
                        Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.SessionMenu] = lstMenus;

                        //global setup
                        var Globaljson = JsonConvert.SerializeObject(_globalSetupService.Get());
                        HttpCookie Gcookie = new HttpCookie("globalSetup", Globaljson);
                        Gcookie.Expires = DateTime.Now.AddDays(30);
                        HttpContext.Response.Cookies.Add(Gcookie);
                        return RedirectToLocal(returnUrl);
                    }
                }
                else
                {
                    var counterList2 = LoginModelCounterIds();

                    ViewBag.CounterIDList = new SelectList(counterList2, "CounterID", "CounterName");

                    ModelState.AddModelError("", "This user already logedIn from another counter");
                    return View(model);
                }

                var counterList = LoginModelCounterIds();

                ViewBag.CounterIDList = new SelectList(counterList, "CounterID", "CounterName");
                // If we got this far, something failed, redisplay form
                ModelState.AddModelError("", "The user name or password provided is incorrect.");
                return View(model);
            }
            catch (Exception ex)
            {
                var counterList = LoginModelCounterIds();

                ViewBag.CounterIDList = new SelectList(counterList, "CounterID", "CounterName");

                ModelState.AddModelError("", ex.Message.ToString());
                return View(model);
            }
        }

        //
        // POST: /Account/LogOff

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LogOff()
        {
            #region conference
            LogedInInfo info = GetLogedInInfo();
            LoggedInConference logged = _loggedInConference.GetByUserInfo(info.UserName, info.ShopID, info.CounterID);
            if (logged != null)
            {
                _loggedInConference.Remove(logged);
                _loggedInConference.Save();
            }

            #endregion

            WebSecurity.Logout();
            Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.globalSetup] = null;
            Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.SessionMenu] = null;

            if (Request.Cookies["POSLogedInInfo"] != null)
            {
                var c = new HttpCookie("POSLogedInInfo");
                c.Expires = DateTime.Now.AddDays(-1);
                Response.Cookies.Add(c);
            }

            if (Request.Cookies["globalSetup"] != null)
            {
                var c = new HttpCookie("globalSetup");
                c.Expires = DateTime.Now.AddDays(-1);
                Response.Cookies.Add(c);
            }
            return RedirectToAction("Index", "Home");
        }

        //
        // GET: /Account/Register

        [AllowAnonymous]
        public ActionResult Register()
        {
            return View();
        }

        //
        // POST: /Account/Register

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult Register(RegisterModel model)
        {
            if (ModelState.IsValid)
            {
                // Attempt to register the user
                try
                {
                    // var roles = (SimpleRoleProvider)Roles.Provider;
                    // var users = (SimpleMembershipProvider)Membership.Provider;
                    //   roles.CreateRole("Admin");

                    // users.CreateUserAndAccount("Admin2", "admin123");
                    // roles.AddUsersToRoles(new[] { "Admin2" }, new[] { "Admin" });
                    if (model.Password != model.ConfirmPassword)
                    {
                        ModelState.AddModelError("", "Password does not match!");
                        return View();
                    }

                    WebSecurity.CreateUserAndAccount(model.UserName, model.Password);
                    WebSecurity.Login(model.UserName, model.Password);
                    return RedirectToAction("Index", "Home");
                }
                catch (MembershipCreateUserException e)
                {
                    ModelState.AddModelError("", ErrorCodeToString(e.StatusCode));
                }
            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }


        //
        // POST: /Account/Disassociate

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Disassociate(string provider, string providerUserId)
        {
            string ownerAccount = OAuthWebSecurity.GetUserName(provider, providerUserId);
            ManageMessageId? message = null;

            // Only disassociate the account if the currently logged in user is the owner
            //if (ownerAccount == User.Identity.Name)
            //{
            //    // Use a transaction to prevent the user from deleting their last login credential
            //    using (var scope = new TransactionScope(TransactionScopeOption.Required, new TransactionOptions { IsolationLevel = IsolationLevel.Serializable }))
            //    {
            //        bool hasLocalAccount = OAuthWebSecurity.HasLocalAccount(WebSecurity.GetUserId(User.Identity.Name));
            //        if (hasLocalAccount || OAuthWebSecurity.GetAccountsFromUserName(User.Identity.Name).Count > 1)
            //        {
            //            OAuthWebSecurity.DeleteAccount(provider, providerUserId);
            //            scope.Complete();
            //            message = ManageMessageId.RemoveLoginSuccess;
            //        }
            //    }
            //}

            return RedirectToAction("Manage", new { Message = message });
        }

        //
        // GET: /Account/Manage

        public ActionResult Manage(ManageMessageId? message)
        {
            ViewBag.StatusMessage =
                message == ManageMessageId.ChangePasswordSuccess ? "Your password has been changed."
                : message == ManageMessageId.SetPasswordSuccess ? "Your password has been set."
                : message == ManageMessageId.RemoveLoginSuccess ? "The external login was removed."
                : "";
            ViewBag.HasLocalPassword = OAuthWebSecurity.HasLocalAccount(WebSecurity.GetUserId(User.Identity.Name));
            ViewBag.ReturnUrl = Url.Action("Manage");
            return View();
        }

        //
        // POST: /Account/Manage

        [HttpPost]
        public ActionResult Manage(LocalPasswordModel model)
        {
            try
            {
                bool hasLocalAccount = OAuthWebSecurity.HasLocalAccount(WebSecurity.GetUserId(model.UserName));
                ViewBag.HasLocalPassword = hasLocalAccount;
                ViewBag.ReturnUrl = Url.Action("Manage");

                MembershipUser u1 = Membership.GetUser(model.UserName, false);
                model.OldPassword = u1.GetPassword();

                if (hasLocalAccount)
                {
                    if (ModelState.IsValid)
                    {
                        bool changePasswordSucceeded;
                        try
                        {
                            if (model.OldPassword == null)
                            {
                                MembershipUser u = Membership.GetUser(model.UserName, false);
                                model.OldPassword = u.GetPassword();
                            }
                            changePasswordSucceeded = WebSecurity.ChangePassword(model.UserName, model.OldPassword, model.NewPassword);

                        }
                        catch (Exception)
                        {
                            return Json(new { result = false, Error = "The current password is incorrect or the new password is invalid." }, JsonRequestBehavior.AllowGet);
                        }
                    }
                }
                else
                {
                    return Json(new { result = false, Error = "The current password is incorrect or the new password is invalid." }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }

            return Json(new { result = true, Error = "Password  successfully Changed" }, JsonRequestBehavior.AllowGet);
        }

        //
        // POST: /Account/ExternalLogin

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult ExternalLogin(string provider, string returnUrl)
        {
            return new ExternalLoginResult(provider, Url.Action("ExternalLoginCallback", new { ReturnUrl = returnUrl }));
        }

        //
        // GET: /Account/ExternalLoginCallback

        [AllowAnonymous]
        public ActionResult ExternalLoginCallback(string returnUrl)
        {
            AuthenticationResult result = OAuthWebSecurity.VerifyAuthentication(Url.Action("ExternalLoginCallback", new { ReturnUrl = returnUrl }));
            if (!result.IsSuccessful)
            {
                return RedirectToAction("ExternalLoginFailure");
            }

            if (OAuthWebSecurity.Login(result.Provider, result.ProviderUserId, createPersistentCookie: false))
            {
                return RedirectToLocal(returnUrl);
            }

            if (User.Identity.IsAuthenticated)
            {
                // If the current user is logged in add the new account
                OAuthWebSecurity.CreateOrUpdateAccount(result.Provider, result.ProviderUserId, User.Identity.Name);
                return RedirectToLocal(returnUrl);
            }
            else
            {
                // User is new, ask for their desired membership name
                string loginData = OAuthWebSecurity.SerializeProviderUserId(result.Provider, result.ProviderUserId);
                ViewBag.ProviderDisplayName = OAuthWebSecurity.GetOAuthClientData(result.Provider).DisplayName;
                ViewBag.ReturnUrl = returnUrl;
                return View("ExternalLoginConfirmation", new RegisterExternalLoginModel { UserName = result.UserName, ExternalLoginData = loginData });
            }
        }

        //
        // POST: /Account/ExternalLoginConfirmation

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult ExternalLoginConfirmation(RegisterExternalLoginModel model, string returnUrl)
        {
            string provider = null;
            string providerUserId = null;

            if (User.Identity.IsAuthenticated || !OAuthWebSecurity.TryDeserializeProviderUserId(model.ExternalLoginData, out provider, out providerUserId))
            {
                return RedirectToAction("Manage");
            }

            if (ModelState.IsValid)
            {
                // Insert a new user into the database
                using (UsersContext db = new UsersContext())
                {
                    UserProfile user = db.UserProfiles.FirstOrDefault(u => u.UserName.ToLower() == model.UserName.ToLower());
                    // Check if user already exists
                    if (user == null)
                    {
                        // Insert name into the profile table
                        db.UserProfiles.Add(new UserProfile { UserName = model.UserName });
                        db.SaveChanges();

                        OAuthWebSecurity.CreateOrUpdateAccount(provider, providerUserId, model.UserName);
                        OAuthWebSecurity.Login(provider, providerUserId, createPersistentCookie: false);

                        return RedirectToLocal(returnUrl);
                    }
                    else
                    {
                        ModelState.AddModelError("UserName", "User name already exists. Please enter a different user name.");
                    }
                }
            }

            ViewBag.ProviderDisplayName = OAuthWebSecurity.GetOAuthClientData(provider).DisplayName;
            ViewBag.ReturnUrl = returnUrl;
            return View(model);
        }

        //
        // GET: /Account/ExternalLoginFailure

        [AllowAnonymous]
        public ActionResult ExternalLoginFailure()
        {
            return View();
        }

        [AllowAnonymous]
        [ChildActionOnly]
        public ActionResult ExternalLoginsList(string returnUrl)
        {
            ViewBag.ReturnUrl = returnUrl;
            return PartialView("_ExternalLoginsListPartial", OAuthWebSecurity.RegisteredClientData);
        }

        [ChildActionOnly]
        public ActionResult RemoveExternalLogins()
        {
            ICollection<OAuthAccount> accounts = OAuthWebSecurity.GetAccountsFromUserName(User.Identity.Name);
            List<ExternalLogin> externalLogins = new List<ExternalLogin>();
            foreach (OAuthAccount account in accounts)
            {
                AuthenticationClientData clientData = OAuthWebSecurity.GetOAuthClientData(account.Provider);

                externalLogins.Add(new ExternalLogin
                {
                    Provider = account.Provider,
                    ProviderDisplayName = clientData.DisplayName,
                    ProviderUserId = account.ProviderUserId,
                });
            }

            ViewBag.ShowRemoveButton = externalLogins.Count > 1 || OAuthWebSecurity.HasLocalAccount(WebSecurity.GetUserId(User.Identity.Name));
            return PartialView("_RemoveExternalLoginsPartial", externalLogins);
        }

        #region Helpers
        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        public enum ManageMessageId
        {
            ChangePasswordSuccess,
            SetPasswordSuccess,
            RemoveLoginSuccess,
        }

        internal class ExternalLoginResult : ActionResult
        {
            public ExternalLoginResult(string provider, string returnUrl)
            {
                Provider = provider;
                ReturnUrl = returnUrl;
            }

            public string Provider { get; private set; }
            public string ReturnUrl { get; private set; }

            public override void ExecuteResult(ControllerContext context)
            {
                OAuthWebSecurity.RequestAuthentication(Provider, ReturnUrl);
            }
        }

        private static string ErrorCodeToString(MembershipCreateStatus createStatus)
        {
            // See http://go.microsoft.com/fwlink/?LinkID=177550 for
            // a full list of status codes.
            switch (createStatus)
            {
                case MembershipCreateStatus.DuplicateUserName:
                    return "User name already exists. Please enter a different user name.";

                case MembershipCreateStatus.DuplicateEmail:
                    return "A user name for that e-mail address already exists. Please enter a different e-mail address.";

                case MembershipCreateStatus.InvalidPassword:
                    return "The password provided is invalid. Please enter a valid password value.";

                case MembershipCreateStatus.InvalidEmail:
                    return "The e-mail address provided is invalid. Please check the value and try again.";

                case MembershipCreateStatus.InvalidAnswer:
                    return "The password retrieval answer provided is invalid. Please check the value and try again.";

                case MembershipCreateStatus.InvalidQuestion:
                    return "The password retrieval question provided is invalid. Please check the value and try again.";

                case MembershipCreateStatus.InvalidUserName:
                    return "The user name provided is invalid. Please check the value and try again.";

                case MembershipCreateStatus.ProviderError:
                    return "The authentication provider returned an error. Please verify your entry and try again. If the problem persists, please contact your system administrator.";

                case MembershipCreateStatus.UserRejected:
                    return "The user creation request has been canceled. Please verify your entry and try again. If the problem persists, please contact your system administrator.";

                default:
                    return "An unknown error occurred. Please verify your entry and try again. If the problem persists, please contact your system administrator.";
            }
        }
        #endregion
    }
}