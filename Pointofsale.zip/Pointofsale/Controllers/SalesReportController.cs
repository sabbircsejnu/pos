﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RetailMaster.POS.Models;
using RetailMaster.POS.Service;
using RetailMaster.POS.Web.BLL;
using RetailMaster.POS.Web.Models;
using RetailMaster.POS.Web.ViewModels;

namespace RetailMaster.POS.Web.Controllers
{
    public class SalesReportController : Controller
    {
        private readonly ISupplierService _supplierService;
        private readonly IBuyCentralService _buyCentralService;
        private readonly IrChallanService _rchallanService;
        private readonly IStyleSizeService _styleSizeService;
        private readonly IShopListService _shopListService;
        private readonly IiChallanService _iChallanService;
        private readonly IBrandTypeService _brandTypeService;
        private readonly IPGroupService _groupService;
        private readonly ISsummaryService _summaryService;

        public SalesReportController(ISupplierService supplierService,IBuyCentralService buyCentralService, IrChallanService rchallanService,
            IStyleSizeService styleSizeService, IShopListService shopListService, IiChallanService iChallanService, IBrandTypeService brandTypeService,
            IPGroupService groupService, ISsummaryService summaryService)
        {
            this._supplierService = supplierService;
            this._buyCentralService = buyCentralService;
            this._rchallanService = rchallanService;
            this._styleSizeService = styleSizeService;
            this._shopListService = shopListService;
            this._iChallanService = iChallanService;
            this._brandTypeService = brandTypeService;
            this._groupService = groupService;
            this._summaryService = summaryService;
        }
        private LogedInInfo GetLogedInInfo()
        {
            LogedInInfo info = new LogedInInfo();
            if (HttpContext.Request.Cookies["POSLogedInInfo"] != null)
            {
                HttpCookie cookie = HttpContext.Request.Cookies.Get("POSLogedInInfo");
                info = Newtonsoft.Json.JsonConvert.DeserializeObject<LogedInInfo>(cookie.Value) as LogedInInfo;
            }
            return info;
        }

        public ActionResult MultipleSalesReport()
        {
            if (!IsPermissionApply("SalesReport", "MultipleSalesReport"))
            {
                return RedirectToAction("Index", "Home");
            }

            //suppliers
            List<Supplier> supl = _supplierService.Gets().ToList();
            Supplier sp = new Supplier();
            sp.SupID = "";
            sp.Supname = "All";
            supl.Insert(0, sp);
            ViewBag.SupplierList = new SelectList(supl, "SupID", "Supname");

            //Group
            List<PGroup> grouplist = _groupService.Gets().ToList();
            PGroup group = new PGroup();
            group.GroupID = "";
            group.GroupName = "All";
            grouplist.Insert(0, group);
            ViewBag.PGroupList = new SelectList(grouplist, "GroupID", "GroupName");

            //Product
            List<Product> prdlist = new List<Product>();
            Product prd = new Product();
            prd.PrdID = "";
            prd.PrdName = "All";
            prdlist.Insert(0, prd);
            ViewBag.ProductList = new SelectList(prdlist, "PrdID", "PrdName");

            //Brand Type
            List<BrandType> btList = _brandTypeService.Gets().ToList();
            BrandType bt = new BrandType();
            bt.BTID = "";
            bt.BTName = "All";
            btList.Insert(0, bt);
            ViewBag.BrandTypeList = new SelectList(btList, "BTID", "BTName");

            // Style Size
            List<StyleSize> sslist = new List<StyleSize>();
            StyleSize ss = new StyleSize();
            ss.SSID = "";
            ss.SSName = "All";
            sslist.Insert(0, ss);
            ViewBag.StyleSizeList = new SelectList(sslist, "SSID", "SSName");


            //Shop List
            List<ShopList> spl = _shopListService.Gets().ToList();
            spl.RemoveAll(m => m.ShopID == "9999");
            string ShopID = GetLogedInInfo().ShopID;
            if (ShopID != "9999")
            {
                spl.RemoveAll(m => m.ShopID != ShopID);
            }
            else
            {
                ShopList sl = new ShopList();
                sl.ShopID = "";
                sl.ShopName = "All";
                spl.Insert(0, sl);
            }
            ViewBag.ShopList = new SelectList(spl, "ShopID", "ShopName");

            var counterList = LoginModelCounterIds();
            ViewBag.CounterIDList = new SelectList(counterList, "CounterID", "CounterName");
            return View();
        }

        public ActionResult InvoiceRepritUpdate(string Invoice)
        {
            try
            {
                Ssummary s = _summaryService.GetByInvoiceNo(Invoice);
                if (s == null)
                {
                    return Json(new { result = false, Error = "Invoice not found" }, JsonRequestBehavior.AllowGet);
                }
                s.IsRePrinted = "N";
                _summaryService.Save();

                return Json(new { result = true, Error = "Updated" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        private static List<LoginModelCounterID> LoginModelCounterIds()
        {
            List<LoginModelCounterID> counterList = new List<LoginModelCounterID>()
            {
                new LoginModelCounterID("01", "Counter - 01"),
                new LoginModelCounterID("02", "Counter - 02"),
                new LoginModelCounterID("03", "Counter - 03"),
                new LoginModelCounterID("04", "Counter - 04"),
                new LoginModelCounterID("05", "Counter - 05"),
                new LoginModelCounterID("06", "Counter - 06"),
                new LoginModelCounterID("07", "Counter - 07"),
                new LoginModelCounterID("08", "Counter - 08"),
                new LoginModelCounterID("09", "Counter - 09"),
                new LoginModelCounterID("10", "Counter - 10"),
                new LoginModelCounterID("11", "Counter - 11"),
                new LoginModelCounterID("12", "Counter - 12"),
                new LoginModelCounterID("13", "Counter - 13"),
                new LoginModelCounterID("14", "Counter - 14"),
                new LoginModelCounterID("15", "Counter - 15"),
                new LoginModelCounterID("16", "Counter - 16"),
                new LoginModelCounterID("17", "Counter - 17"),
                new LoginModelCounterID("18", "Counter - 18"),
                new LoginModelCounterID("19", "Counter - 19"),
                new LoginModelCounterID("20", "Counter - 20")
            };
            return counterList;
        }

        #region ==== Menu Permission Check =====
        private bool IsPermissionApply(string Controller, string ActionName)
        {
            List<MenuURLViewModel> lstMenus = null;
            if (Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.SessionMenu] == null)
            {
                lstMenus = new GlobalClass().GetMenuByUserName(User.Identity.Name);
                Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.SessionMenu] = lstMenus;
            }
            else
            {
                lstMenus =
                    Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.SessionMenu] as
                        List<MenuURLViewModel>;
            }
            MenuURLViewModel menu = lstMenus.FindAll(m => m.Controller == Controller && m.ActionName == ActionName).FirstOrDefault();
            if (menu != null)
                return true;
            else
                return false;
        }
        #endregion
	}
}