﻿using System;
using System.Data;
using System.Linq;
using System.Web;
using RetailMaster.POS.Models;
using RetailMaster.POS.Service;
using RetailMaster.POS.Web.BLL;
using RetailMaster.POS.Web.Models;
using System.Collections.Generic;
using System.Web.Mvc;
using RetailMaster.POS.Web.ViewModels;

namespace RetailMaster.POS.Web.Controllers
{
    public class HomeController : Controller
    {

        private readonly ICircularPriceChangedService _priceChangedService;
        private readonly ICircularPriceChangedDetailService _priceChangedDetailService;
        private readonly IBuyCentralService _buyCentralService;
        private readonly IStyleSizeService _styleSizeService;
        private readonly IiChallanService _iChallanService;
        private readonly IiChallanTempService _iChallanTempService;
        private readonly IStockReturnTempService _stockReturnTempService;
        private readonly IBuyService _buyService;
        private readonly IBuyOrderService _buyOrderService;
        private readonly IStockReturnShopService _stockReturnShopService;
        public HomeController(ICircularPriceChangedService priceChangedService,
            ICircularPriceChangedDetailService priceChangedDetailService,
            IBuyCentralService buyCentralService, IStyleSizeService styleSizeService, IiChallanService ichallanService,
            IiChallanTempService ichallanTempService
            , IStockReturnTempService stockReturnTempService, IBuyService buyService, IBuyOrderService buyOrderService,
            IStockReturnShopService stockReturnShopService)
        {
            _priceChangedService = priceChangedService;
            _priceChangedDetailService = priceChangedDetailService;
            _buyCentralService = buyCentralService;
            _styleSizeService = styleSizeService;
            _iChallanService = ichallanService;
            _iChallanTempService = ichallanTempService;
            _stockReturnTempService = stockReturnTempService;
            _buyService = buyService;
            _buyOrderService = buyOrderService;
            _stockReturnShopService = stockReturnShopService;
        }

        private LogedInInfo GetLogedInInfo()
        {
            LogedInInfo info = new LogedInInfo();
            if (HttpContext.Request.Cookies["POSLogedInInfo"] != null)
            {
                HttpCookie cookie = HttpContext.Request.Cookies.Get("POSLogedInInfo");
                info = Newtonsoft.Json.JsonConvert.DeserializeObject<LogedInInfo>(cookie.Value) as LogedInInfo;
            }
            return info;
        }

        public ActionResult Index()
        {
            string ShopID = GetLogedInInfo().ShopID;
            if (ShopID == "9999")
            {
                if (IsPermissionApply("Process", "PurchaseReceive"))
                {
                    ViewBag.ItemReceiveUrl = "/Process/PurchaseReceive";
                    ViewBag.NoOfItemReceive = PurchaseReceiveGetPOBySupID().ToString();
                }
                else
                {
                    ViewBag.ItemReceiveUrl = "#";
                    ViewBag.NoOfItemReceive = "0";
                }
                ViewBag.ItemReceive = "Purchase Receive";

                if (IsPermissionApply("StockReturn", "StockReturnShopReceive"))
                {
                    ViewBag.TransferReceiveUrl = "/StockReturn/StockReturnShopReceive";
                    ViewBag.NoOfTransferReceive = GetNonRcvChlnByShopID().ToString();
                }
                else
                {
                    ViewBag.TransferReceiveUrl = "#";
                    ViewBag.NoOfTransferReceive = "0";
                }
                ViewBag.TransferReceive = "Stock Return Receive";

                if (IsPermissionApply("Process", "DeliveryToShop"))
                {
                    ViewBag.SaleUrl = "/Process/DeliveryToShop";
                }
                else
                {
                    ViewBag.SaleUrl = "#";
                }
                ViewBag.FaIcon = "fa fa-industry fa-4x";
                ViewBag.Sale = "Delivery to Shop";

                if (IsPermissionApply("SalesReport", "MultipleSalesReport"))
                {
                    ViewBag.SaleReportUrl = "/SalesReport/MultipleSalesReport";
                }
                else
                {
                    ViewBag.SaleReportUrl = "#";
                }
                ViewBag.SaleReport = "Sales Report"; 
            }
            else
            {
                if (IsPermissionApply("Shop", "ShopReceive"))
                {
                    ViewBag.ItemReceiveUrl = "/Shop/ShopReceive";
                    ViewBag.NoOfItemReceive = ShopReceiveGetDCNOByShopID().ToString();
                }
                else
                {
                    ViewBag.ItemReceiveUrl = "#";
                    ViewBag.NoOfItemReceive = "0";
                }
                ViewBag.ItemReceive = "Shop Receive";

                if (IsPermissionApply("StockReturn", "StockReturnShopReceive"))
                {
                    ViewBag.TransferReceiveUrl = "/StockReturn/StockReturnShopReceive";
                    ViewBag.NoOfTransferReceive = GetNonRcvChlnByShopID().ToString();
                }
                else
                {
                    ViewBag.TransferReceiveUrl = "#";
                    ViewBag.NoOfTransferReceive = "0";
                }
                ViewBag.TransferReceive = "Shop Tranfer Receive";
                
                if (IsPermissionApply("Sales", "Sale"))
                {
                    ViewBag.SaleUrl = "/Sales/Sale";
                }
                else
                {
                    ViewBag.SaleUrl = "#";
                }
                ViewBag.FaIcon = "fa fa-shopping-cart fa-4x";
                ViewBag.Sale = "Sale";

                if (IsPermissionApply("SalesReport", "MultipleSalesReport"))
                {
                    ViewBag.SaleReportUrl = "/SalesReport/MultipleSalesReport";
                }
                else
                {
                    ViewBag.SaleReportUrl = "#";
                }
                ViewBag.SaleReport = "Sales Report"; 
            }
            return View();
        }

        public ActionResult PriceChangedActive()
        {
            string CPCNo = "";
            try
            {
                DateTime currenTime = Convert.ToDateTime(DateTime.Now.ToShortDateString());
                List<CircularPriceChanged> circularPrice = _priceChangedService.GetTodayWillActive(currenTime, "N");
                circularPrice = circularPrice.OrderBy(o => o.EffectiveDate).ToList();
                foreach (CircularPriceChanged pc in circularPrice)
                {
                    List<CircularPriceChangedDetail> pcDetails = _priceChangedDetailService.GetByCPCNo(pc.CPCNo);
                    foreach (CircularPriceChangedDetail pcd in pcDetails)
                    {
                        BuyCentral bc = _buyCentralService.GetObjByBarcode(pcd.BarCode);
                        bc.RPU = pcd.CngRPU;
                        pcd.EffectedbalQty = bc.balQty;

                        // update RPU in style/Size
                        StyleSize ss = _styleSizeService.GetstyleSizeByBarcode(pcd.BarCode);
                        ss.RPU = pcd.CngRPU;

                        //  upade RPU in shop Delivery (ichallan (not transfer) and ichallanTemp)
                        List<iChallanTemp> ict = _iChallanTempService.GetByBarCode(pcd.BarCode);
                        foreach (iChallanTemp ictt in ict)
                        {
                            ictt.RPU = pcd.CngRPU;
                        }
                        List<iChallan> ic = _iChallanService.GetByBarCode(pcd.BarCode, "N");
                        foreach (iChallanTemp i in ict)
                        {
                            i.RPU = pcd.CngRPU;
                        }

                        // update RPU in CS to Supplier Stock Return Temp table
                        List<StockReturnTemp> srt = _stockReturnTempService.GetByBarCode(pcd.BarCode);
                        foreach (StockReturnTemp ir in srt)
                        {
                            ir.RPU = pcd.CngRPU;
                        }

                    }
                    pc.IsActivated = "Y";

                    if (CPCNo == "")
                        CPCNo += pc.CPCNo;
                    else
                    {
                        CPCNo += ", " + pc.CPCNo;
                    }
                }
                if (CPCNo != "")
                {
                    _buyCentralService.Save();
                    _priceChangedService.Save();
                    _priceChangedDetailService.Save();
                    _styleSizeService.Save();
                    _iChallanTempService.Save();
                    _iChallanService.Save();
                    _stockReturnTempService.Save();
                }
            }
            catch (Exception ex)
            {
                return Json(new {result = false, Error = ex.Message.ToString()}, JsonRequestBehavior.AllowGet);
            }

            if (CPCNo != "")
                return Json(new {result = true, CPCNo = CPCNo}, JsonRequestBehavior.AllowGet);
            else
                return Json(new {result = false}, JsonRequestBehavior.AllowGet);
        }

        private bool IsPermissionApply(string Controller, string ActionName)
        {
            List<RetailMaster.POS.Web.ViewModels.MenuURLViewModel> lstMenus = null;
            if (Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.SessionMenu] == null)
            {
                lstMenus = new GlobalClass().GetMenuByUserName(User.Identity.Name);
                Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.SessionMenu] = lstMenus;
            }
            else
            {
                lstMenus =
                    Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.SessionMenu] as
                        List<RetailMaster.POS.Web.ViewModels.MenuURLViewModel>;
            }
            MenuURLViewModel menu = lstMenus.FindAll(m => m.Controller == Controller && m.ActionName == ActionName).FirstOrDefault();
            if (menu != null)
                return true;
            else
                return false;
        }


        private int ShopReceiveGetDCNOByShopID()
        {
            int count = 0;
            DataTable dt = _buyService.GetDCNoByShopID(GetLogedInInfo().ShopID);
            if (dt.Rows.Count > 0)
            {
                count = dt.Rows.Count;
            }
            return count;
        }

        private int PurchaseReceiveGetPOBySupID()
        {
            int count = 0;
            DataTable dt = _buyOrderService.GetPOBySupID("All");
            if (dt.Rows.Count > 0)
            {
                count = dt.Rows.Count;
            }
            return count;
        }

        private int GetNonRcvChlnByShopID()
        {
            int count = 0;
            DataTable dt = _stockReturnShopService.GetNonRcvChlnByShopID(GetLogedInInfo().ShopID);
            if (dt.Rows.Count > 0)
            {
                count = dt.Rows.Count;
            }
            return count;
        }
    }
}