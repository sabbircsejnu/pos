﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AutoMapper;
using Newtonsoft.Json;
using RetailMaster.POS.Models;
using RetailMaster.POS.Service;
using RetailMaster.POS.Service.ServiceLayer;
using RetailMaster.POS.Web.BLL;
using RetailMaster.POS.Web.ViewModels;
using RetailMaster.POS.Web.Models;


namespace RetailMaster.POS.Web.Controllers
{
    public class StockReturnController : Controller
    {
        private readonly IGlobalSetupService _globalSetupService;
        private readonly ISupplierService _supplierService;
        private readonly IBuyCentralService _buyCentralService;
        private readonly IStockReturnService _stockReturnService;
        private readonly IStockReturnTempService _stockReturnTempService;
        private readonly IAccountsChlnService _accountsChlnService;
        private readonly IStockDMLService _stockDmlService;
        private readonly IStockDMLTempService _stockDmlTempService;
        private readonly IShopListService _shopListService;
        private readonly IStockReturnShopService _stockReturnShopService;
        private readonly IStockReturnShopTempService _stockReturnShopTempService;
        private readonly IBuyService _buyService;
        private readonly IReasonsForReturnService _reasongForReturnService;
        
        public StockReturnController(IGlobalSetupService globalSetupService,ISupplierService supplierService,
            IBuyCentralService buyCentralService, IStockReturnService stockReturnService, IStockReturnTempService stockReturnTempService,
            IAccountsChlnService accountsChlnService, IStockDMLService stockDmlService, IStockDMLTempService stockDmlTempService,
            IStockReturnShopService stockReturnShopService, IStockReturnShopTempService stockReturnShopTempService, IShopListService shopListService,
            IBuyService buyService, IReasonsForReturnService reasongForReturnService)
        {
            _globalSetupService = globalSetupService;
            _supplierService = supplierService;
            this._buyCentralService = buyCentralService;
            this._stockReturnService = stockReturnService;
            this._stockReturnTempService = stockReturnTempService;
            this._accountsChlnService = accountsChlnService;
            this._stockDmlService = stockDmlService;
            this._stockDmlTempService = stockDmlTempService;
            this._stockReturnShopService = stockReturnShopService;
            this._stockReturnShopTempService = stockReturnShopTempService;
            this._shopListService = shopListService;
            this._buyService = buyService;
            this._reasongForReturnService = reasongForReturnService;
        }
        
        private LogedInInfo GetLogedInInfo()
        {
            LogedInInfo info = new LogedInInfo();
            if (HttpContext.Request.Cookies["POSLogedInInfo"] != null)
            {
                HttpCookie cookie = HttpContext.Request.Cookies.Get("POSLogedInInfo");
                info = Newtonsoft.Json.JsonConvert.DeserializeObject<LogedInInfo>(cookie.Value) as LogedInInfo;
            }
            return info;
        }

        #region Stock Return
        public ActionResult WarehouseToSupplier()
        {
            if (!IsPermissionApply("StockReturn", "WarehouseToSupplier"))
            {
                return RedirectToAction("Index", "Home");
            }
            List<SupplierViewModel> resultSupplier = null;
            IEnumerable<Supplier> dataSupplier = _supplierService.Gets();
            resultSupplier = Mapper.Map<IEnumerable<Supplier>, IEnumerable<SupplierViewModel>>(dataSupplier).ToList();
            SupplierViewModel obj = new SupplierViewModel();
            obj.SupID = "";
            obj.Supname = "Select";
            resultSupplier.Insert(0, obj);
            ViewBag.SupplierList = new SelectList(resultSupplier, "SupID", "Supname");

            List<ReasonsForReturn> reasons = _reasongForReturnService.Gets("R").ToList();
            ViewBag.ReasonsList = new SelectList(reasons, "Reasons", "Reasons");
            
            return View();
        }

        public ActionResult BuyCentralBySupID(string SupID)
        {
            var data = _buyCentralService.GetBySupID(SupID);
            var list = JsonConvert.SerializeObject(new { data = data }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });

            return Content(list, "application/json");
        }

        public ActionResult BuyCentralFindByBarcode(string BarCode)
        {
            var list="";
            var data = _buyCentralService.GetByBarCode(BarCode);
            if (data.Rows.Count>0)
            {
                list = JsonConvert.SerializeObject(new { result=true, data = data }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });
            }
            else
            {
                list = JsonConvert.SerializeObject(new { result = false}, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });
            }
            

            return Content(list, "application/json");
        }

        public ActionResult TempStockReturnInsert(string BarCode, string ReturnQty, string SupID, string Reasons)
        {
            try
            {
                DataTable dt = _buyCentralService.GetByBarCode(BarCode);
                StockReturnTemp srt = new StockReturnTemp();

                string MaxID = new GlobalClass().GetMaxIdWithPrfix("Chln", "6", "000001", "StockReturn", "r");
                decimal temp = 0;
                srt.Chln = "T" + MaxID;
                srt.BarCode = dt.Rows[0]["BarCode"].ToString();
                srt.CmpIDX = srt.Chln + srt.BarCode;

                srt.BTName = dt.Rows[0]["BTName"].ToString();
                decimal.TryParse(dt.Rows[0]["CPU"].ToString(), out temp);
                srt.CPU = temp;
                srt.GroupName = dt.Rows[0]["GroupName"].ToString();
                srt.PrdName = dt.Rows[0]["PrdName"].ToString();
                decimal.TryParse(dt.Rows[0]["Qty"].ToString(), out temp);
                srt.Qty = temp;
                decimal.TryParse(dt.Rows[0]["RPU"].ToString(), out temp);
                srt.RPU = temp;
                decimal.TryParse(dt.Rows[0]["RPU"].ToString(), out temp);
                srt.Reasons = Reasons;
                srt.ReturnDt = DateTime.Now;
                srt.SSName = dt.Rows[0]["SSName"].ToString();
                srt.ShopID = GetLogedInInfo().ShopID;
                srt.SupID = SupID;
                srt.SupName = dt.Rows[0]["SupName"].ToString();
                srt.TransferTo = "SUP";
                srt.UserID = User.Identity.Name;
                decimal.TryParse(dt.Rows[0]["balQty"].ToString(), out temp);
                srt.balQty = temp;
                srt.cSqty = 1;
                decimal.TryParse(dt.Rows[0]["rQty"].ToString(), out temp);
                srt.rQty = temp;
                srt.sBarcode = dt.Rows[0]["sBarcode"].ToString();
                decimal.TryParse(dt.Rows[0]["sQty"].ToString(), out temp);
                srt.sQty = temp;
                temp = 0;
                decimal.TryParse(ReturnQty, out temp);
                srt.sReturn = temp;
                _stockReturnTempService.Create(srt);
                _stockReturnTempService.Save();

                var list = JsonConvert.SerializeObject(new { result = true, data = "Saved" }, Formatting.None,
                           new JsonSerializerSettings()
                           {
                               ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                           });

                return Content(list, "application/json");
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult StockReturnTempGetList()
        {
            List<StockReturnTemp> srt = new List<StockReturnTemp>();
            srt = _stockReturnTempService.Gets().ToList();
            if (srt != null)
            {
                srt = srt.FindAll(m => m.UserID == User.Identity.Name);
            }

            var list = JsonConvert.SerializeObject(new { result = true, data = srt }, Formatting.None,
                           new JsonSerializerSettings()
                           {
                               ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                           });

            return Content(list, "application/json");
        }

        public ActionResult StockReturntempDelete(string CmpIDX)
        {
            try
            {
                var data = _stockReturnTempService.Get(CmpIDX);
                _stockReturnTempService.Remove(data);
                _stockReturnTempService.Save();
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult StockReturntempDeleteAll()
        {
            try
            {
                _stockReturnTempService.RemoveTempList(User.Identity.Name);
                _stockReturnTempService.Save();
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult StockReturnInsert()
        {
            string newChln = "";
            try
            {
                decimal totalAccount = 0;
                List<StockReturnTemp> stockReturnTemps = _stockReturnTempService.Gets().ToList();
                if (stockReturnTemps == null)
                {
                     return Json(new { result = false, Error = "No Data Found" }, JsonRequestBehavior.AllowGet);
                }

                newChln = new GlobalClass().GetMaxIdWithPrfix("Chln", "6", "000001", "StockReturn", "r");
                decimal temp = 0;
                decimal CPU = 0;
                decimal sReturn = 0;

                StockReturnTemp OneValue = stockReturnTemps.FirstOrDefault();
                
                foreach (StockReturnTemp srt in stockReturnTemps)
                {
                    StockReturn sr = new StockReturn();

                    decimal.TryParse(srt.CPU.ToString(), out CPU);
                    decimal.TryParse(srt.sReturn.ToString(), out sReturn);
                    totalAccount += CPU * sReturn;
                    sr.Chln = newChln;
                    sr.BarCode = srt.BarCode;
                    sr.CmpIDX = sr.Chln + sr.BarCode;
                    sr.BTName = srt.BTName;
                    sr.CPU = srt.CPU;
                    sr.GroupName = srt.GroupName;
                    sr.PrdName = srt.PrdName;
                    sr.Qty = srt.Qty;
                    sr.RPU = srt.RPU;
                    sr.Reasons = srt.Reasons;
                    sr.ReturnDt = srt.ReturnDt;
                    sr.SSName = srt.SSName;
                    sr.ShopID = srt.ShopID;
                    sr.SupID = srt.SupID;
                    sr.SupName = srt.SupName;
                    sr.TransferTo = srt.TransferTo;
                    sr.UserID = User.Identity.Name;
                    sr.balQty = srt.balQty;
                    sr.cSqty = 1;
                    sr.rQty = srt.rQty;
                    sr.sBarcode = srt.sBarcode;
                    sr.sQty = srt.sQty;
                    sr.sReturn = srt.sReturn;
                    _stockReturnService.Create(sr);
                    temp = 0;
                    decimal.TryParse(sr.sReturn.ToString(), out temp);
                    _buyCentralService.ReduceStockReturnQty(sr.BarCode, temp);
                }

                AccountsChln ac=new AccountsChln();
                ac.Chln = newChln;
                ac.AddPrdComm = 0;
                ac.BuyDt = DateTime.Now;
                ac.ChlnTotal = totalAccount;
                ac.SupID = OneValue.SupID;
                ac.SupName = OneValue.SupName;
                ac.SupRef = "Stock Return";
                ac.TotalPrdComm = 0;
                ac.Transfer = "N";
                ac.UserID = User.Identity.Name;
                _accountsChlnService.Create(ac);
                _accountsChlnService.Save();

                _stockReturnTempService.RemoveTempList(User.Identity.Name);
                _stockReturnService.Save();
                _buyCentralService.Save();
                _stockReturnTempService.Save();
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Saved", Chln = newChln }, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region Damage and Lost

        public ActionResult DamageLost()
        {
            if (!IsPermissionApply("StockReturn", "DamageLost"))
            {
                return RedirectToAction("Index", "Home");
            }
            List<ReasonsForReturn> reasons = _reasongForReturnService.Gets("D").ToList();
            ViewBag.ReasonsList = new SelectList(reasons, "Reasons", "Reasons");
            return View();
        }

        public ActionResult DamageLostGetList()
        {
            List<StockDMLTemp> srt = new List<StockDMLTemp>();
            srt = _stockDmlTempService.Gets().ToList();
            if (srt != null)
            {
                srt = srt.FindAll(m => m.UserID == User.Identity.Name);
            }

            var list = JsonConvert.SerializeObject(new { result = true, data = srt }, Formatting.None,
                           new JsonSerializerSettings()
                           {
                               ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                           });

            return Content(list, "application/json");
        }

        public ActionResult DamageLostTempInsert(string BarCode, string ReturnQty, string Reasons)
        {
            try
            {
                DataTable dt = _buyCentralService.GetByBarCode(BarCode);
                StockDMLTemp srt = new StockDMLTemp();

                string MaxID = new GlobalClass().GetMaxIdWithPrfix("Chln", "6", "000001", "StockDML", "DMLQT");
                decimal temp = 0;
                srt.Chln = "T" + MaxID;
                srt.BarCode = dt.Rows[0]["BarCode"].ToString();
                srt.CmpIDX = srt.Chln + srt.BarCode;
                StockDMLTemp alreadyExists= _stockDmlTempService.Get(srt.CmpIDX);
                if (alreadyExists != null)
                {
                    temp = 0;
                    decimal.TryParse(ReturnQty, out temp);
                    alreadyExists.sReturn += temp;

                    decimal.TryParse(dt.Rows[0]["balQty"].ToString(), out temp);
                    alreadyExists.balQty = temp;

                    decimal.TryParse(dt.Rows[0]["rQty"].ToString(), out temp);
                    srt.rQty = temp;

                    decimal.TryParse(dt.Rows[0]["sQty"].ToString(), out temp);
                    srt.sQty = temp;

                    _stockDmlTempService.Update(alreadyExists);
                    _stockDmlTempService.Save();
                }
                else
                {
                    srt.BTName = dt.Rows[0]["BTName"].ToString();
                    decimal.TryParse(dt.Rows[0]["CPU"].ToString(), out temp);
                    srt.CPU = temp;
                    srt.GroupName = dt.Rows[0]["GroupName"].ToString();
                    srt.PrdName = dt.Rows[0]["PrdName"].ToString();
                    decimal.TryParse(dt.Rows[0]["Qty"].ToString(), out temp);
                    srt.Qty = temp;
                    decimal.TryParse(dt.Rows[0]["RPU"].ToString(), out temp);
                    srt.RPU = temp;
                    decimal.TryParse(dt.Rows[0]["RPU"].ToString(), out temp);
                    srt.REASONS = Reasons;
                    srt.ReturnDt = DateTime.Now;
                    srt.SSName = dt.Rows[0]["SSName"].ToString();
                    srt.ShopID = GetLogedInInfo().ShopID;
                    srt.SupID = dt.Rows[0]["SupID"].ToString();
                    srt.SupName = dt.Rows[0]["SupName"].ToString();
                    srt.UserID = User.Identity.Name;
                    decimal.TryParse(dt.Rows[0]["balQty"].ToString(), out temp);
                    srt.balQty = temp;
                    srt.cSqty = 1;
                    decimal.TryParse(dt.Rows[0]["rQty"].ToString(), out temp);
                    srt.rQty = temp;
                    srt.sBarcode = dt.Rows[0]["sBarcode"].ToString();
                    decimal.TryParse(dt.Rows[0]["sQty"].ToString(), out temp);
                    srt.sQty = temp;
                    temp = 0;
                    decimal.TryParse(ReturnQty, out temp);
                    srt.sReturn = temp;
                    _stockDmlTempService.Create(srt);
                    _stockDmlTempService.Save();
                }
                var list = JsonConvert.SerializeObject(new { result = true, data = "Saved" }, Formatting.None,
                           new JsonSerializerSettings()
                           {
                               ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                           });

                return Content(list, "application/json");
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult DamageLostTempDelete(string CmpIDX)
        {
            try
            {
                var data = _stockDmlTempService.Get(CmpIDX);
                _stockDmlTempService.Remove(data);
                _stockDmlTempService.Save();
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult DamageLostTempDeleteAll()
        {
            try
            {
                _stockDmlTempService.RemoveTempList(User.Identity.Name);
                _stockDmlTempService.Save();
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult DamageLostInsert()
        {
            string newChln = "";
            try
            {
                List<StockDMLTemp> stockDMLTemp = _stockDmlTempService.Gets().ToList();
                if (stockDMLTemp == null)
                {
                    return Json(new { result = false, Error = "No Data Found" }, JsonRequestBehavior.AllowGet);
                }

                newChln = new GlobalClass().GetMaxIdWithPrfix("Chln", "6", "000001", "StockDML", "DMLQT");
                decimal temp = 0;
                foreach (StockDMLTemp srt in stockDMLTemp)
                {
                    StockDML sr = new StockDML();
                    sr.Chln = newChln;
                    sr.BarCode = srt.BarCode;
                    sr.CmpIDX = sr.Chln + sr.BarCode;
                    sr.sBarcode = srt.sBarcode;
                    sr.SupID = srt.SupID;
                    sr.CPU = srt.CPU;
                    sr.Qty = srt.Qty;
                    sr.RPU = srt.RPU;
                    sr.rQty = srt.rQty;
                    sr.cSqty = srt.cSqty;
                    sr.sQty = srt.sQty;
                    sr.ReturnDt = srt.ReturnDt;
                    sr.ShopID = srt.ShopID;
                    sr.UserID = User.Identity.Name;
                    sr.balQty = srt.balQty;
                    sr.sReturn = srt.sReturn;
                    sr.REASONS = srt.REASONS;
                    _stockDmlService.Create(sr);

                    temp = 0;
                    decimal.TryParse(sr.sReturn.ToString(), out temp);
                    _buyCentralService.ReduceDmlQty(sr.BarCode, temp);
                }
                _stockDmlTempService.RemoveTempList(User.Identity.Name);
                _stockDmlService.Save();
                _buyCentralService.Save();
                _stockDmlTempService.Save();
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Saved", Chln = newChln }, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Stock Return Shop

        public ActionResult StockReturnShop()
        {
            if (!IsPermissionApply("StockReturn", "StockReturnShop"))
            {
                return RedirectToAction("Index", "Home");
            }
            ShopList resultShop = null;
            List<ShopList> dataShop = _shopListService.Gets().ToList();
            resultShop = dataShop.Find(c => c.ShopID == GetLogedInInfo().ShopID);
            dataShop.Remove(resultShop);
            List<ShopList> newList = new List<ShopList>();
            ShopList ss = new ShopList();
            ss.ShopID = "";
            ss.ShopName = "Select";
            newList.Add(ss);
            foreach (ShopList sl in dataShop)
            {
                ShopList s = new ShopList();
                s.ShopID = sl.ShopID;
                s.ShopName = sl.ShopID + "-" + sl.ShopName;
                newList.Add(s);
            }
            ViewBag.ShopList = new SelectList(newList, "ShopID", "ShopName");

            List<ReasonsForReturn> reasons = _reasongForReturnService.Gets("R").ToList();
            ViewBag.ReasonsList = new SelectList(reasons, "Reasons", "Reasons");

            return View();
        }

        public ActionResult BuyGetByBarCode(string BarCode)
        {
            DataTable dt = _buyService.GetBarCodeShopID(BarCode,GetLogedInInfo().ShopID);
            var list = "";
            if (dt.Rows.Count > 0)
            {
                list = JsonConvert.SerializeObject(new { result = true, data = dt }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });
            }
            else
            {
                list = JsonConvert.SerializeObject(new { result = false }, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                        });
            }
            
            return Content(list, "application/json");
        }

        public ActionResult BuyByShopID()
        {
            DataTable dt = _buyService.GetShopItem(GetLogedInInfo().ShopID);

            var list = JsonConvert.SerializeObject(new { result = true, data = dt }, Formatting.None,
                           new JsonSerializerSettings()
                           {
                               ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                           });

            return Content(list, "application/json");
        }

        public ActionResult TempStockReturnShopInsert(string BarCode, string ReturnQty, string Reasons, string TransferTo)
        {
            try
            {
                string ShopID = GetLogedInInfo().ShopID;
                DataTable dt = _buyService.GetBarCodeShopID(BarCode, ShopID);
                TempStockReturnShop srt = new TempStockReturnShop();
                int tQty = 0;
                List<TempStockReturnShop> sr = _stockReturnShopTempService.GetByShopID(ShopID, User.Identity.Name, TransferTo).ToList();
                TempStockReturnShop findOne = sr.FindAll(m => m.Barcode == BarCode && m.ShopId == ShopID).FirstOrDefault();
                if (findOne != null)
                {
                    int.TryParse(ReturnQty, out tQty);
                    findOne.TQty += tQty;
                    _stockReturnShopTempService.Update(findOne);
                    _stockReturnShopTempService.Save();
                }
                else
                {
                    string MaxID = new GlobalClass().GetMaxId("TempId", "TempStockReturnShop");
                    decimal temp = 0;
                    decimal.TryParse(MaxID, out temp);
                    srt.TempId = temp;
                    srt.UserId = User.Identity.Name;
                    srt.ShopId = GetLogedInInfo().ShopID;
                    srt.SBarocde = dt.Rows[0]["sBarCode"].ToString();
                    srt.Barcode = dt.Rows[0]["BarCode"].ToString();
                    int.TryParse(ReturnQty, out tQty);
                    srt.TQty = tQty;
                    decimal.TryParse(dt.Rows[0]["CPU"].ToString(), out temp);
                    srt.CPU = temp;
                    decimal.TryParse(dt.Rows[0]["RPU"].ToString(), out temp);
                    srt.RPU = temp;
                    srt.ProdcutDescription = dt.Rows[0]["GroupName"].ToString() + "-" + dt.Rows[0]["PrdName"].ToString() + "-" + dt.Rows[0]["BTName"].ToString() + "-" + dt.Rows[0]["SSName"].ToString();
                    srt.TransferTo = TransferTo;
                    _stockReturnShopTempService.Create(srt);
                    _stockReturnShopTempService.Save();
                }
                
                var list = JsonConvert.SerializeObject(new { result = true, data = "Saved" }, Formatting.None,
                           new JsonSerializerSettings()
                           {
                               ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                           });

                return Content(list, "application/json");
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult TempStockReturnShopList(string TransferTo)
        {
            List<TempStockReturnShop> sr = _stockReturnShopTempService.GetByShopID(GetLogedInInfo().ShopID, User.Identity.Name, TransferTo).ToList();

            var list = JsonConvert.SerializeObject(new { result = true, data = sr }, Formatting.None,
                           new JsonSerializerSettings()
                           {
                               ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                           });

            return Content(list, "application/json");
        }

        public ActionResult TempStockReturnShopDelete(string BarCode)
        {
            try
            {
                List<TempStockReturnShop> sr = _stockReturnShopTempService.Gets().ToList();
                TempStockReturnShop findOne = sr.FindAll(m => m.Barcode == BarCode && m.ShopId == GetLogedInInfo().ShopID).FirstOrDefault();
                _stockReturnShopTempService.Remove(findOne);
                _stockReturnShopTempService.Save();
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult TempStockReturnShopDeleteAll(string TransferTo)
        {
            try
            {
                _stockReturnShopTempService.RemoveTempList(GetLogedInInfo().ShopID, User.Identity.Name,TransferTo);
                _stockReturnShopTempService.Save();
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Deleted" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult StockReturnShopInsert(string TransferToShop)
        {
            string newChln = "";
            try
            {
                string ShopID = GetLogedInInfo().ShopID;
                decimal totalAccount = 0;
                DataTable dt = _stockReturnShopTempService.GetListByShopID(ShopID,TransferToShop, User.Identity.Name);
                if (dt.Rows.Count == 0)
                {
                    return Json(new { result = false, Error = "No Data Found" }, JsonRequestBehavior.AllowGet);
                }

                newChln = new GlobalClass().GetMaxIdWithPrfix("Chln", "7", "0000001", "StockReturnShop", ShopID);
                decimal temp = 0;
                decimal CPU = 0;
                decimal sReturn = 0;
                string TransferTo = "";
                foreach (DataRow dr in dt.Rows)
                {
                    StockReturnShop sr = new StockReturnShop();
                    sr.Chln = newChln;
                    sr.BarCode = dr["Barcode"].ToString();
                    sr.CmpIDX = sr.Chln + sr.BarCode;
                    sr.sBarcode = dr["SBarocde"].ToString();
                    sr.SupID = dr["SupID"].ToString(); ;
                    decimal.TryParse(dr["CPU"].ToString(), out temp);
                    sr.CPU = temp;
                    decimal.TryParse(dr["RPU"].ToString(), out temp);
                    sr.RPU = temp;
                    decimal.TryParse(dr["TQty"].ToString(), out temp);
                    sr.Qty = temp;

                    sr.RcvQty = 0;
                    sr.ReturnDt = DateTime.Now;
                    sr.UserID = User.Identity.Name;
                    sr.ShopID = ShopID;
                    sr.TransferTo = dr["TransferTo"].ToString();
                    _stockReturnShopService.Create(sr);

                    TransferTo= dr["TransferTo"].ToString();

                    temp = 0;
                    decimal.TryParse(sr.Qty.ToString(), out temp);
                    // Reduce balQty and add with TrnsQty
                    _buyService.AddTransferQty(sr.BarCode, ShopID, temp);
                }
                _stockReturnShopService.Save();
                _buyService.Save();

                _stockReturnShopTempService.RemoveTempList(ShopID, User.Identity.Name, TransferTo);
                _stockReturnShopTempService.Save();
            }
            catch (Exception ex)
            {
                return Json(new { result = false, Error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { result = true, Error = "Saved", Chln = newChln }, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region ====== ShopReceive ======
        public ActionResult StockReturnShopReceive()
        {
            if (!IsPermissionApply("StockReturn", "StockReturnShopReceive"))
            {
                return RedirectToAction("Index", "Home");
            }

            DataTable dt = _stockReturnShopService.GetShopListByShopID(GetLogedInInfo().ShopID);
            List<ShopList> newList = new List<ShopList>();
            ShopList ss = new ShopList();
            ss.ShopID = "";
            ss.ShopName = "Select";
            newList.Add(ss);
            if (dt != null)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    ShopList s = new ShopList();
                    s.ShopID = dr["ShopID"].ToString();
                    s.ShopName = dr["ShopName"].ToString();
                    newList.Add(s);
                }
            }
            ViewBag.ShopList = new SelectList(newList, "ShopID", "ShopName");
            return View();
        }

        public ActionResult GetNonRcvChlnByShopID(string ShopID)
        {
            DataTable dt = _stockReturnShopService.GetNonRcvChlnByShopID(GetLogedInInfo().ShopID);
            List<string> chln=new List<string>();
            foreach (DataRow dr in dt.Rows)
            {
                chln.Add(dr["Chln"].ToString());
            }

            var list = JsonConvert.SerializeObject(new { result = true, data = chln }, Formatting.None,
                           new JsonSerializerSettings()
                           {
                               ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                           });

            return Content(list, "application/json");
        }

        public ActionResult GetByChln(string Chln)
        {
            DataTable dt = _stockReturnShopService.GetByChln(Chln);

            var list = JsonConvert.SerializeObject(new { result = true, data = dt }, Formatting.None,
                           new JsonSerializerSettings()
                           {
                               ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                           });

            return Content(list, "application/json");
        }

        public ActionResult ShopReceive(string Chln)
        {
            string ShopID = GetLogedInInfo().ShopID;
            
            if (ShopID == "9999")
            {
                List<StockReturnShop> srs = _stockReturnShopService.Gets(Chln).ToList();

                foreach (StockReturnShop sr in srs)
                {
                    sr.IsTransfer = "T";
                    sr.RcvQty = sr.Qty;
                    sr.RecevieDt = DateTime.Now;
                    _stockReturnShopService.Update(sr);

                    decimal temp = 0;
                    decimal.TryParse(sr.Qty.ToString(), out temp);
                    _buyCentralService.TransferReceiveQty(sr.BarCode, temp); 
                }
                _buyCentralService.Save();
                _stockReturnShopService.Save();
            }
            else
            {
                List<StockReturnShop> srs = _stockReturnShopService.Gets(Chln).ToList();
                foreach (StockReturnShop sr in srs)
                {
                    sr.IsTransfer = "T";
                    sr.RcvQty = sr.Qty;
                    sr.RecevieDt = DateTime.Now;
                    _stockReturnShopService.Update(sr);

                    decimal temp = 0;
                    decimal.TryParse(sr.Qty.ToString(), out temp);
                    //if not exits this barcode with this shopId then insert new row into the Buy table for this shopId 

                    DataTable dt = _buyService.GetBarCodeShopID(sr.BarCode, ShopID);
                    if (dt.Rows.Count==0)
                    {
                        DataTable dtrFB = _buyService.GetBarCodeShopID(sr.BarCode, sr.ShopID);
                        // insert new row into buy
                        Buy b = new Buy();

                        b.CMPIDX = ShopID + sr.BarCode;
                        b.sBarCode = sr.sBarcode;
                        b.BarCode = sr.BarCode;
                        b.Chln = Chln;
                        b.sreturn = 0;
                        b.TrfQty = 0;
                        b.SrpQty = 0;
                        b.InvQty = 0;
                        b.BuyDT = DateTime.Now;
                        b.CPU = sr.CPU;
                        b.RPU = sr.RPU;
                        //b.RPP = sr.RPP;
                        decimal.TryParse(dtrFB.Rows[0]["WSP"].ToString(), out temp);
                        b.WSP = temp;
                        decimal.TryParse(dtrFB.Rows[0]["WSQ"].ToString(), out temp);
                        b.WSQ = temp;
                        decimal.TryParse(dtrFB.Rows[0]["Point"].ToString(), out temp);
                        b.Point = temp;
                        decimal.TryParse(dtrFB.Rows[0]["Reorder"].ToString(), out temp);
                        b.Reorder = temp;
                        decimal.TryParse(dtrFB.Rows[0]["DiscPrcnt"].ToString(), out temp);
                        b.DiscPrcnt = temp;
                        decimal.TryParse(dtrFB.Rows[0]["VATPrcnt"].ToString(), out temp);
                        b.VATPrcnt = temp;
                        decimal.TryParse(dtrFB.Rows[0]["PrdComm"].ToString(), out temp);
                        b.PrdComm = temp;
                        b.Qty = sr.Qty;
                        b.balQty = sr.Qty;
                        decimal.TryParse(dtrFB.Rows[0]["bQty"].ToString(), out temp);
                        b.bQty = temp;
                        decimal.TryParse(dtrFB.Rows[0]["sQty"].ToString(), out temp);
                        b.sQty = temp;
                        decimal.TryParse(dtrFB.Rows[0]["rQty"].ToString(), out temp);
                        b.rQty = temp;
                        decimal.TryParse(dtrFB.Rows[0]["dmlqty"].ToString(), out temp);
                        b.dmlqty = temp;
                        b.ZoneID = dtrFB.Rows[0]["ZoneID"].ToString();
                        b.ShopID = ShopID;
                        b.SupID = dtrFB.Rows[0]["SupID"].ToString();
                        b.Transfer = "N";
                        b.SupRef = "Ref";
                        b.UserID = User.Identity.Name;
                        _buyService.Create(b);
                    }
                    else
                    {
                        _buyService.TransferReceiveQty(sr.BarCode, ShopID, temp);     
                    }
                    
                }
                _buyService.Save();
                _stockReturnShopService.Save();
            }
            var list = JsonConvert.SerializeObject(new { result = true, Chln = Chln }, Formatting.None,
                          new JsonSerializerSettings()
                          {
                              ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                          });

            return Content(list, "application/json");
        }

        #endregion

        #region ==== Menu Permission Check =====
        private bool IsPermissionApply(string Controller, string ActionName)
        {
            List<MenuURLViewModel> lstMenus = null;
            if (Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.SessionMenu] == null)
            {
                lstMenus = new GlobalClass().GetMenuByUserName(User.Identity.Name);
                Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.SessionMenu] = lstMenus;
            }
            else
            {
                lstMenus =
                    Session[RetailMaster.POS.Web.DefaultData.SessionCookieDataManager.SessionMenu] as
                        List<MenuURLViewModel>;
            }
            MenuURLViewModel menu = lstMenus.FindAll(m => m.Controller == Controller && m.ActionName == ActionName).FirstOrDefault();
            if (menu != null)
                return true;
            else
                return false;
        }
        #endregion
    }
}