﻿using System;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using RetailMaster.POS.Web.App_Start;

namespace RetailMaster.POS.Web
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);


            // Autofac and Automapper configurations
            Bootstrapper.Run();
        }

        protected void Application_Error()
        {
            Exception ex = Server.GetLastError();
            if (ex is HttpAntiForgeryException)
            {
                Response.Clear();
                Server.ClearError(); //make sure you log the exception first
                Response.Redirect("~/Home/Index", true);
            }
        }
    }
}
