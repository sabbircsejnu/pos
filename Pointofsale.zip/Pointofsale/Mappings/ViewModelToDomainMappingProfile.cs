﻿using AutoMapper;
using RetailMaster.POS.Models;
using RetailMaster.POS.Web.ViewModels;

namespace RetailMaster.POS.Web.Mappings
{
    public class ViewModelToDomainMappingProfile : Profile
    {

        public override string ProfileName
        {
            get { return "ViewModelToDomainMappings"; }
        }

        protected override void Configure()
        {
            Mapper.CreateMap<GlobalSetupViewModel, GlobalSetup>();
            Mapper.CreateMap<PGroupViewModel, PGroup>();
            Mapper.CreateMap<ProductViewModel, Product>();
            Mapper.CreateMap<BrandTypeViewModel, BrandType>();
            Mapper.CreateMap<SupplierViewModel, Supplier>();
            Mapper.CreateMap<SupplierRegPrdViewModel, SupplierRegPrd>();
            Mapper.CreateMap<StyleSizeViewModel, StyleSize>();
            Mapper.CreateMap<CustomerMstViewModel, CustomerMst>();
            Mapper.CreateMap<BuyOrderViewModel, BuyOrder>();
            Mapper.CreateMap<BuyOrderTempViewModel, BuyOrderTemp>();
            Mapper.CreateMap<BuyOrderTempViewModel, BuyOrder>();
            Mapper.CreateMap<BuyCentralViewModel, BuyCentral>();     
            Mapper.CreateMap<AccountsChlnViewModel, AccountsChln>();
            Mapper.CreateMap<rChallanViewModel, rChallan>();
            Mapper.CreateMap<MenuURLViewModel, MenuURL>();
            Mapper.CreateMap<UsersMenuViewModel, UsersMenu>();
            Mapper.CreateMap<iChallanTempViewModel, iChallanTemp>();
            Mapper.CreateMap<iChallanViewModel, iChallan>();
            Mapper.CreateMap<ShopListViewModel, ShopList>();            
            Mapper.CreateMap<TempTableValueViewModel, TempTableValue>();
            Mapper.CreateMap<BuyRequisitionViewModel, BuyRequisition>();
            Mapper.CreateMap<BuyRequisitionTempViewModel, BuyRequisitionTemp>();
            Mapper.CreateMap<BuyViewModel, Buy>();
            Mapper.CreateMap<rChallanShopViewModel, rChallanShop>();
              //.ForMember(g => g.ChkRegOwner, map => map.MapFrom(vm => vm.ChkRegOwnerB));

            //Mapper.CreateMap<GadgetFormViewModel, Gadget>()
            //    .ForMember(g => g.Name, map => map.MapFrom(vm => vm.GadgetTitle))
            //    .ForMember(g => g.Description, map => map.MapFrom(vm => vm.GadgetDescription))
            //    .ForMember(g => g.Price, map => map.MapFrom(vm => vm.GadgetPrice))
            //    .ForMember(g => g.Image, map => map.MapFrom(vm => vm.File.FileName))
            //    .ForMember(g => g.CategoryID, map => map.MapFrom(vm => vm.GadgetCategory));
        }

    }
}
