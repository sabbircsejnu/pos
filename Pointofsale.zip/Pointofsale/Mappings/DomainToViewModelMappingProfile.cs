﻿using AutoMapper;
using RetailMaster.POS.Models;
using RetailMaster.POS.Web.ViewModels;

namespace RetailMaster.POS.Web.Mappings
{
    public class DomainToViewModelMappingProfile : Profile
    {
        public override string ProfileName
        {
            get { return "DomainToViewModelMappings"; }
        }

        protected override void Configure()
        {
            Mapper.CreateMap<GlobalSetup, GlobalSetupViewModel>();
            Mapper.CreateMap<PGroup, PGroupViewModel>();
            Mapper.CreateMap<Product, ProductViewModel>();
            Mapper.CreateMap<BrandType, BrandTypeViewModel>();
            Mapper.CreateMap<Supplier, SupplierViewModel>();
            Mapper.CreateMap<SupplierRegPrd, SupplierRegPrdViewModel>();
            Mapper.CreateMap<StyleSize, StyleSizeViewModel>();
            Mapper.CreateMap<CustomerMst, CustomerMstViewModel>();
            Mapper.CreateMap<BuyOrder, BuyOrderViewModel>();
            Mapper.CreateMap<BuyOrderTemp, BuyOrderTempViewModel>();
            Mapper.CreateMap<BuyCentral, BuyCentralViewModel>();
            Mapper.CreateMap<AccountsChln, AccountsChlnViewModel>();
            Mapper.CreateMap<rChallan, rChallanViewModel>();
            Mapper.CreateMap<UsersMenu, UsersMenuViewModel>();
            Mapper.CreateMap<MenuURL, MenuURLViewModel>();
            Mapper.CreateMap<iChallanTemp, iChallanTempViewModel>();
            Mapper.CreateMap<iChallan, iChallanViewModel>();
            Mapper.CreateMap<ShopList, ShopListViewModel>();
            Mapper.CreateMap<BuyRequisition, BuyRequisitionViewModel>();
            Mapper.CreateMap<BuyRequisitionTemp, BuyRequisitionTempViewModel>();
            Mapper.CreateMap<Buy, BuyViewModel>();
            Mapper.CreateMap<TempTableValue, TempTableValueViewModel>();
            Mapper.CreateMap<rChallanShop, rChallanShopViewModel>();

        }
    }
}
