﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using RetailMaster.POS.Data;
using RetailMaster.POS.Models;
using RetailMaster.POS.Web.ViewModels;

namespace RetailMaster.POS.Web.BLL
{
   
    public class ReportDbSource
    {
        SQLDAL objSqlData = new SQLDAL();
        Result oResult = new Result();
        public ReportDbSource()
        {
            
        }

        #region Process
        public DataTable GetBuyOrderTempByChln(string chln)
        {
            string sql = "EXECUTE usp_BuyOrderTemp_GetByChln '" + chln + "'";
            oResult = objSqlData.Select(sql);
            return oResult.Data;
        }

        public DataTable GetBuyOrderByChln(string chln)
        {
            string sql = "EXECUTE usp_BuyOrder_GetByChln '" + chln + "'";
            oResult = objSqlData.Select(sql);
            return oResult.Data;
        }

        public DataTable rChallan_GetByChln(string chln)
        {
            string sql = "EXECUTE usp_rChallan_GetByChln '" + chln + "'";
            oResult = objSqlData.Select(sql);
            return oResult.Data;
        }

        public DataTable rChallanTemp_GetByChln(string chln)
        {
            DataTable dtPRT = new DataTable();
            #region dt
            dtPRT.Columns.Add("CmpIDX", typeof(string));
            dtPRT.Columns.Add("Chln", typeof(string));
            dtPRT.Columns.Add("OrderNo", typeof(string));
            dtPRT.Columns.Add("BarCode", typeof(string));
            dtPRT.Columns.Add("sBarCode", typeof(string));
            dtPRT.Columns.Add("Qty", typeof(decimal));
            dtPRT.Columns.Add("sQty", typeof(decimal));
            dtPRT.Columns.Add("CPU", typeof(decimal));
            dtPRT.Columns.Add("ACPU", typeof(decimal));
            dtPRT.Columns.Add("RPU", typeof(decimal));
            dtPRT.Columns.Add("BuyDT", typeof(DateTime));
            dtPRT.Columns.Add("EXPDT", typeof(DateTime));
            dtPRT.Columns.Add("PrdComm", typeof(decimal));
            dtPRT.Columns.Add("TotalPrdComm", typeof(decimal));
            dtPRT.Columns.Add("AddPrdComm", typeof(decimal));
            dtPRT.Columns.Add("ChlnTotal", typeof(decimal));
            dtPRT.Columns.Add("AddiCost", typeof(decimal));
            dtPRT.Columns.Add("bQty", typeof(decimal));
            dtPRT.Columns.Add("SupRef", typeof(string));
            dtPRT.Columns.Add("SupName", typeof(string));
            dtPRT.Columns.Add("GroupName", typeof(string));
            dtPRT.Columns.Add("ItemDesc", typeof(string));
            #endregion
            List<rChallanViewModel> isFoundrChallan = new List<rChallanViewModel>();
            List<rChallanViewModel> result = null;

            string sql = " EXECUTE usp_TempTableValue_GetAll";
            oResult = objSqlData.Select(sql);
            DataView dv= oResult.Data.DefaultView;
            dv.RowFilter = "TableOperation='rChallanTemp'";
            DataTable dt = dv.ToTable();
            if (dt.Rows.Count > 0)
            {
                result = Newtonsoft.Json.JsonConvert.DeserializeObject<List<rChallanViewModel>>(dt.Rows[0]["TableValue"].ToString());
                isFoundrChallan = result.FindAll(m => m.Chln == chln);
                decimal temp = 0;
                foreach (rChallanViewModel rc in isFoundrChallan)
                {
                    DataRow dr = dtPRT.NewRow();
                    dr["CmpIDX"] =rc.CmpIDX;
                    dr["Chln"] =rc.Chln;
                    dr["OrderNo"] =rc.OrderNo;
                    dr["BarCode"] =rc.BarCode;
                    dr["sBarCode"] =rc.sBarCode;
                    dr["Qty"] =rc.Qty;
                    dr["sQty"] =rc.sQty;
                    dr["CPU"] =rc.CPU;
                    dr["ACPU"] = rc.ACPU;
                    
                    dr["RPU"] =rc.RPU;
                    dr["BuyDT"] =rc.BuyDT==null?DateTime.Now:rc.BuyDT;
                    dr["EXPDT"] = rc.EXPDT == null ? DateTime.Now : rc.EXPDT;
                    dr["PrdComm"] =rc.PrdComm;
                    decimal.TryParse(rc.AddPrdComm.ToString(), out temp);
                    dr["AddPrdComm"] = temp;
                    decimal.TryParse(rc.bQty.ToString(), out temp);
                    dr["bQty"] = temp;
                    decimal.TryParse(rc.AddiCost.ToString(), out temp);
                    dr["AddiCost"] = temp;
                    decimal.TryParse(rc.ChlnTotal.ToString(), out temp);
                    dr["ChlnTotal"] = temp;

                    dr["SupRef"] = rc.SupRef;
                    dr["SupName"] = rc.SupName;
                    dr["GroupName"] = rc.GroupName;
                    dr["ItemDesc"] = rc.Prdname+"-"+rc.BTname+"-"+rc.SSName;
                    dtPRT.Rows.Add(dr);
                }
            }
            return dtPRT;
        }

        public DataTable GetByShopName(string ShopID)
        {
            string sql = "EXECUTE usp_ShopList_GetByShopID '" + ShopID + "'";
            oResult = objSqlData.Select(sql);
            return oResult.Data;        
        }

        public DataTable iChallan_GetByDCNO(string DCNO)
        {
            string sql = "EXECUTE usp_iChallan_GetByDCNO '" + DCNO + "'";
            oResult = objSqlData.Select(sql);
            return oResult.Data;
        }
        public DataTable iChallanTemp_GetByDCNO(string DCNO)
        {
            string sql = "EXECUTE usp_iChallanTemp_GetByDCNO '" + DCNO + "'";
            oResult = objSqlData.Select(sql);
            return oResult.Data;
        }
        public DataTable BuyRequisition_GetByRequisitionNo(string RequisitionNo)
        {
            string sql = "EXECUTE usp_BuyRequisition_GetByRequisitionNo '" + RequisitionNo + "'";
            oResult = objSqlData.Select(sql);
            return oResult.Data;
        }

        public DataTable BuyRequisitionTemp_GetByShopID(string ShopID)
        {
            string sql = "EXECUTE usp_BuyRequisitionTemp_GetByShopID '" + ShopID + "'";
            oResult = objSqlData.Select(sql);
            return oResult.Data;
        }

        public DataTable rChallanShop_GetByChlnShopID(string Chln)
        {
            string sql = "EXECUTE usp_rChallanShop_GetByChlnShopID '" + Chln + "'";
            oResult = objSqlData.Select(sql);
            return oResult.Data;
        }
        #endregion

        #region Stock Return / DML

        public DataTable StockReturn_GetByChln(string Chln)
        {
            string sql = "Select * from  StockReturn where Chln='" + Chln + "'";
            oResult = objSqlData.Select(sql);
            return oResult.Data;
        }

        public DataTable StockReturnTemp_GetList()
        {
            string sql = "Select * from  StockReturnTemp";
            oResult = objSqlData.Select(sql);
            return oResult.Data;
        }

        public DataTable StockDML_GetByChln(string Chln)
        {
            string sql = "usp_StockDML_GetByChln '" + Chln + "'";
            oResult = objSqlData.Select(sql);
            return oResult.Data;
        }

        public DataTable StockDMLTemp_GetList()
        {
            string sql = @" SELECT dbo.StockDMLTemp.*,ss.GroupName,ss.PrdName,ss.BTName, ss.SSName, ss.PrdName+'-'+ss.BTName+'-'+ss.SSName AS ItemDes
            FROM dbo.StockDMLTemp INNER JOIN dbo.StyleSize ss ON dbo.StockDMLTemp.BarCode = ss.Barcode";
            oResult = objSqlData.Select(sql);
            return oResult.Data;
        }

        public DataTable StockReturnShopByChln(string Chln, string IsTransfer)
        {
            string sql = "usp_StockReturnShop_GetByChln '" + Chln + "'," + IsTransfer;
            oResult = objSqlData.Select(sql);
            return oResult.Data;
        }
        public DataTable StockReturnShopTempByChln(string ShopId, string TransferToShop, string UserId)
        {
            string sql = @" SELECT srs.Barcode AS BarCode, srs.UserId,srs.ShopId,srs.TQty AS Qty, srs.CPU, 
                          srs.ProdcutDescription AS ItemDes,TransferTo, GETDATE() AS ReturnDt,'' AS Chln
                          FROM dbo.TempStockReturnShop srs where  ShopId='" + ShopId + "' AND srs.TransferTo='" + TransferToShop + "' and UserId='" + UserId + "'";
            oResult = objSqlData.Select(sql);
            return oResult.Data;
        }
        #endregion

        #region Promotion, BuyGet, Circular
        public DataTable BuyAndGet_GetByNo(string buyAndGetNo)
        {
            string sql = "usp_BuyAndGet_GetByNo '" + buyAndGetNo + "'";
            oResult = objSqlData.Select(sql);
            return oResult.Data;
        }

        public DataTable PackageSetupByPackageNo(string PackageNo)
        {
            string sql = "usp_Package_GetByPackageNo '" + PackageNo + "'";
            oResult = objSqlData.Select(sql);
            return oResult.Data;
        }

        public DataTable PackageIssueByPIssueNo(string PIssueNo)
        {
            string sql = "usp_PackageIssue_GetByPIssueNo '" + PIssueNo + "'";
            oResult = objSqlData.Select(sql);
            return oResult.Data;
        }

        public DataTable CircularDiscount_GetByCDNo(string CDNo)
        {
            string sql = "usp_CircularDiscount_GetByCDNo '" + CDNo + "'";
            oResult = objSqlData.Select(sql);
            return oResult.Data;
        }
        public DataTable rpt_PayLessByID(string PayLessNo)
        {
            string sql = "rpt_PayLessByID '" + PayLessNo + "'";
            oResult = objSqlData.Select(sql);
            return oResult.Data;
        }
        public DataTable CircularPriceChanged_GetByCPCNo(string CPCNo)
        {
            string sql = "usp_CircularPriceChanged_GetByCPCNo '" + CPCNo + "'";
            oResult = objSqlData.Select(sql);
            return oResult.Data;
        }

        #endregion

        #region Stock Report
        public DataTable rptSupWiseStockSummary(string SupID, string Type)
        {
            string sql = "rpt_SupWiseStockSummary '" + SupID + "','" + Type + "'";
            oResult = objSqlData.Select(sql);
            return oResult.Data;
        }
        public DataTable rptSupWiseStockSummaryShop(string ShopID, string SupID, string Type)
        {
            string sql = "rpt_SupWiseStockSummaryShop '" + ShopID + "','" + SupID + "'" + ",'" + Type + "'";
            oResult = objSqlData.Select(sql);
            return oResult.Data;
        }

        public DataTable rptSupStockPosition(string SupID, string Type)
        {
            string sql = "rpt_SupplierwiseStockPosition '" + SupID + "','" + Type + "'";
            oResult = objSqlData.Select(sql);
            return oResult.Data;
        }
        public DataTable rptSupStockPositionShop(string ShopID, string SupID, string Type)
        {
            string sql = "rpt_SupplierwiseStockPositionShop '" + ShopID + "','" + SupID + "'" + ",'" + Type + "'";
            oResult = objSqlData.Select(sql);
            return oResult.Data;
        }

        public DataTable rptGroupwiseDetailsStock(string SupID, string Type)
        {
            string sql = "rpt_GroupwiseDetailsStock '" + SupID + "','" + Type + "'";
            oResult = objSqlData.Select(sql);
            return oResult.Data;
        }
        public DataTable rptGroupwiseDetailsStockShop(string ShopID, string SupID, string Type)
        {
            string sql = "rpt_GroupwiseDetailsStockShop '" + ShopID + "','" + SupID + "'" + ",'" + Type + "'";
            oResult = objSqlData.Select(sql);
            return oResult.Data;
        }

        public DataTable rptPurchaseOrderByPO(string sDate, string eDate, string SupID)
        {
            string sql = "rpt_PurchaseOrderByPO '" + sDate + "','" + eDate + "','" + SupID + "'";
            oResult = objSqlData.Select(sql);
            return oResult.Data;
        }

        public DataTable rptPurchaseRecvByChln(string sDate, string eDate, string SupID, string Chln, string OrderNo)
        {
            string sql = "rpt_purchaseRecvByChln '" + sDate + "','" + eDate + "','" + SupID + "','" + Chln + "','" + OrderNo + "'";
            oResult = objSqlData.Select(sql);
            return oResult.Data;
        }

        public DataTable rptReportStockPeriodical(string FromDate, string ToDate, string shopId, string BTID, string groupId, string PrdId, string SSID, string supId, string balType)
        {
            var query = string.Format("SP_ReportStockPeriodical '{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}' ",
                FromDate, ToDate, shopId, BTID, groupId, PrdId, SSID, supId, balType);
            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }

        public DataTable rptReportBuyCentralStockPeriodical(string FromDate, string ToDate, string BTID, string groupId, string PrdId, string SSID, string supId, string balType)
        {
            var query = string.Format("rpt_BuyCentalPeriodicalData '{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}' ",
                FromDate, ToDate, BTID, groupId, PrdId, SSID, supId, balType);
            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }

        public DataTable rptShopDeliveryReport(string FromDate, string ToDate, string BTID, string groupId, string PrdId, string SSID, string supId, string DCNO, string Chln, string ShopID)
        {
            var query = string.Format("usp_rptShopDeliveryReport '{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}' ",
                FromDate, ToDate, BTID, groupId, PrdId, SSID, supId, DCNO, Chln, ShopID);
            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }

        public DataTable rptShopReceiveReport(string FromDate, string ToDate, string BTID, string groupId, string PrdId, string SSID, string supId, string ShopID)
        {
            var query = string.Format("usp_rptShopReceiveReport '{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}' ",
                FromDate, ToDate, BTID, groupId, PrdId, SSID, supId, ShopID);
            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }

        public DataTable rptReportShopTransferDetails(string FromDate, string ToDate, string ShopID, string TransferTo,string BTID, string groupId, string PrdId, string SSID, string supId)
        {
            var query = string.Format("SP_ReportShopTransferDetails '{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}' ",
                FromDate, ToDate, ShopID, TransferTo, BTID, groupId, PrdId, SSID, supId);
            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }
        public DataTable rptReportShopTransferReceiveDetails(string FromDate, string ToDate, string ShopID, string TransferTo, string BTID, string groupId, string PrdId, string SSID, string supId)
        {
            var query = string.Format("SP_ReportShopTransferReceiveDetails '{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}' ",
                FromDate, ToDate, ShopID, TransferTo, BTID, groupId, PrdId, SSID, supId);
            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }
        public DataTable rptReportReportDamageAndLost(string FromDate, string ToDate, string BTID, string groupId, string PrdId, string SSID, string supId)
        {
            var query = string.Format("SP_ReportDamageAndLost '{0}','{1}','{2}','{3}','{4}','{5}','{6}' ",
                FromDate, ToDate, BTID, groupId, PrdId, SSID, supId);
            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }
        public DataTable rptReportStockReturn(string FromDate, string ToDate, string BTID, string groupId, string PrdId, string SSID, string supId)
        {
            var query = string.Format("SP_ReportStockReturn '{0}','{1}','{2}','{3}','{4}','{5}','{6}' ",
                FromDate, ToDate, BTID, groupId, PrdId, SSID, supId);
            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }

        public DataTable rptReportShopRequistionDetails(string FromDate, string ToDate, string ShopID, string BTID, string groupId, string PrdId, string SSID, string supId)
        {
            var query = string.Format("SP_ReportShopRequistionDetails '{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}' ",
                FromDate, ToDate, ShopID, BTID, groupId, PrdId, SSID, supId);
            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }

        public DataTable rptReportCircularDiscount(string FromDate, string ToDate, string Status)
        {
            var query = string.Format("SP_ReportCircularDiscount '{0}','{1}','{2}'",
                FromDate, ToDate, Status);
            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }

        public DataTable rptReportPackage(string FromDate, string ToDate, string Status)
        {
            var query = string.Format("SP_ReportPackage '{0}','{1}','{2}'",
                FromDate, ToDate, Status);
            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }

        public DataTable rptReportCircularPriceChanged(string Status)
        {
            var query = string.Format("SP_ReportCircularPriceChanged '{0}'",Status);
            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }

        public DataTable rptReportPromotion(string FromDate, string ToDate, string Status)
        {
            var query = string.Format("SP_ReportPromotion '{0}','{1}','{2}'",
                FromDate, ToDate, Status);
            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }

        public DataTable rptReportPayLess(string FromDate, string ToDate, string Status)
        {
            var query = string.Format("SP_ReportPayLess '{0}','{1}','{2}'",
                FromDate, ToDate, Status);
            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }

        public DataTable GetPackageIssueReceivePIssueNo(string PIUsseNo)
        {
            var query = @"SELECT     Id, PIssueNo, PIssueRecvNo, PackageNo, ShopID, PQty, sPQty, balPQty, UserId, CreateDate, RecvUserId, RecvDate,
                        (SELECT TOP 1 PName FROM dbo.Package WHERE Package.PackageNo=PackageIssueDetail.PackageNo) PName,
                        (SELECT TOP 1 PackagePrice FROM dbo.Package WHERE Package.PackageNo=PackageIssueDetail.PackageNo) PackagePrice,
                        (SELECT TOP 1 StartDate FROM dbo.Package WHERE Package.PackageNo=PackageIssueDetail.PackageNo) StartDate,
                        (SELECT TOP 1 EndDate FROM dbo.Package WHERE Package.PackageNo=PackageIssueDetail.PackageNo) EndDate
                        FROM         PackageIssueDetail
                        WHERE PIssueNo='" + PIUsseNo + "'";

            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }

        public DataTable PackageIssueReportDateRangeShopID(string FromDate, string ToDate, string ShopID)
        {
            var query = ("SP_ReportPackageIssue '" + FromDate + "','" + ToDate + "','" + ShopID + "'");
            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }
        
        #endregion

        #region Sales Report

        public DataTable rptDailySalesReport(string monthFromDate, string monthToDate, string yearFromDate, string YearToDate)
        {
            string  query = string.Format("SP_Report_DailySalesReport '{0}','{1}','{2}','{3}' ", monthFromDate, monthToDate, yearFromDate, YearToDate);
            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }
        public DataTable rptSalesShopSupItem(string FromDate, string ToDate, string shopId, string BTID, string groupId,
            string PrdId, string SSID, string supId)
        {
            var query = string.Format("SP_Report_ShopItemWiseSalesReport '{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}' ",
                FromDate, ToDate, shopId, BTID, groupId, PrdId, SSID, supId);
            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }
        public DataTable rptSalesItemWise(string FromDate, string ToDate, string shopId, string BTID, string groupId, string PrdId, string SSID, string supId)
        {
            var query = string.Format("SP_Report_ItemWiseSalesReport '{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}' ",
                      FromDate, ToDate, shopId, BTID, groupId, PrdId, SSID, supId);
            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }
        public DataTable rptSalesStockReport(string FromDate, string ToDate, string shopId, string BTID, string groupId, string PrdId, string SSID, string supId)
        {
            var query = string.Format("SP_Report_SalesStockReport '{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}' ",
                FromDate, ToDate, shopId, BTID, groupId, PrdId, SSID, supId);

            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }
        public DataTable rptSalesFromStockPercent(string FromDate, string ToDate, string shopId, string BTID, string groupId, string PrdId, string SSID, string supId)
        {
            var query = string.Format("SP_Report_SalesFromStockPercent '{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}' ",
                  FromDate, ToDate, shopId, BTID, groupId, PrdId, SSID, supId);
            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }

        public DataTable rptSalesSupplierGP(string FromDate, string ToDate, string shopId, string BTID, string groupId, string PrdId, string SSID, string supId)
        {
            var query = string.Format("SP_Report_SupplierWIseGP '{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}' ",
                  FromDate, ToDate, shopId, BTID, groupId, PrdId, SSID, supId);
            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }
        public DataTable rptSalesSupplierSalesPercent(string FromDate, string ToDate, string shopId, string BTID, string groupId, string PrdId, string SSID, string supId)
        {
            var query = string.Format("SP_Report_SupplierSalesContribution '{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}' ",
                  FromDate, ToDate, shopId, BTID, groupId, PrdId, SSID, supId);
            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }

        public DataTable rptSalesInvoiceWiseSalesSummary(string FromDate, string ToDate, string shopId, string BTID, string groupId, string PrdId, string SSID, string supId)
        {
            var query = string.Format("SP_ReportSalesInvoiceWiseSummary '{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}' ",
                   FromDate, ToDate, shopId, BTID, groupId, PrdId, SSID, supId);
            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }
        public DataTable rptSalesInvoiceWiseSalesDetails(string FromDate, string ToDate, string shopId, string BTID, string groupId, string PrdId, string SSID, string supId)
        {
            var query = string.Format("SP_ReportSalesInvoiceWiseDetails '{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}' ",
                   FromDate, ToDate, shopId, BTID, groupId, PrdId, SSID, supId);
            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }

        public DataTable rptSalesGroupWise(string FromDate, string ToDate, string shopId, string BTID, string groupId, string PrdId, string SSID, string supId)
        {
            var query = string.Format("SP_Report_GroupWiseSalesReport '{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}' ",
                  FromDate, ToDate, shopId, BTID, groupId, PrdId, SSID, supId);
            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }
        public DataTable rptSalesCasierSummaryReport(string FromDate, string ToDate, string shopId, string BTID, string groupId, string PrdId, string SSID, string supId)
        {
            var query = string.Format("SP_Report_SalesCasierSummaryReport '{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}' ",
                  FromDate, ToDate, shopId, BTID, groupId, PrdId, SSID, supId);
            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }

        public DataTable rptReportSalesCounterSummaryReport(string FromDate, string ToDate, string shopId, string CounterID)
        {
            var query = string.Format("SP_ReportSalesCounterSummaryReport '{0}','{1}','{2}','{3}'",
                  FromDate, ToDate, shopId, CounterID);
            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }

        public DataTable rptSalesByInvoiceNo(string InvoiceNo)
        {
            var query = string.Format("SP_SalesInvoice '{0}'", InvoiceNo);
            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }

        public DataTable rptCreditCollection(string ID)
        {
            var query = string.Format("rpt_CreditCollectionByID '{0}'", ID);
            DataTable dt = new SQLDAL().Select(query).Data;
            return dt;
        }

        #endregion

    }
}