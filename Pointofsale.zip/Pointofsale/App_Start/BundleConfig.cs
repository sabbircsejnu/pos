﻿using System.Web.Optimization;

namespace RetailMaster.POS.Web
{
    public class BundleConfig
    {
        // For more information on Bundling, visit http://go.microsoft.com/fwlink/?LinkId=254725
        public static void RegisterBundles(BundleCollection bundles)
        {
            System.Web.Optimization.BundleTable.EnableOptimizations = false;

            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jquery-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryui").Include(
                        "~/Scripts/jquery-ui-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                        "~/Scripts/jquery.unobtrusive*",
                        "~/Scripts/jquery.validate*"));

            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at http://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                        "~/Scripts/modernizr-*"));

            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
                        "~/Scripts/bootstrap.js"));

            bundles.Add(new ScriptBundle("~/bundles/chosen").Include(
            "~/Scripts/chosen.jquery.js"));

            bundles.Add(new ScriptBundle("~/bundles/datatables").Include(
                        "~/Scripts/jquery.dataTables.js"));


            bundles.Add(new ScriptBundle("~/bundles/spin").Include(
                        "~/Scripts/spin.min.js"));

            bundles.Add(new ScriptBundle("~/bundles/morrisJS").Include(
                       "~/Scripts/raphael-min.js",
                       "~/content/morrisJS/morris.min.js"));

           // bundles.Add(new StyleBundle("~/Content/css").Include("~/Content/site.css"));

            bundles.Add(new StyleBundle("~/content/themes/base/css").Include(
                                    "~/content/themes/base/accordion.css",
                                    "~/content/themes/base/all.css",
                                    "~/content/themes/base/autocomplete.css",
                                    "~/content/themes/base/base.css",
                                    "~/content/themes/base/button.css",
                                    "~/content/themes/base/core.css",
                                    "~/content/themes/base/datepicker.css",
                                    "~/content/themes/base/dialog.css",
                                    "~/content/themes/base/draggable.css",
                                    "~/content/themes/base/menu.css",
                                    "~/content/themes/base/progressbar.css",
                                    "~/content/themes/base/resizablecss",
                                    "~/content/themes/base/selectable.css",
                                    "~/content/themes/base/selectmenu.css",
                                    "~/content/themes/base/slider.css",
                                    "~/content/themes/base/sortable.css",
                                    "~/content/themes/base/spinner.css",
                                    "~/content/themes/base/tabs.css",
                                    "~/content/themes/base/theme.css",
                                    "~/content/themes/base/tooltip.css"));
            bundles.Add(new StyleBundle("~/content/css").Include("~/content/bootstrap.css", 
                "~/content/sb-admin.css", 
                "~/content/font-awesome/css/font-awesome.css",
                "~/content/jquery-ui.css",
                "~/content/jquery-ui.structure.css",
                "~/content/chosen.css",
                "~/content/jquery.dataTables.css",
                "~/content/morrisJS/morris.css",
                "~/content/custom.css"));

        }
    }
}