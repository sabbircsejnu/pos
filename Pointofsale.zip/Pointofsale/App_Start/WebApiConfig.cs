﻿namespace RetailMaster.POS.Web.App_Start
{
    public static class WebApiConfig
    {
        
    }
}