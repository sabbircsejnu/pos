﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailMasterDesktop.POS.Reports.Class
{
    public class SP_ReportShopTransferDetails
    {
        public string CmpIDX { get; set; }
        public string Chln { get; set; }
        public string RcvChln { get; set; }
        public string BarCode { get; set; }
        public string sBarcode { get; set; }
        public string SupID { get; set; }
        public decimal CPU { get; set; }
        public decimal RPU { get; set; }
        public decimal Qty { get; set; }
        public decimal RcvQty { get; set; }
        public DateTime ReturnDt { get; set; }
        public DateTime RecevieDt { get; set; }
        public string UserID { get; set; }
        public string ShopID { get; set; }
        public string TransferTo { get; set; }
        public string SSName { get; set; }
        public string PrdName { get; set; }
        public string BTName { get; set; }
        public string GroupName { get; set; }
        public string SupName { get; set; }
        public string ShopName { get; set; }
    }
}
