﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RetailMaster.POS.Web.ReportsClass
{
    public class rptClassPackageIssueReport
    {
        public int Id { get; set; }
        public string PIssueNo { get; set; }
        public string PIssueRecvNo { get; set; }
        public string PackageNo { get; set; }
        public string ShopID { get; set; }
        public decimal PQty { get; set; }
        public decimal sPQty { get; set; }
        public decimal balPQty { get; set; }
        public string UserId { get; set; }
        public DateTime CreateDate { get; set; }
        public string RecvUserId { get; set; }
        public DateTime RecvDate { get; set; }
        public string PName { get; set; }
        public decimal PackagePrice { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
}