﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RetailMaster.POS.Web.ReportsClass
{
    public class rpt_BuyCentalPeriodicalData
    {
        public string BarCode { get; set; }
        public string sBarCode { get; set; }
        public string ItemDesc { get; set; }
        public decimal openingQty { get; set; }
        public decimal closingQty { get; set; }
        public decimal dmlQty { get; set; }
        public decimal recvQty { get; set; }
        public decimal returnCSQty { get; set; }
        public decimal returnShopQty { get; set; }
        public decimal deliveryQty { get; set; }
        public string SupID { get; set; }
        public string SupName { get; set; }
    }
}