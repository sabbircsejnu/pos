﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RetailMaster.POS.Web.ReportsClass
{
    public class PurchaseOrderByPO
    {
        public string Chln { get; set; }
        public string SupId { get; set; }
        public string SupName { get; set; }
        public string GroupName { get; set; }
        public string ItemDes { get; set; }
        public decimal CPU { get; set; }
        public DateTime BuyDT { get; set; }
        public DateTime EXPDT { get; set; }
        public decimal UserID { get; set; }
        public decimal BarCode { get; set; }
        public decimal Qty { get; set; }
        public decimal sQty { get; set; }
    }
}