﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RetailMaster.POS.Web.ReportsClass
{
    public class GroupwiseDetailsStock
    {
        public string Barcode { get; set; }
        public string GroupName { get; set; }
        public string PrdName { get; set; }
        public string BTName { get; set; }
        public string SSName { get; set; }
        public string SupID { get; set; }
        public string SupName { get; set; }
        public decimal CPU { get; set; }
        public decimal RPU { get; set; }
        public decimal Qty { get; set; }
        public decimal sreturn { get; set; }
        public decimal sQty { get; set; }
        public decimal dmlqty { get; set; }
        public decimal balQty { get; set; }
    }
}