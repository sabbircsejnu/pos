﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RetailMaster.POS.Web.ReportsClass
{
    public class rptClassPackage
    {
        public int Id { get; set; }
        public string PackageNo { get; set; }
        public string PName { get; set; }
        public decimal PQty { get; set; }
        public decimal balPQty { get; set; }
        public decimal PackagePrice { get; set; }
        public string BarCode { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public decimal Qty { get; set; }
        public decimal CPU { get; set; }
        public decimal RPU { get; set; }
        public decimal PckRPU { get; set; }
        public decimal VATPrcen { get; set; }
        public string UserId { get; set; }
        public DateTime CreateDate { get; set; }
        public string IsActive { get; set; }
        public string ItemInfo { get; set; }

    }
}