﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RetailMaster.POS.Web.ReportsClass
{
    public class rptClassPayLessReport
    {
        public decimal PayLessId { get; set; }
        public string PayLessNo { get; set; }
        public string PayLessName { get; set; }
        public string SupID { get; set; }
        public string BarCode { get; set; }
        public string sBarCode { get; set; }
        public decimal CPU { get; set; }
        public decimal RPU { get; set; }
        public decimal CngRPU { get; set; }
        public decimal DiscPrecn { get; set; }
        public decimal DiscAmnt { get; set; }
        public decimal Qty { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Status { get; set; }
        public string UserId { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime UpdateDate { get; set; }
        public string ItemInfo { get; set; }
    }
}