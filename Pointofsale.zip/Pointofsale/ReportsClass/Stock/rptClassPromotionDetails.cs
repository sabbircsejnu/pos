﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RetailMaster.POS.Web.ReportsClass
{
    public class rptClassPromotionDetails
    {
        public decimal BuyGetId { get; set; }
        public string BuyGetNo { get; set; }
        public string BuyGetName { get; set; }
        public string SupID { get; set; }
        public string BarCode { get; set; }
        public string sBarCode { get; set; }
        public decimal CPU { get; set; }
        public decimal RPU { get; set; }
        public decimal Qty { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string IsFree { get; set; }
        public string UserId { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime UpdateDate { get; set; }
        public string ItemInfo { get; set; }
    }
}