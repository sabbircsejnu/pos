﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RetailMaster.POS.Web.ReportsClass
{
    public class rptClassCircularDiscount
    {
        public int Id { get; set; }
        public string CDNo { get; set; }
        public string CDName { get; set; }
        public string Description { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime ExpireDate { get; set; }
        public string UserId { get; set; }
        public DateTime CreateDate { get; set; }
        public string BarCode { get; set; }
        public decimal RPU { get; set; }
        public decimal DRPU { get; set; }
        public decimal DiscountPrcnt { get; set; }
        public decimal DiscountAmount { get; set; }
        public string ItemInfo { get; set; }
    }
}