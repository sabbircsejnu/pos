﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailMasterDesktop.POS.Reports.Class
{
    public class SP_ReportShopReceiveDetails
    {
        public string CmpIDX { get; set; }
        public string Chln { get; set; }
        public string OrderNo { get; set; }
        public string sBarCode { get; set; }
        public string BarCode { get; set; }
        public decimal CPU { get; set; }
        public decimal ACPU { get; set; }
        public decimal RPU { get; set; }
        public decimal VPU { get; set; }
        public decimal VPP { get; set; }
        public decimal DiscPrcnt { get; set; }
        public decimal VATPrcnt { get; set; }
        public decimal PrdComm { get; set; }
        public decimal Qty { get; set; }
        public decimal bQty { get; set; }
        public decimal sQty { get; set; }
        public decimal cSqty { get; set; }
        public decimal rQty { get; set; }
        public decimal dmlqty { get; set; }
        public DateTime BuyDT { get; set; }
        public string ShopID { get; set; }
        public decimal ChlnTotal { get; set; }
        public int SupRef { get; set; }
        public int UserID { get; set; }
        public int ItemDesc { get; set; }
        public int SupName { get; set; }
        public int ShopName { get; set; }

    }
}
