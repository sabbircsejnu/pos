﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailMasterDesktop.POS.Reports.Class
{
    public class SP_Report_SalesCasierSummaryReport
    {
        public string UserId { get; set; }
        public decimal CashAmount { get; set; }
        public decimal CardAmnt { get; set; }
        public decimal NetAmnt { get; set; }
        public decimal RetAmnt { get; set; }
        public decimal NetPayable { get; set; }
        public decimal ReturnByExchange { get; set; }
        public decimal DiscountAmount { get; set; }
        public decimal VatAmount { get; set; }
    }
}
