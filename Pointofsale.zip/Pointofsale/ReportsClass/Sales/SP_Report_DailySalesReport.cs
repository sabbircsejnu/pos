﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailMasterDesktop.POS.Reports.Class
{
    public class SP_Report_DailySalesReport
    {
        public string ShopID { get; set; }
        public string ShopName { get; set; }
        public decimal TodasySales { get; set; }
        public decimal UpToThisMonth { get; set; }
        public decimal UpToThisYear { get; set; }
    }
}
