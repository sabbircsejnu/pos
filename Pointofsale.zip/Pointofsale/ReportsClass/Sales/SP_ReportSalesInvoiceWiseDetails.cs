﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailMasterDesktop.POS.Reports.Class
{
    public class SP_ReportSalesInvoiceWiseDetails
    {
        public string ShopID { get; set; }
        public string ShopName { get; set; }
        public string SupID { get; set; }
        public string SupName { get; set; }
        public string BarCode { get; set; }
        public string sBarCode { get; set; }
        public string GroupName { get; set; }
        public string BTName { get; set; }
        public string PrdName { get; set; }
        public DateTime SaleDT { get; set; }
        public decimal RPU { get; set; }
        public decimal CPU { get; set; }
        public decimal SQty { get; set; }
        public decimal rQty { get; set; }
        public decimal rAmt { get; set; }
        public decimal rVat { get; set; }
        public decimal rDisc { get; set; }
        public decimal cInvoice { get; set; }
        public decimal PayType { get; set; }
        public decimal TotalCost { get; set; }
        public decimal TotalAmt { get; set; }
        public decimal DiscPrcnt { get; set; }
        public decimal DiscAmtPrd { get; set; }
        public decimal DiscAmt { get; set; }
        public decimal VAT { get; set; }
        public decimal VATPrd { get; set; }
        public decimal NetAmt { get; set; }
        public decimal NetRAmt { get; set; }
        public string PrdSlNo { get; set; }
        public decimal CshAmt { get; set; }
        public decimal CrdAmt { get; set; }
        public string Salesman { get; set; }
        public string Invoice { get; set; }
        public string CardName { get; set; }
        public string CardNo { get; set; }
        public string CounterID { get; set; }
        public string PrvCusID { get; set; }
        public string CusName { get; set; }
        public string Posted { get; set; }
        public decimal VATPrcnt { get; set; }
        public string Returned { get; set; }
        public string ReturnedType { get; set; }
        public DateTime ReturnedDt { get; set; }
        public string Flag { get; set; }
        public string IsCircularDiscount { get; set; }
        public string InvoiceGroups { get; set; }
        public decimal CreditAmt { get; set; }
        public decimal TotalCreditAmt { get; set; }
    }
}
