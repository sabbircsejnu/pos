﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RetailMaster.POS.Web.ReportsClass
{
    public class rptCreditCollection
    {
        public int ID { get; set; }
        public string PrvCusID { get; set; }
        public string CusLedgerNo { get; set; }
        public string ShopID { get; set; }
        public string ShopName { get; set; }
        public decimal Debit { get; set; }
        public decimal Credit { get; set; }
        public string PayMode { get; set; }
        public string BankName { get; set; }
        public string Check_NO { get; set; }
        public decimal CardAmount { get; set; }
        public decimal CashAmount { get; set; }
        public string Reason { get; set; }
        public string InvoiceNo { get; set; }
        public string CreateBy { get; set; }
        public DateTime CreateDate { get; set; }
        public string UpdateBy { get; set; }
        public DateTime UpdateDate { get; set; }
        public string CusName { get; set; }
        public string Address { get; set; }
        public string Phone { get; set; }
        public decimal NewCredit { get; set; }
    }
}