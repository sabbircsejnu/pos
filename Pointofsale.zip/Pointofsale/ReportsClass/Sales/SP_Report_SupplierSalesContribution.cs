﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailMasterDesktop.POS.Reports.Class
{
    public class SP_Report_SupplierSalesContribution
    {
        public string SupID { get; set; }
        public string SupName { get; set; }
        public decimal sQty { get; set; }
        public decimal TotalRPU { get; set; }
        public decimal ContributionPercent { get; set; }
    }
}
