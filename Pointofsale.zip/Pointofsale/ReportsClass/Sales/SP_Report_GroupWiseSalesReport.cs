﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailMasterDesktop.POS.Reports.Class
{
    public class SP_Report_GroupWiseSalesReport
    {
        public string ShopID { get; set; }
        public string ShopName { get; set; }
        public string SupID { get; set; }
        public string SupName { get; set; }
        public string BarCode { get; set; }
        public string sBarCode { get; set; }
        public string GroupName { get; set; }
        public string BTName { get; set; }
        public string PrdName { get; set; }
        public decimal Sqty { get; set; }
        public decimal RPU { get; set; }
        public decimal CPU { get; set; }
        public decimal TotalCPU { get; set; }
        public decimal TotalRPU { get; set; }
        public decimal DiscAmtPrd { get; set; }
        public decimal rDisc { get; set; }
    }
}
