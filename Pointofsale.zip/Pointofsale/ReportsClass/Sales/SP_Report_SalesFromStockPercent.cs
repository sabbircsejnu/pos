﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailMasterDesktop.POS.Reports.Class
{
    public class SP_Report_SalesFromStockPercent
    {
        public string BarCode { get; set; }
        public string SupID { get; set; }
        public string SupName { get; set; }
        public string GroupName { get; set; }
        public string PrdName { get; set; }
        public string BTName { get; set; }
        public decimal Qty { get; set; }
        public decimal sQty { get; set; }
        public string ShopID { get; set; }
        public string ShopName { get; set; }
    }
}
