// Tree view

_treeViewSelectedColor="#E0E0E0";
_treeViewUnselectedColor="white";

_listWidgetItemWidth=94;
_listWidgetItemHeight=24;
_listWidgetItemSpacing=5;