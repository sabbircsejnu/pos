﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using RetailMaster.POS.Service;
using RetailMaster.POS.Web.BLL;
using RetailMaster.POS.Web.Models;
using RetailMaster.POS.Web.Reports.CircularDiscount;
using RetailMaster.POS.Web.Reports.CircularPriceChanged;
using RetailMaster.POS.Web.Reports.Package;
using RetailMaster.POS.Web.Reports.PackageIssue;
using RetailMaster.POS.Web.Reports.PackageIssueReceive;
using RetailMaster.POS.Web.Reports.PayLess;
using RetailMaster.POS.Web.Reports.Promotion;
using RetailMaster.POS.Web.Reports.Setup;
using RetailMaster.POS.Web.Reports.ShopDeliveryReceive;
using RetailMaster.POS.Web.Reports.ShopRequisition;
using RetailMaster.POS.Web.Reports.ShopTransfer;
using RetailMaster.POS.Web.Reports.StockReturn;
using RetailMaster.POS.Web.ViewModels;
using RetailMaster.POS.Web.Reports.DamageLost;

namespace RetailMaster.POS.Web.Reports.Viewer
{
    public partial class ShopDeliveryReceiveViewer : System.Web.UI.Page
    {
        protected void Page_Init(object sender, EventArgs e)
        {
            #region shopid
            if (Request.QueryString["ShopID"] != null)
            {
                String LoginShopID = GetLogedInInfo().ShopID;
                // if shop user try to see the cs report
                string ShopID = Request.QueryString["ShopID"].ToString();
                if (LoginShopID != "9999" && LoginShopID != ShopID)
                {
                    return;
                }
            }
            #endregion

            try
            {
                if (Request.QueryString["ReportName"] == null)
                    return;

                DataTable dtShopStatic = new DataTable();

                switch (Request.QueryString["ReportName"])
                {
                    #region Shop Delivery Report
                    case "ShopDeliveryReport":

                        if (Request.QueryString["ShopID"].ToString() == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null || Request.QueryString["BTID"].ToString() == null || Request.QueryString["GroupID"].ToString() == null || Request.QueryString["PrdID"].ToString() == null || Request.QueryString["SSID"].ToString() == null || Request.QueryString["SupID"].ToString() == null || Request.QueryString["DCNO"].ToString() == null || Request.QueryString["Chln"].ToString() == null)
                            return;

                        DataTable dtShopStaticSDRD = new ReportDbSource().GetByShopName("9999");
                        rptShopDeliveryReport rptSDRD = new rptShopDeliveryReport();
                        DataTable dtSDRD = new ReportDbSource().rptShopDeliveryReport(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["BTID"].ToString(), Request.QueryString["GroupID"].ToString(), Request.QueryString["PrdID"].ToString(), Request.QueryString["SSID"].ToString(), Request.QueryString["SupID"].ToString(), Request.QueryString["DCNO"].ToString(), Request.QueryString["Chln"].ToString(), Request.QueryString["ShopID"].ToString());
                        rptSDRD.SetDataSource(dtSDRD);

                        rptSDRD.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                        rptSDRD.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());

                        if (dtShopStaticSDRD.Rows.Count > 0)
                        {
                            rptSDRD.SetParameterValue("shopname", dtShopStaticSDRD.Rows[0]["ShopName"].ToString());
                            rptSDRD.SetParameterValue("address", dtShopStaticSDRD.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rptSDRD.SetParameterValue("shopname", "");
                            rptSDRD.SetParameterValue("address", "");
                        }
                        rptViewer.ReportSource = rptSDRD;
                        rptViewer.DataBind();
                        break;
                    #endregion

                    #region Shop Delivery Summary Report
                    case "ShopDeliveryReportSummary":

                        if (Request.QueryString["ShopID"].ToString() == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null || Request.QueryString["BTID"].ToString() == null || Request.QueryString["GroupID"].ToString() == null || Request.QueryString["PrdID"].ToString() == null || Request.QueryString["SSID"].ToString() == null || Request.QueryString["SupID"].ToString() == null || Request.QueryString["DCNO"].ToString() == null || Request.QueryString["Chln"].ToString() == null)
                            return;

                        DataTable dtShopStaticSDRDS = new ReportDbSource().GetByShopName("9999");
                        rptShopDeliverySummaryReport rptSDRDS = new rptShopDeliverySummaryReport();
                        DataTable dtSDRDS = new ReportDbSource().rptShopDeliveryReport(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["BTID"].ToString(), Request.QueryString["GroupID"].ToString(), Request.QueryString["PrdID"].ToString(), Request.QueryString["SSID"].ToString(), Request.QueryString["SupID"].ToString(), Request.QueryString["DCNO"].ToString(), Request.QueryString["Chln"].ToString(), Request.QueryString["ShopID"].ToString());
                        rptSDRDS.SetDataSource(dtSDRDS);

                        rptSDRDS.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                        rptSDRDS.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());

                        if (dtShopStaticSDRDS.Rows.Count > 0)
                        {
                            rptSDRDS.SetParameterValue("shopname", dtShopStaticSDRDS.Rows[0]["ShopName"].ToString());
                            rptSDRDS.SetParameterValue("address", dtShopStaticSDRDS.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rptSDRDS.SetParameterValue("shopname", "");
                            rptSDRDS.SetParameterValue("address", "");
                        }
                        rptViewer.ReportSource = rptSDRDS;
                        rptViewer.DataBind();
                        break;
                    #endregion

                    #region Shop Receive Details Report
                    case "ShopReceiveDetails":

                        if (Request.QueryString["ShopID"].ToString() == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null || Request.QueryString["BTID"].ToString() == null || Request.QueryString["GroupID"].ToString() == null || Request.QueryString["PrdID"].ToString() == null || Request.QueryString["SSID"].ToString() == null || Request.QueryString["SupID"].ToString() == null || Request.QueryString["ShopID"].ToString() == null)
                            return;

                        if (Request.QueryString["ShopID"].ToString() == "All")
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");
                        else
                        {
                            dtShopStatic = new ReportDbSource().GetByShopName(Request.QueryString["ShopID"].ToString());
                        }

                        rptReceiveDetails rptSRRD = new rptReceiveDetails();
                        DataTable dtSRRD = new ReportDbSource().rptShopReceiveReport(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["BTID"].ToString(), Request.QueryString["GroupID"].ToString(), Request.QueryString["PrdID"].ToString(), Request.QueryString["SSID"].ToString(), Request.QueryString["SupID"].ToString(), Request.QueryString["ShopID"].ToString());
                        rptSRRD.SetDataSource(dtSRRD);

                        rptSRRD.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                        rptSRRD.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());

                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptSRRD.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptSRRD.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rptSRRD.SetParameterValue("shopname", "");
                            rptSRRD.SetParameterValue("address", "");
                        }
                        rptViewer.ReportSource = rptSRRD;
                        rptViewer.DataBind();
                        break;
                    #endregion

                    #region Shop Receive Summary Report
                    case "ShopReceiveSummary":

                        if (Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null || Request.QueryString["BTID"].ToString() == null || Request.QueryString["GroupID"].ToString() == null || Request.QueryString["PrdID"].ToString() == null || Request.QueryString["SSID"].ToString() == null || Request.QueryString["SupID"].ToString() == null || Request.QueryString["ShopID"].ToString() == null)
                            return;

                        if (Request.QueryString["ShopID"].ToString() == "All")
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");
                        else
                        {
                            dtShopStatic = new ReportDbSource().GetByShopName(Request.QueryString["ShopID"].ToString());
                        }

                        rptReceiveSummary rptSRRS = new rptReceiveSummary();
                        DataTable dSRRS = new ReportDbSource().rptShopReceiveReport(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["BTID"].ToString(), Request.QueryString["GroupID"].ToString(), Request.QueryString["PrdID"].ToString(), Request.QueryString["SSID"].ToString(), Request.QueryString["SupID"].ToString(), Request.QueryString["ShopID"].ToString());
                        rptSRRS.SetDataSource(dSRRS);

                        rptSRRS.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                        rptSRRS.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());

                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptSRRS.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptSRRS.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rptSRRS.SetParameterValue("shopname", "");
                            rptSRRS.SetParameterValue("address", "");
                        }
                        rptViewer.ReportSource = rptSRRS;
                        rptViewer.DataBind();
                        break;
                    #endregion

                    #region Shop Transfer Details Report
                    case "ShopTransferDetails":

                        if (Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null || Request.QueryString["BTID"].ToString() == null || Request.QueryString["GroupID"].ToString() == null || Request.QueryString["PrdID"].ToString() == null || Request.QueryString["SSID"].ToString() == null || Request.QueryString["SupID"].ToString() == null || Request.QueryString["ShopID"].ToString() == null)
                            return;

                        if (Request.QueryString["ShopID"].ToString() == "All")
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");
                        else
                        {
                            dtShopStatic = new ReportDbSource().GetByShopName(Request.QueryString["ShopID"].ToString());
                        }

                        rptTransferDetails rptSTDR = new rptTransferDetails();
                        DataTable dtSTDR = new ReportDbSource().rptReportShopTransferDetails(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["ShopID"].ToString(), Request.QueryString["TransferTo"].ToString(), Request.QueryString["BTID"].ToString(), Request.QueryString["GroupID"].ToString(), Request.QueryString["PrdID"].ToString(), Request.QueryString["SSID"].ToString(), Request.QueryString["SupID"].ToString());
                        rptSTDR.SetDataSource(dtSTDR);

                        rptSTDR.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                        rptSTDR.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());

                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptSTDR.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptSTDR.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rptSTDR.SetParameterValue("shopname", "");
                            rptSTDR.SetParameterValue("address", "");
                        }
                        rptViewer.ReportSource = rptSTDR;
                        rptViewer.DataBind();
                        break;
                    #endregion

                    #region Shop Transfer Summary Report
                    case "ShopTransferSummary":

                        if (Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null || Request.QueryString["BTID"].ToString() == null || Request.QueryString["GroupID"].ToString() == null || Request.QueryString["PrdID"].ToString() == null || Request.QueryString["SSID"].ToString() == null || Request.QueryString["SupID"].ToString() == null || Request.QueryString["ShopID"].ToString() == null)
                            return;

                        if (Request.QueryString["ShopID"].ToString() == "All")
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");
                        else
                        {
                            dtShopStatic = new ReportDbSource().GetByShopName(Request.QueryString["ShopID"].ToString());
                        }

                        rptTransferSummary rptSTSR = new rptTransferSummary();
                        DataTable dtSTSR = new ReportDbSource().rptReportShopTransferDetails(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["ShopID"].ToString(), Request.QueryString["TransferTo"].ToString(), Request.QueryString["BTID"].ToString(), Request.QueryString["GroupID"].ToString(), Request.QueryString["PrdID"].ToString(), Request.QueryString["SSID"].ToString(), Request.QueryString["SupID"].ToString());
                        rptSTSR.SetDataSource(dtSTSR);

                        rptSTSR.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                        rptSTSR.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());

                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptSTSR.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptSTSR.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rptSTSR.SetParameterValue("shopname", "");
                            rptSTSR.SetParameterValue("address", "");
                        }
                        rptViewer.ReportSource = rptSTSR;
                        rptViewer.DataBind();
                        break;
                    #endregion

                    #region Shop Transfer Receive Details Report
                    case "ShopTransferReceiveDetails":

                        if (Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null || Request.QueryString["BTID"].ToString() == null || Request.QueryString["GroupID"].ToString() == null || Request.QueryString["PrdID"].ToString() == null || Request.QueryString["SSID"].ToString() == null || Request.QueryString["SupID"].ToString() == null || Request.QueryString["ShopID"].ToString() == null)
                            return;

                        if (Request.QueryString["ShopID"].ToString() == "All")
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");
                        else
                        {
                            dtShopStatic = new ReportDbSource().GetByShopName(Request.QueryString["ShopID"].ToString());
                        }

                        rptTransferReceiveDetails rptSRDR = new rptTransferReceiveDetails();
                        DataTable dtSRDR = new ReportDbSource().rptReportShopTransferReceiveDetails(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["ShopID"].ToString(), Request.QueryString["TransferTo"].ToString(), Request.QueryString["BTID"].ToString(), Request.QueryString["GroupID"].ToString(), Request.QueryString["PrdID"].ToString(), Request.QueryString["SSID"].ToString(), Request.QueryString["SupID"].ToString());
                        rptSRDR.SetDataSource(dtSRDR);

                        rptSRDR.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                        rptSRDR.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());

                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptSRDR.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptSRDR.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rptSRDR.SetParameterValue("shopname", "");
                            rptSRDR.SetParameterValue("address", "");
                        }
                        rptViewer.ReportSource = rptSRDR;
                        rptViewer.DataBind();
                        break;
                    #endregion

                    #region Shop Transfer Receive Summary Report
                    case "ShopTransferReceiveSummary":

                        if (Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null || Request.QueryString["BTID"].ToString() == null || Request.QueryString["GroupID"].ToString() == null || Request.QueryString["PrdID"].ToString() == null || Request.QueryString["SSID"].ToString() == null || Request.QueryString["SupID"].ToString() == null || Request.QueryString["ShopID"].ToString() == null)
                            return;

                        if (Request.QueryString["ShopID"].ToString() == "All")
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");
                        else
                        {
                            dtShopStatic = new ReportDbSource().GetByShopName(Request.QueryString["ShopID"].ToString());
                        }

                        rptTransferReceiveSummary rptSRSR = new rptTransferReceiveSummary();
                        DataTable dtSRSR = new ReportDbSource().rptReportShopTransferReceiveDetails(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["ShopID"].ToString(), Request.QueryString["TransferTo"].ToString(), Request.QueryString["BTID"].ToString(), Request.QueryString["GroupID"].ToString(), Request.QueryString["PrdID"].ToString(), Request.QueryString["SSID"].ToString(), Request.QueryString["SupID"].ToString());
                        rptSRSR.SetDataSource(dtSRSR);

                        rptSRSR.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                        rptSRSR.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());

                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptSRSR.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptSRSR.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rptSRSR.SetParameterValue("shopname", "");
                            rptSRSR.SetParameterValue("address", "");
                        }
                        rptViewer.ReportSource = rptSRSR;
                        rptViewer.DataBind();
                        break;
                    #endregion

                    #region Damage and Lost Details Report
                    case "DamageLostDetails":

                        if (Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null || Request.QueryString["BTID"].ToString() == null || Request.QueryString["GroupID"].ToString() == null || Request.QueryString["PrdID"].ToString() == null || Request.QueryString["SSID"].ToString() == null || Request.QueryString["SupID"].ToString() == null)
                            return;

                        dtShopStatic = new ReportDbSource().GetByShopName("9999");

                        rptDamageLostDetails rptDLD = new rptDamageLostDetails();
                        DataTable dtDLD = new ReportDbSource().rptReportReportDamageAndLost(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["BTID"].ToString(), Request.QueryString["GroupID"].ToString(), Request.QueryString["PrdID"].ToString(), Request.QueryString["SSID"].ToString(), Request.QueryString["SupID"].ToString());
                        rptDLD.SetDataSource(dtDLD);

                        rptDLD.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                        rptDLD.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());

                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptDLD.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptDLD.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rptDLD.SetParameterValue("shopname", "");
                            rptDLD.SetParameterValue("address", "");
                        }
                        rptViewer.ReportSource = rptDLD;
                        rptViewer.DataBind();
                        break;
                    #endregion

                    #region Damage and Lost Summary Report
                    case "DamageLostSummary":

                        if (Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null || Request.QueryString["BTID"].ToString() == null || Request.QueryString["GroupID"].ToString() == null || Request.QueryString["PrdID"].ToString() == null || Request.QueryString["SSID"].ToString() == null || Request.QueryString["SupID"].ToString() == null)
                            return;

                        dtShopStatic = new ReportDbSource().GetByShopName("9999");

                        rptDamageLostSummary rptDLS = new rptDamageLostSummary();
                        DataTable dtDLS = new ReportDbSource().rptReportReportDamageAndLost(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["BTID"].ToString(), Request.QueryString["GroupID"].ToString(), Request.QueryString["PrdID"].ToString(), Request.QueryString["SSID"].ToString(), Request.QueryString["SupID"].ToString());
                        rptDLS.SetDataSource(dtDLS);

                        rptDLS.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                        rptDLS.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());

                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptDLS.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptDLS.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rptDLS.SetParameterValue("shopname", "");
                            rptDLS.SetParameterValue("address", "");
                        }
                        rptViewer.ReportSource = rptDLS;
                        rptViewer.DataBind();
                        break;
                    #endregion

                    #region ReturntoSupplier Details Report
                    case "ReturntoSupplierDetails":

                        if (Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null || Request.QueryString["BTID"].ToString() == null || Request.QueryString["GroupID"].ToString() == null || Request.QueryString["PrdID"].ToString() == null || Request.QueryString["SSID"].ToString() == null || Request.QueryString["SupID"].ToString() == null)
                            return;

                        dtShopStatic = new ReportDbSource().GetByShopName("9999");

                        rptStockReturnSupplier rptSRSD = new rptStockReturnSupplier();
                        DataTable dtSRSD = new ReportDbSource().rptReportStockReturn(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["BTID"].ToString(), Request.QueryString["GroupID"].ToString(), Request.QueryString["PrdID"].ToString(), Request.QueryString["SSID"].ToString(), Request.QueryString["SupID"].ToString());
                        rptSRSD.SetDataSource(dtSRSD);

                        rptSRSD.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                        rptSRSD.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());

                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptSRSD.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptSRSD.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rptSRSD.SetParameterValue("shopname", "");
                            rptSRSD.SetParameterValue("address", "");
                        }
                        rptViewer.ReportSource = rptSRSD;
                        rptViewer.DataBind();
                        break;
                    #endregion

                    #region ReturntoSupplier Summary Report
                    case "ReturntoSupplierSummary":

                        if (Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null || Request.QueryString["BTID"].ToString() == null || Request.QueryString["GroupID"].ToString() == null || Request.QueryString["PrdID"].ToString() == null || Request.QueryString["SSID"].ToString() == null || Request.QueryString["SupID"].ToString() == null)
                            return;

                        dtShopStatic = new ReportDbSource().GetByShopName("9999");

                        rptStockReturnSupplierSummary rptSRSS = new rptStockReturnSupplierSummary();
                        DataTable dtSRSS = new ReportDbSource().rptReportStockReturn(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["BTID"].ToString(), Request.QueryString["GroupID"].ToString(), Request.QueryString["PrdID"].ToString(), Request.QueryString["SSID"].ToString(), Request.QueryString["SupID"].ToString());
                        rptSRSS.SetDataSource(dtSRSS);

                        rptSRSS.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                        rptSRSS.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());

                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptSRSS.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptSRSS.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rptSRSS.SetParameterValue("shopname", "");
                            rptSRSS.SetParameterValue("address", "");
                        }
                        rptViewer.ReportSource = rptSRSS;
                        rptViewer.DataBind();
                        break;
                    #endregion

                    #region Shop Requisition Details Report
                    case "ShopRequisitionDetails":

                        if (Request.QueryString["ShopID"].ToString() == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null || Request.QueryString["BTID"].ToString() == null || Request.QueryString["GroupID"].ToString() == null || Request.QueryString["PrdID"].ToString() == null || Request.QueryString["SSID"].ToString() == null || Request.QueryString["SupID"].ToString() == null || Request.QueryString["ShopID"].ToString() == null)
                            return;

                        if (Request.QueryString["ShopID"].ToString() == "All")
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");
                        else
                        {
                            dtShopStatic = new ReportDbSource().GetByShopName(Request.QueryString["ShopID"].ToString());
                        }

                        rptRequistionDetails rptSReqDR = new rptRequistionDetails();
                        DataTable dtSReqDR = new ReportDbSource().rptReportShopRequistionDetails(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["ShopID"].ToString(), Request.QueryString["BTID"].ToString(), Request.QueryString["GroupID"].ToString(), Request.QueryString["PrdID"].ToString(), Request.QueryString["SSID"].ToString(), Request.QueryString["SupID"].ToString());
                        rptSReqDR.SetDataSource(dtSReqDR);

                        rptSReqDR.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                        rptSReqDR.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());

                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptSReqDR.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptSReqDR.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rptSReqDR.SetParameterValue("shopname", "");
                            rptSReqDR.SetParameterValue("address", "");
                        }
                        rptViewer.ReportSource = rptSReqDR;
                        rptViewer.DataBind();
                        break;
                    #endregion

                    #region Shop Requisition Summary Report
                    case "ShopRequisitionSummary":

                        if (Request.QueryString["ShopID"].ToString() == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null || Request.QueryString["BTID"].ToString() == null || Request.QueryString["GroupID"].ToString() == null || Request.QueryString["PrdID"].ToString() == null || Request.QueryString["SSID"].ToString() == null || Request.QueryString["SupID"].ToString() == null || Request.QueryString["ShopID"].ToString() == null)
                            return;

                        if (Request.QueryString["ShopID"].ToString() == "All")
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");
                        else
                        {
                            dtShopStatic = new ReportDbSource().GetByShopName(Request.QueryString["ShopID"].ToString());
                        }

                        rptRequistionSummary rptSReqSR = new rptRequistionSummary();
                        DataTable dtSReqSR = new ReportDbSource().rptReportShopRequistionDetails(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["ShopID"].ToString(), Request.QueryString["BTID"].ToString(), Request.QueryString["GroupID"].ToString(), Request.QueryString["PrdID"].ToString(), Request.QueryString["SSID"].ToString(), Request.QueryString["SupID"].ToString());
                        rptSReqSR.SetDataSource(dtSReqSR);

                        rptSReqSR.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                        rptSReqSR.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());

                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptSReqSR.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptSReqSR.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rptSReqSR.SetParameterValue("shopname", "");
                            rptSReqSR.SetParameterValue("address", "");
                        }
                        rptViewer.ReportSource = rptSReqSR;
                        rptViewer.DataBind();
                        break;
                    #endregion

                    #region Circular Discount Details Report
                    case "CircularDiscountDetails":

                        if (Request.QueryString["Status"].ToString() == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        dtShopStatic = new ReportDbSource().GetByShopName(GetLogedInInfo().ShopID);

                        rptCircularDiscountDetails rptCDD = new rptCircularDiscountDetails();
                        DataTable dtCDD = new ReportDbSource().rptReportCircularDiscount(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["Status"].ToString());
                        rptCDD.SetDataSource(dtCDD);

                        rptCDD.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                        rptCDD.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());

                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptCDD.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptCDD.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rptCDD.SetParameterValue("shopname", "");
                            rptCDD.SetParameterValue("address", "");
                        }
                        rptViewer.ReportSource = rptCDD;
                        rptViewer.DataBind();
                        break;
                    #endregion

                    #region Circular Discount Summary Report
                    case "CircularDiscountSummary":

                        if (Request.QueryString["Status"].ToString() == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        dtShopStatic = new ReportDbSource().GetByShopName(GetLogedInInfo().ShopID);

                        rptCircularDiscountSummary rptCDS = new rptCircularDiscountSummary();
                        DataTable dtCDS = new ReportDbSource().rptReportCircularDiscount(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["Status"].ToString());
                        rptCDS.SetDataSource(dtCDS);

                        rptCDS.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                        rptCDS.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());

                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptCDS.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptCDS.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rptCDS.SetParameterValue("shopname", "");
                            rptCDS.SetParameterValue("address", "");
                        }
                        rptViewer.ReportSource = rptCDS;
                        rptViewer.DataBind();
                        break;
                    #endregion

                    #region Package Details Report
                    case "PackageDetails":

                        if (Request.QueryString["Status"].ToString() == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        dtShopStatic = new ReportDbSource().GetByShopName(GetLogedInInfo().ShopID);

                        rptPackageDetails rptPD = new rptPackageDetails();
                        DataTable dtPD = new ReportDbSource().rptReportPackage(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["Status"].ToString());
                        rptPD.SetDataSource(dtPD);

                        rptPD.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                        rptPD.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());

                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptPD.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptPD.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rptPD.SetParameterValue("shopname", "");
                            rptPD.SetParameterValue("address", "");
                        }
                        rptViewer.ReportSource = rptPD;
                        rptViewer.DataBind();
                        break;
                    #endregion

                    #region Package Summary Report
                    case "PackageSummary":

                        if (Request.QueryString["Status"].ToString() == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        dtShopStatic = new ReportDbSource().GetByShopName(GetLogedInInfo().ShopID);

                        rptPackageSummary rptPS = new rptPackageSummary();
                        DataTable dtPS = new ReportDbSource().rptReportPackage(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["Status"].ToString());
                        rptPS.SetDataSource(dtPS);

                        rptPS.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                        rptPS.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());

                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptPS.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptPS.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rptPS.SetParameterValue("shopname", "");
                            rptPS.SetParameterValue("address", "");
                        }
                        rptViewer.ReportSource = rptPS;
                        rptViewer.DataBind();
                        break;
                    #endregion

                    #region Circular Price Changed Details Report
                    case "CPCDetails":

                        if (Request.QueryString["Status"].ToString() == null)
                            return;

                        dtShopStatic = new ReportDbSource().GetByShopName(GetLogedInInfo().ShopID);

                        rptCircularPriceChangedDetails rptCPCD = new rptCircularPriceChangedDetails();
                        DataTable dtCPCD = new ReportDbSource().rptReportCircularPriceChanged(Request.QueryString["Status"].ToString());
                        rptCPCD.SetDataSource(dtCPCD);

                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptCPCD.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptCPCD.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rptCPCD.SetParameterValue("shopname", "");
                            rptCPCD.SetParameterValue("address", "");
                        }
                        rptViewer.ReportSource = rptCPCD;
                        rptViewer.DataBind();
                        break;
                    #endregion

                    #region Circular Price Changed Details Report
                    case "CPCSummary":

                        if (Request.QueryString["Status"].ToString() == null)
                            return;

                        dtShopStatic = new ReportDbSource().GetByShopName(GetLogedInInfo().ShopID);

                        rptCircularPriceChangedSummary rptCPCS = new rptCircularPriceChangedSummary();
                        DataTable dtCPCS = new ReportDbSource().rptReportCircularPriceChanged(Request.QueryString["Status"].ToString());
                        rptCPCS.SetDataSource(dtCPCS);

                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptCPCS.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptCPCS.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rptCPCS.SetParameterValue("shopname", "");
                            rptCPCS.SetParameterValue("address", "");
                        }
                        rptViewer.ReportSource = rptCPCS;
                        rptViewer.DataBind();
                        break;
                    #endregion

                    #region Promotion Details Report
                    case "PromotionDetails":

                        if (Request.QueryString["Status"].ToString() == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        dtShopStatic = new ReportDbSource().GetByShopName(GetLogedInInfo().ShopID);

                        rptPromotionDetails rptProD = new rptPromotionDetails();
                        DataTable dtProD = new ReportDbSource().rptReportPromotion(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["Status"].ToString());
                        rptProD.SetDataSource(dtProD);

                        rptProD.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                        rptProD.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());

                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptProD.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptProD.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rptProD.SetParameterValue("shopname", "");
                            rptProD.SetParameterValue("address", "");
                        }
                        rptViewer.ReportSource = rptProD;
                        rptViewer.DataBind();
                        break;
                    #endregion

                    #region Promotion Summary Report
                    case "PromotionSummary":

                        if (Request.QueryString["Status"].ToString() == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        dtShopStatic = new ReportDbSource().GetByShopName(GetLogedInInfo().ShopID);

                        rptPromotionSummary rptProS = new rptPromotionSummary();
                        DataTable dtProS = new ReportDbSource().rptReportPromotion(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["Status"].ToString());
                        rptProS.SetDataSource(dtProS);

                        rptProS.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                        rptProS.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());

                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptProS.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptProS.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rptProS.SetParameterValue("shopname", "");
                            rptProS.SetParameterValue("address", "");
                        }
                        rptViewer.ReportSource = rptProS;
                        rptViewer.DataBind();
                        break;
                    #endregion

                    #region Pay Less Details Report
                    case "PayLessDetails":

                        if (Request.QueryString["Status"].ToString() == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        dtShopStatic = new ReportDbSource().GetByShopName(GetLogedInInfo().ShopID);

                        rptPayLessDetails rptPLD = new rptPayLessDetails();
                        DataTable dtPLD = new ReportDbSource().rptReportPayLess(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["Status"].ToString());
                        rptPLD.SetDataSource(dtPLD);

                        rptPLD.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                        rptPLD.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());

                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptPLD.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptPLD.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rptPLD.SetParameterValue("shopname", "");
                            rptPLD.SetParameterValue("address", "");
                        }
                        rptViewer.ReportSource = rptPLD;
                        rptViewer.DataBind();
                        break;
                    #endregion

                    #region Pay Less Summary Report
                    case "PayLessSummary":

                        if (Request.QueryString["Status"].ToString() == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        dtShopStatic = new ReportDbSource().GetByShopName(GetLogedInInfo().ShopID);

                        rptPayLessSummary rptPLS = new rptPayLessSummary();
                        DataTable dtPLS = new ReportDbSource().rptReportPayLess(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["Status"].ToString());
                        rptPLS.SetDataSource(dtPLS);

                        rptPLS.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                        rptPLS.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());

                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptPLS.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptPLS.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rptPLS.SetParameterValue("shopname", "");
                            rptPLS.SetParameterValue("address", "");
                        }
                        rptViewer.ReportSource = rptPLS;
                        rptViewer.DataBind();
                        break;
                    #endregion

                    #region Package Issue Details Report
                    case "PackageIssueDetails":

                        if (Request.QueryString["ShopID"].ToString() == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        dtShopStatic = new ReportDbSource().GetByShopName(GetLogedInInfo().ShopID);

                        rptPackageIssueDetails rptPID = new rptPackageIssueDetails();
                        DataTable dtPID = new ReportDbSource().PackageIssueReportDateRangeShopID(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["ShopID"].ToString());
                        rptPID.SetDataSource(dtPID);

                        rptPID.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                        rptPID.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());

                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptPID.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptPID.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rptPID.SetParameterValue("shopname", "");
                            rptPID.SetParameterValue("address", "");
                        }

                        rptViewer.ReportSource = rptPID;
                        rptViewer.DataBind();
                        break;
                    #endregion

                    #region Package Issue Summary Report
                    case "PackageIssueSummary":

                        if (Request.QueryString["ShopID"].ToString() == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        dtShopStatic = new ReportDbSource().GetByShopName(GetLogedInInfo().ShopID);

                        rptPackageIssueSummary rptPIS = new rptPackageIssueSummary();
                        DataTable dtPIS = new ReportDbSource().PackageIssueReportDateRangeShopID(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["ShopID"].ToString());
                        rptPIS.SetDataSource(dtPIS);

                        rptPIS.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                        rptPIS.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());

                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptPIS.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptPIS.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rptPIS.SetParameterValue("shopname", "");
                            rptPIS.SetParameterValue("address", "");
                        }

                        rptViewer.ReportSource = rptPIS;
                        rptViewer.DataBind();
                        break;
                    #endregion

                    #region Package Issue Receive Details Report
                    case "PackageIssueReceiveDetails":

                        if (Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;
                       
                        string ShopIDD = GetLogedInInfo().ShopID;
                        dtShopStatic = new ReportDbSource().GetByShopName(ShopIDD);

                        rptPackageIssueReceiveDetails rptPIRD = new rptPackageIssueReceiveDetails();
                        DataTable dtPIRD = new ReportDbSource().PackageIssueReportDateRangeShopID(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), ShopIDD);
                        rptPIRD.SetDataSource(dtPIRD);

                        rptPIRD.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                        rptPIRD.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());

                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptPIRD.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptPIRD.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rptPIRD.SetParameterValue("shopname", "");
                            rptPIRD.SetParameterValue("address", "");
                        }

                        rptViewer.ReportSource = rptPIRD;
                        rptViewer.DataBind();
                        break;
                    #endregion

                    #region Package Issue Receive Summary Report
                    case "PackageIssueReceiveSummary":

                        if (Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;
                        string ShopID = GetLogedInInfo().ShopID;
                        dtShopStatic = new ReportDbSource().GetByShopName(ShopID);

                        rptPackageIssueReceiveSummary rptPIRS = new rptPackageIssueReceiveSummary();
                        DataTable dtPIRS = new ReportDbSource().PackageIssueReportDateRangeShopID(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), ShopID);
                        rptPIRS.SetDataSource(dtPIRS);

                        rptPIRS.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                        rptPIRS.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());

                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptPIRS.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptPIRS.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rptPIRS.SetParameterValue("shopname", "");
                            rptPIRS.SetParameterValue("address", "");
                        }

                        rptViewer.ReportSource = rptPIRS;
                        rptViewer.DataBind();
                        break;
                    #endregion

                }
            }
            catch (Exception ex)
            {

            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        private LogedInInfo GetLogedInInfo()
        {
            LogedInInfo info = new LogedInInfo();
            if (Request.Cookies["POSLogedInInfo"] != null)
            {
                var value = Request.Cookies["POSLogedInInfo"].Value;
                info = Newtonsoft.Json.JsonConvert.DeserializeObject<LogedInInfo>(value) as LogedInInfo;
            }
            return info;
        }
    }
}