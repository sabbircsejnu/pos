﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using RetailMaster.POS.Service;
using RetailMaster.POS.Web.BLL;
using RetailMaster.POS.Web.Models;
using RetailMaster.POS.Web.Reports.Setup;
using RetailMaster.POS.Web.Reports.Stock;
using RetailMaster.POS.Web.ViewModels;

namespace RetailMaster.POS.Web.Reports.Viewer
{
    public partial class StockReportViewer : System.Web.UI.Page
    {
        private static string strdvCriteria = string.Empty;
        private static DataTable dtShopStatic;
        private static DataTable dtSupWiseStockSummary;
        private static DataTable dtSupWiseStockSummaryShop;
        private static DataTable dtSupStockPosition;
        private static DataTable dtSupStockPositionShop;
        private static DataTable dtGroupwiseDetailsStock;
        private static DataTable dtGroupwiseDetailsStockShop;
        private static DataTable dtPurchaseOrderByPO;
        private static DataTable dtPurchaseOrderSummary;
        private static DataTable dtPurchaseRecvByChln;
        private static DataTable dtPurchaseRecvByOrder;
        private static DataTable dtPRSupplierSummary;
        private static DataTable dtPeriodicalStock;
        private static DataTable dtPeriodicalStockBuycentral;
        private static DataTable dtShopDeliveryReport;
        private static DataTable dtShopDeliverySummaryReport;

        protected void Page_Init(object sender, EventArgs e)
        {
            if (Request.QueryString["ShopID"] != null)
            {
                String LoginShopID = GetLogedInInfo().ShopID;
                // if shop user try to see the cs report
                string ShopID = Request.QueryString["ShopID"].ToString();
                if (LoginShopID != "9999" && LoginShopID != ShopID)
                {
                    return;
                }
            }
          

            if (!IsPostBack)
            {
                BindReport();
            }
            else
            {
                BindReportWhenPostBack();
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        private void BindReport()
        {
            try
            {
                if (Request.QueryString["ReportName"] == null)
                    return;
                switch (Request.QueryString["ReportName"])
                {
                    #region SupWiseStockSummary
                    case "SupWiseStockSummary":

                        if (Request.QueryString["SupID"] == null || Request.QueryString["balQtyType"] == null || Request.QueryString["ShopID"] == null)
                            return;
                        dtShopStatic = new ReportDbSource().GetByShopName(Request.QueryString["ShopID"].ToString());
                        if (Request.QueryString["ShopID"].ToString() == "9999") // from buyCental
                        {
                            rptSupWiseStockSummary rptSupWiseStock = new rptSupWiseStockSummary();
                            DataTable dtSupWiseStock =
                                new ReportDbSource().rptSupWiseStockSummary(Request.QueryString["SupID"].ToString(),
                                    Request.QueryString["balQtyType"].ToString());
                            dtSupWiseStockSummary = dtSupWiseStock;
                            rptSupWiseStock.SetDataSource(dtSupWiseStock);

                            if (dtShopStatic.Rows.Count > 0)
                            {
                                rptSupWiseStock.SetParameterValue("printedby", Page.User.Identity.Name);
                                rptSupWiseStock.SetParameterValue("reportName", "Supplier Wise Stock Summary");
                                rptSupWiseStock.SetParameterValue("shopname",
                                    dtShopStatic.Rows[0]["ShopName"].ToString());
                                rptSupWiseStock.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            }
                            else
                            {
                                rptSupWiseStock.SetParameterValue("printedby", Page.User.Identity.Name);
                                rptSupWiseStock.SetParameterValue("reportName", "Supplier Wise Stock Summary");
                                rptSupWiseStock.SetParameterValue("shopname", "");
                                rptSupWiseStock.SetParameterValue("address", "");
                            }
                            rptViewer.ReportSource = rptSupWiseStock;
                            rptViewer.DataBind();
                        }
                        else  // others shop
                        {
                            rptSupWiseStockSummaryShop rptSupWiseStock = new rptSupWiseStockSummaryShop();
                            DataTable dtSupWiseStock =
                                new ReportDbSource().rptSupWiseStockSummaryShop(Request.QueryString["ShopID"].ToString(), Request.QueryString["SupID"].ToString(),
                                    Request.QueryString["balQtyType"].ToString());
                            dtSupWiseStockSummaryShop = dtSupWiseStock;
                            rptSupWiseStock.SetDataSource(dtSupWiseStock);

                            if (dtShopStatic.Rows.Count > 0)
                            {
                                rptSupWiseStock.SetParameterValue("printedby", Page.User.Identity.Name);
                                rptSupWiseStock.SetParameterValue("reportName", "Supplier Wise Stock Summary");
                                rptSupWiseStock.SetParameterValue("shopname",
                                    dtShopStatic.Rows[0]["ShopName"].ToString());
                                rptSupWiseStock.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            }
                            else
                            {
                                rptSupWiseStock.SetParameterValue("printedby", Page.User.Identity.Name);
                                rptSupWiseStock.SetParameterValue("reportName", "Supplier Wise Stock Summary");
                                rptSupWiseStock.SetParameterValue("shopname", "");
                                rptSupWiseStock.SetParameterValue("address", "");
                            }
                            rptViewer.ReportSource = rptSupWiseStock;
                            rptViewer.DataBind();
                        }
                        break;
                    #endregion

                    #region SupStockPosition
                    case "SupStockPosition":

                        if (Request.QueryString["SupID"] == null || Request.QueryString["balQtyType"] == null || Request.QueryString["ShopID"] == null)
                            return;

                        dtShopStatic = new ReportDbSource().GetByShopName(Request.QueryString["ShopID"].ToString());
                        if (Request.QueryString["ShopID"].ToString() == "9999") // from buyCental
                        {
                            rptSupStockPosition rptSupWiseStock = new rptSupStockPosition();
                            DataTable dtSupWiseStock =
                                new ReportDbSource().rptSupStockPosition(Request.QueryString["SupID"].ToString(),
                                    Request.QueryString["balQtyType"].ToString());
                            dtSupStockPosition = dtSupWiseStock;
                            rptSupWiseStock.SetDataSource(dtSupWiseStock);

                            if (dtShopStatic.Rows.Count > 0)
                            {
                                rptSupWiseStock.SetParameterValue("printedby", Page.User.Identity.Name);
                                rptSupWiseStock.SetParameterValue("reportName", "Supplier Wise Stock Summary");
                                rptSupWiseStock.SetParameterValue("shopname",
                                    dtShopStatic.Rows[0]["ShopName"].ToString());
                                rptSupWiseStock.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            }
                            else
                            {
                                rptSupWiseStock.SetParameterValue("printedby", Page.User.Identity.Name);
                                rptSupWiseStock.SetParameterValue("reportName", "Supplier Wise Stock Summary");
                                rptSupWiseStock.SetParameterValue("shopname", "");
                                rptSupWiseStock.SetParameterValue("address", "");
                            }
                            rptViewer.ReportSource = rptSupWiseStock;
                            rptViewer.DataBind();
                        }
                        else  // others shop
                        {
                            rptSupStockPositionShop rptSupWiseStock = new rptSupStockPositionShop();
                            DataTable dtSupWiseStock =
                                new ReportDbSource().rptSupStockPositionShop(Request.QueryString["ShopID"].ToString(), Request.QueryString["SupID"].ToString(),
                                    Request.QueryString["balQtyType"].ToString());
                            dtSupStockPositionShop = dtSupWiseStock;
                            rptSupWiseStock.SetDataSource(dtSupWiseStock);

                            if (dtShopStatic.Rows.Count > 0)
                            {
                                rptSupWiseStock.SetParameterValue("printedby", Page.User.Identity.Name);
                                rptSupWiseStock.SetParameterValue("reportName", "Supplier Wise Stock Summary");
                                rptSupWiseStock.SetParameterValue("shopname",
                                    dtShopStatic.Rows[0]["ShopName"].ToString());
                                rptSupWiseStock.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            }
                            else
                            {
                                rptSupWiseStock.SetParameterValue("printedby", Page.User.Identity.Name);
                                rptSupWiseStock.SetParameterValue("reportName", "Supplier Wise Stock Summary");
                                rptSupWiseStock.SetParameterValue("shopname", "");
                                rptSupWiseStock.SetParameterValue("address", "");
                            }
                            rptViewer.ReportSource = rptSupWiseStock;
                            rptViewer.DataBind();
                        }
                        break;
                    #endregion

                    #region Group wise Details Stock
                    case "GroupWiseDetailsDiffSup":
                        if (Request.QueryString["SupID"] == null || Request.QueryString["balQtyType"] == null || Request.QueryString["ShopID"] == null)
                            return;

                        dtShopStatic = new ReportDbSource().GetByShopName(Request.QueryString["ShopID"].ToString());
                        if (Request.QueryString["ShopID"].ToString() == "9999") // from buyCental
                        {
                            rptGroupwiseDetailsStock rpt = new rptGroupwiseDetailsStock();
                            DataTable dt = new ReportDbSource().rptGroupwiseDetailsStock(Request.QueryString["SupID"].ToString(), Request.QueryString["balQtyType"].ToString());
                            dtGroupwiseDetailsStock = dt;
                            rpt.SetDataSource(dt);

                            if (dtShopStatic.Rows.Count > 0)
                            {
                                rpt.SetParameterValue("printedby", Page.User.Identity.Name);
                                rpt.SetParameterValue("reportName", "Supplier Wise Stock Summary");
                                rpt.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                                rpt.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            }
                            else
                            {
                                rpt.SetParameterValue("printedby", Page.User.Identity.Name);
                                rpt.SetParameterValue("reportName", "Supplier Wise Stock Summary");
                                rpt.SetParameterValue("shopname", "");
                                rpt.SetParameterValue("address", "");
                            }
                            rptViewer.ReportSource = rpt;
                            rptViewer.DataBind();
                        }
                        else  // others shop
                        {
                            rptGroupwiseDetailsStockShop rpt = new rptGroupwiseDetailsStockShop();
                            DataTable dt = new ReportDbSource().rptGroupwiseDetailsStockShop(Request.QueryString["ShopID"].ToString(), Request.QueryString["SupID"].ToString(), Request.QueryString["balQtyType"].ToString());
                            dtGroupwiseDetailsStockShop = dt;
                            rpt.SetDataSource(dt);

                            if (dtShopStatic.Rows.Count > 0)
                            {
                                rpt.SetParameterValue("printedby", Page.User.Identity.Name);
                                rpt.SetParameterValue("reportName", "Supplier Wise Stock Summary");
                                rpt.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                                rpt.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            }
                            else
                            {
                                rpt.SetParameterValue("printedby", Page.User.Identity.Name);
                                rpt.SetParameterValue("reportName", "Supplier Wise Stock Summary");
                                rpt.SetParameterValue("shopname", "");
                                rpt.SetParameterValue("address", "");
                            }
                            rptViewer.ReportSource = rpt;
                            rptViewer.DataBind();
                        }
                        break;
                    #endregion

                    #region PurchaseOrder By PO
                    case "POStockReceived":
                        if (Request.QueryString["SupID"] == null || Request.QueryString["ShopID"] == null)
                            return;

                        dtShopStatic = new ReportDbSource().GetByShopName(Request.QueryString["ShopID"].ToString());
                        if (Request.QueryString["ShopID"].ToString() == "9999") // from buyCental
                        {
                            rptPurchaseOrderByPO rpt = new rptPurchaseOrderByPO();
                            DataTable dt = new ReportDbSource().rptPurchaseOrderByPO(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["SupID"].ToString());
                            dtPurchaseOrderByPO = dt;
                            rpt.SetDataSource(dt);

                            rpt.SetParameterValue("from", "From: ");
                            rpt.SetParameterValue("fromDate", Request.QueryString["sDate"].ToString());
                            rpt.SetParameterValue("toDate", Request.QueryString["eDate"].ToString());

                            if (dtShopStatic.Rows.Count > 0)
                            {
                                rpt.SetParameterValue("printedby", Page.User.Identity.Name);
                                rpt.SetParameterValue("reportName", "Purchase Order By PO Number");
                                rpt.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                                rpt.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            }
                            else
                            {
                                rpt.SetParameterValue("printedby", Page.User.Identity.Name);
                                rpt.SetParameterValue("reportName", "Purchase Order By PO Number");
                                rpt.SetParameterValue("shopname", "");
                                rpt.SetParameterValue("address", "");
                            }
                            rptViewer.ReportSource = rpt;
                            rptViewer.DataBind();
                        }
                        break;
                    #endregion
                   
                    #region PurchaseOrder Summary
                    case "POPendingSummary":
                        if (Request.QueryString["SupID"] == null || Request.QueryString["ShopID"] == null)
                            return;

                        dtShopStatic = new ReportDbSource().GetByShopName(Request.QueryString["ShopID"].ToString());
                        if (Request.QueryString["ShopID"].ToString() == "9999") // from buyCental
                        {
                            rptPurchaseOrderByPOSummary rpt = new rptPurchaseOrderByPOSummary();
                            DataTable dt = new ReportDbSource().rptPurchaseOrderByPO(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["SupID"].ToString());
                            dtPurchaseOrderSummary = dt;
                            rpt.SetDataSource(dt);

                            rpt.SetParameterValue("from", "From: ");
                            rpt.SetParameterValue("fromDate", Request.QueryString["sDate"].ToString());
                            rpt.SetParameterValue("toDate", Request.QueryString["eDate"].ToString());

                            if (dtShopStatic.Rows.Count > 0)
                            {
                                rpt.SetParameterValue("printedby", Page.User.Identity.Name);
                                rpt.SetParameterValue("reportName", "Purchase Order Summary");
                                rpt.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                                rpt.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            }
                            else
                            {
                                rpt.SetParameterValue("printedby", Page.User.Identity.Name);
                                rpt.SetParameterValue("reportName", "Supplier Wise Stock Summary");
                                rpt.SetParameterValue("shopname", "");
                                rpt.SetParameterValue("address", "");
                            }
                            rptViewer.ReportSource = rpt;
                            rptViewer.DataBind();
                        }
                        break;
                    #endregion

                    #region PR Challan NO
                    case "PRChallanNO":
                        if (Request.QueryString["SupID"] == null || Request.QueryString["ShopID"] == null || Request.QueryString["Chln"].ToString() == null || Request.QueryString["OrderNo"].ToString() == null)
                            return;

                        dtShopStatic = new ReportDbSource().GetByShopName(Request.QueryString["ShopID"].ToString());
                        if (Request.QueryString["ShopID"].ToString() == "9999") // from buyCental
                        {
                            rptPRChallanNO rpt = new rptPRChallanNO();
                            DataTable dt = new ReportDbSource().rptPurchaseRecvByChln(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["SupID"].ToString(), Request.QueryString["Chln"].ToString(), Request.QueryString["OrderNo"].ToString());
                            dtPurchaseRecvByChln = dt;
                            rpt.SetDataSource(dt);

                            rpt.SetParameterValue("from", "From: ");
                            rpt.SetParameterValue("fromDate", Request.QueryString["sDate"].ToString());
                            rpt.SetParameterValue("toDate", Request.QueryString["eDate"].ToString());

                            if (dtShopStatic.Rows.Count > 0)
                            {
                                rpt.SetParameterValue("printedby", Page.User.Identity.Name);
                                rpt.SetParameterValue("reportName", "Purchase Receive by Challan Number");
                                rpt.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                                rpt.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            }
                            else
                            {
                                rpt.SetParameterValue("printedby", Page.User.Identity.Name);
                                rpt.SetParameterValue("reportName", "Purchase Receive by Challan Number");
                                rpt.SetParameterValue("shopname", "");
                                rpt.SetParameterValue("address", "");
                            }
                            rptViewer.ReportSource = rpt;
                            rptViewer.DataBind();
                        }
                        break;
                    #endregion

                    #region PR Order NO
                    case "PROrderNo":
                        if (Request.QueryString["SupID"] == null || Request.QueryString["ShopID"] == null || Request.QueryString["Chln"].ToString() == null || Request.QueryString["OrderNo"].ToString() == null)
                            return;

                        dtShopStatic = new ReportDbSource().GetByShopName(Request.QueryString["ShopID"].ToString());
                        if (Request.QueryString["ShopID"].ToString() == "9999") // from buyCental
                        {
                            rptPRChallanNO rpt = new rptPRChallanNO();
                            DataTable dt = new ReportDbSource().rptPurchaseRecvByChln(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["SupID"].ToString(), Request.QueryString["Chln"].ToString(), Request.QueryString["OrderNo"].ToString());
                            dtPurchaseRecvByOrder = dt;
                            rpt.SetDataSource(dt);

                            rpt.SetParameterValue("from", "From: ");
                            rpt.SetParameterValue("fromDate", Request.QueryString["sDate"].ToString());
                            rpt.SetParameterValue("toDate", Request.QueryString["eDate"].ToString());

                            if (dtShopStatic.Rows.Count > 0)
                            {
                                rpt.SetParameterValue("printedby", Page.User.Identity.Name);
                                rpt.SetParameterValue("reportName", "Purchase Receive by Order Number");
                                rpt.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                                rpt.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            }
                            else
                            {
                                rpt.SetParameterValue("printedby", Page.User.Identity.Name);
                                rpt.SetParameterValue("reportName", "Purchase Receive by Order Number");
                                rpt.SetParameterValue("shopname", "");
                                rpt.SetParameterValue("address", "");
                            }
                            rptViewer.ReportSource = rpt;
                            rptViewer.DataBind();
                        }
                        break;
                    #endregion

                    #region PR Supplier Summary
                    case "PRSupplierSummary":
                        if (Request.QueryString["SupID"] == null || Request.QueryString["ShopID"] == null || Request.QueryString["Chln"].ToString() == null || Request.QueryString["OrderNo"].ToString() == null)
                            return;

                        dtShopStatic = new ReportDbSource().GetByShopName(Request.QueryString["ShopID"].ToString());
                        if (Request.QueryString["ShopID"].ToString() == "9999") // from buyCental
                        {
                            rptPRChallanNO rpt = new rptPRChallanNO();
                            DataTable dt = new ReportDbSource().rptPurchaseRecvByChln(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["SupID"].ToString(), Request.QueryString["Chln"].ToString(), Request.QueryString["OrderNo"].ToString());
                            dtPurchaseOrderSummary = dt;
                            rpt.SetDataSource(dt);

                            rpt.SetParameterValue("from", "From: ");
                            rpt.SetParameterValue("fromDate", Request.QueryString["sDate"].ToString());
                            rpt.SetParameterValue("toDate", Request.QueryString["eDate"].ToString());

                            if (dtShopStatic.Rows.Count > 0)
                            {
                                rpt.SetParameterValue("printedby", Page.User.Identity.Name);
                                rpt.SetParameterValue("reportName", "Purchase Receive");
                                rpt.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                                rpt.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            }
                            else
                            {
                                rpt.SetParameterValue("printedby", Page.User.Identity.Name);
                                rpt.SetParameterValue("reportName", "Purchase Receive");
                                rpt.SetParameterValue("shopname", "");
                                rpt.SetParameterValue("address", "");
                            }
                            rptViewer.ReportSource = rpt;
                            rptViewer.DataBind();
                        }
                        break;
                    #endregion

                    #region Periodical Stock
                    case "PeriodicalStockReport":
                       if (Request.QueryString["ShopID"] == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        string  ShopID = Request.QueryString["ShopID"].ToString();
                        if (ShopID != "All")
                            dtShopStatic = new ReportDbSource().GetByShopName(ShopID);
                        else
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");

                        if (Request.QueryString["ShopID"].ToString() == "9999") // from buyCental
                        {
                            rptPeriodicalStockBuyCentral rpt = new rptPeriodicalStockBuyCentral();
                            string sDate = Request.QueryString["sDate"].ToString();
                            string eDate = Request.QueryString["eDate"].ToString();
                            DataTable dt = new ReportDbSource().rptReportBuyCentralStockPeriodical(sDate, eDate, Request.QueryString["BTID"].ToString(), Request.QueryString["GroupID"].ToString(), Request.QueryString["PrdID"].ToString(), Request.QueryString["SSID"].ToString(), Request.QueryString["SupID"].ToString(), Request.QueryString["balType"].ToString());
                            dtPeriodicalStockBuycentral = dt;
                            rpt.SetDataSource(dt);

                            rpt.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                            rpt.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());

                            if (dtShopStatic.Rows.Count > 0)
                            {
                                rpt.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                                rpt.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            }
                            else
                            {
                                rpt.SetParameterValue("shopname", "");
                                rpt.SetParameterValue("address", "");
                            }
                            rptViewer.ReportSource = rpt;
                            rptViewer.DataBind();
                        
                        }
                        else
                        {
                            rptPeriodicalStock rpt = new rptPeriodicalStock();
                            string sDate = Request.QueryString["sDate"].ToString();
                            string eDate = Request.QueryString["eDate"].ToString();
                            DataTable dt = new ReportDbSource().rptReportStockPeriodical(sDate, eDate, Request.QueryString["ShopID"].ToString(), Request.QueryString["BTID"].ToString(), Request.QueryString["GroupID"].ToString(), Request.QueryString["PrdID"].ToString(), Request.QueryString["SSID"].ToString(), Request.QueryString["SupID"].ToString(), Request.QueryString["balType"].ToString());
                            dtPeriodicalStock = dt;
                            rpt.SetDataSource(dt);

                            rpt.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                            rpt.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());

                            if (dtShopStatic.Rows.Count > 0)
                            {
                                rpt.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                                rpt.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            }
                            else
                            {
                                rpt.SetParameterValue("shopname", "");
                                rpt.SetParameterValue("address", "");
                            }
                            rptViewer.ReportSource = rpt;
                            rptViewer.DataBind();
                        }
                        break;
                    #endregion

                }
            }
            catch (Exception ex)
            {
            }
        }
        private void BindReportWhenPostBack()
        {
            try
            {
                switch (Request.QueryString["ReportName"])
                {
                    #region SupWiseStockSummary
                    case "SupWiseStockSummary":
                        if (Request.QueryString["ShopID"].ToString() == "9999") // from buyCental
                        {
                            rptSupWiseStockSummary rptSupWiseStock = new rptSupWiseStockSummary();
                            rptSupWiseStock.SetDataSource(dtSupWiseStockSummary);

                            if (dtShopStatic.Rows.Count > 0)
                            {
                                rptSupWiseStock.SetParameterValue("printedby", Page.User.Identity.Name);
                                rptSupWiseStock.SetParameterValue("reportName", "Supplier Wise Stock Summary");
                                rptSupWiseStock.SetParameterValue("shopname",
                                    dtShopStatic.Rows[0]["ShopName"].ToString());
                                rptSupWiseStock.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            }
                            else
                            {
                                rptSupWiseStock.SetParameterValue("printedby", Page.User.Identity.Name);
                                rptSupWiseStock.SetParameterValue("reportName", "Supplier Wise Stock Summary");
                                rptSupWiseStock.SetParameterValue("shopname", "");
                                rptSupWiseStock.SetParameterValue("address", "");
                            }
                            rptViewer.ReportSource = rptSupWiseStock;
                            rptViewer.DataBind();
                        }
                        else  // others shop
                        {
                            rptSupWiseStockSummaryShop rptSupWiseStock = new rptSupWiseStockSummaryShop();
                            rptSupWiseStock.SetDataSource(dtSupWiseStockSummaryShop);

                            if (dtShopStatic.Rows.Count > 0)
                            {
                                rptSupWiseStock.SetParameterValue("printedby", Page.User.Identity.Name);
                                rptSupWiseStock.SetParameterValue("reportName", "Supplier Wise Stock Summary");
                                rptSupWiseStock.SetParameterValue("shopname",
                                    dtShopStatic.Rows[0]["ShopName"].ToString());
                                rptSupWiseStock.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            }
                            else
                            {
                                rptSupWiseStock.SetParameterValue("printedby", Page.User.Identity.Name);
                                rptSupWiseStock.SetParameterValue("reportName", "Supplier Wise Stock Summary");
                                rptSupWiseStock.SetParameterValue("shopname", "");
                                rptSupWiseStock.SetParameterValue("address", "");
                            }
                            rptViewer.ReportSource = rptSupWiseStock;
                            rptViewer.DataBind();
                        }
                        break;
                    #endregion

                    #region SupStockPosition
                    case "SupStockPosition":
                        
                        if (Request.QueryString["ShopID"].ToString() == "9999") // from buyCental
                        {
                            rptSupStockPosition rptSupWiseStock = new rptSupStockPosition();
                            rptSupWiseStock.SetDataSource(dtSupStockPosition);

                            if (dtShopStatic.Rows.Count > 0)
                            {
                                rptSupWiseStock.SetParameterValue("printedby", Page.User.Identity.Name);
                                rptSupWiseStock.SetParameterValue("reportName", "Supplier Wise Stock Summary");
                                rptSupWiseStock.SetParameterValue("shopname",
                                    dtShopStatic.Rows[0]["ShopName"].ToString());
                                rptSupWiseStock.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            }
                            else
                            {
                                rptSupWiseStock.SetParameterValue("printedby", Page.User.Identity.Name);
                                rptSupWiseStock.SetParameterValue("reportName", "Supplier Wise Stock Summary");
                                rptSupWiseStock.SetParameterValue("shopname", "");
                                rptSupWiseStock.SetParameterValue("address", "");
                            }
                            rptViewer.ReportSource = rptSupWiseStock;
                            rptViewer.DataBind();
                        }
                        else  // others shop
                        {
                            rptSupStockPositionShop rptSupWiseStock = new rptSupStockPositionShop();
                            rptSupWiseStock.SetDataSource(dtSupStockPositionShop);

                            if (dtShopStatic.Rows.Count > 0)
                            {
                                rptSupWiseStock.SetParameterValue("printedby", Page.User.Identity.Name);
                                rptSupWiseStock.SetParameterValue("reportName", "Supplier Wise Stock Summary");
                                rptSupWiseStock.SetParameterValue("shopname",
                                    dtShopStatic.Rows[0]["ShopName"].ToString());
                                rptSupWiseStock.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            }
                            else
                            {
                                rptSupWiseStock.SetParameterValue("printedby", Page.User.Identity.Name);
                                rptSupWiseStock.SetParameterValue("reportName", "Supplier Wise Stock Summary");
                                rptSupWiseStock.SetParameterValue("shopname", "");
                                rptSupWiseStock.SetParameterValue("address", "");
                            }
                            rptViewer.ReportSource = rptSupWiseStock;
                            rptViewer.DataBind();
                        }
                        break;
                    #endregion

                    #region Group wise Details Stock
                    case "GroupWiseDetailsDiffSup":
                        if (Request.QueryString["SupID"] == null || Request.QueryString["balQtyType"] == null || Request.QueryString["ShopID"] == null)
                            return;

                        if (Request.QueryString["ShopID"].ToString() == "9999") // from buyCental
                        {
                            rptGroupwiseDetailsStock rpt = new rptGroupwiseDetailsStock();
                            rpt.SetDataSource(dtGroupwiseDetailsStock);

                            if (dtShopStatic.Rows.Count > 0)
                            {
                                rpt.SetParameterValue("printedby", Page.User.Identity.Name);
                                rpt.SetParameterValue("reportName", "Supplier Wise Stock Summary");
                                rpt.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                                rpt.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            }
                            else
                            {
                                rpt.SetParameterValue("printedby", Page.User.Identity.Name);
                                rpt.SetParameterValue("reportName", "Supplier Wise Stock Summary");
                                rpt.SetParameterValue("shopname", "");
                                rpt.SetParameterValue("address", "");
                            }
                            rptViewer.ReportSource = rpt;
                            rptViewer.DataBind();
                        }
                        else  // others shop
                        {
                            rptGroupwiseDetailsStockShop rpt = new rptGroupwiseDetailsStockShop();
                            rpt.SetDataSource(dtGroupwiseDetailsStockShop);

                            if (dtShopStatic.Rows.Count > 0)
                            {
                                rpt.SetParameterValue("printedby", Page.User.Identity.Name);
                                rpt.SetParameterValue("reportName", "Supplier Wise Stock Summary");
                                rpt.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                                rpt.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            }
                            else
                            {
                                rpt.SetParameterValue("printedby", Page.User.Identity.Name);
                                rpt.SetParameterValue("reportName", "Supplier Wise Stock Summary");
                                rpt.SetParameterValue("shopname", "");
                                rpt.SetParameterValue("address", "");
                            }
                            rptViewer.ReportSource = rpt;
                            rptViewer.DataBind();
                        }
                        break;
                    #endregion

                    #region PurchaseOrder By PO
                    case "POStockReceived":
                        if (Request.QueryString["SupID"] == null || Request.QueryString["ShopID"] == null)
                            return;

                        if (Request.QueryString["ShopID"].ToString() == "9999") // from buyCental
                        {
                            rptPurchaseOrderByPO rpt = new rptPurchaseOrderByPO();
                            rpt.SetDataSource(dtPurchaseOrderByPO);
                            rpt.SetParameterValue("from", "From: ");
                            rpt.SetParameterValue("fromDate", Request.QueryString["sDate"].ToString());
                            rpt.SetParameterValue("toDate", Request.QueryString["eDate"].ToString());
                            if (dtShopStatic.Rows.Count > 0)
                            {
                                rpt.SetParameterValue("printedby", Page.User.Identity.Name);
                                rpt.SetParameterValue("reportName", "Purchase Order By PO Number");
                                rpt.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                                rpt.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            }
                            else
                            {
                                rpt.SetParameterValue("printedby", Page.User.Identity.Name);
                                rpt.SetParameterValue("reportName", "Purchase Order By PO Number");
                                rpt.SetParameterValue("shopname", "");
                                rpt.SetParameterValue("address", "");
                            }
                            rptViewer.ReportSource = rpt;
                            rptViewer.DataBind();
                        }
                        break;
                    #endregion

                    #region PurchaseOrder Summary
                    case "POPendingSummary":
                        if (Request.QueryString["SupID"] == null || Request.QueryString["ShopID"] == null)
                            return;

                        if (Request.QueryString["ShopID"].ToString() == "9999") // from buyCental
                        {
                            rptPurchaseOrderByPOSummary rpt = new rptPurchaseOrderByPOSummary();
                            rpt.SetDataSource(dtPurchaseOrderSummary);
                            
                            rpt.SetParameterValue("from", "From: ");
                            rpt.SetParameterValue("fromDate", Request.QueryString["sDate"].ToString());
                            rpt.SetParameterValue("toDate", Request.QueryString["eDate"].ToString());
                            if (dtShopStatic.Rows.Count > 0)
                            {
                                rpt.SetParameterValue("printedby", Page.User.Identity.Name);
                                rpt.SetParameterValue("reportName", "Purchase Order Summary");
                                rpt.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                                rpt.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            }
                            else
                            {
                                rpt.SetParameterValue("printedby", Page.User.Identity.Name);
                                rpt.SetParameterValue("reportName", "Supplier Wise Stock Summary");
                                rpt.SetParameterValue("shopname", "");
                                rpt.SetParameterValue("address", "");
                            }
                            rptViewer.ReportSource = rpt;
                            rptViewer.DataBind();
                        }
                        break;
                    #endregion
                  
                    #region PR Challan NO
                    case "PRChallanNO":
                        if (Request.QueryString["SupID"] == null || Request.QueryString["ShopID"] == null || Request.QueryString["Chln"].ToString() == null || Request.QueryString["OrderNo"].ToString() == null)
                            return;
                        if (Request.QueryString["ShopID"].ToString() == "9999") // from buyCental
                        {
                            rptPRChallanNO rpt = new rptPRChallanNO();
                            rpt.SetDataSource(dtPurchaseRecvByChln);

                            rpt.SetParameterValue("from", "From: ");
                            rpt.SetParameterValue("fromDate", Request.QueryString["sDate"].ToString());
                            rpt.SetParameterValue("toDate", Request.QueryString["eDate"].ToString());

                            if (dtShopStatic.Rows.Count > 0)
                            {
                                rpt.SetParameterValue("printedby", Page.User.Identity.Name);
                                rpt.SetParameterValue("reportName", "Purchase Receive by Challan Number");
                                rpt.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                                rpt.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            }
                            else
                            {
                                rpt.SetParameterValue("printedby", Page.User.Identity.Name);
                                rpt.SetParameterValue("reportName", "Purchase Receive by Challan Number");
                                rpt.SetParameterValue("shopname", "");
                                rpt.SetParameterValue("address", "");
                            }
                            rptViewer.ReportSource = rpt;
                            rptViewer.DataBind();
                        }
                        break;
                    #endregion

                    #region PR Order NO
                    case "PROrderNo":
                        if (Request.QueryString["SupID"] == null || Request.QueryString["ShopID"] == null || Request.QueryString["Chln"].ToString() == null || Request.QueryString["OrderNo"].ToString() == null)
                            return;

                        if (Request.QueryString["ShopID"].ToString() == "9999") // from buyCental
                        {
                            rptPRChallanNO rpt = new rptPRChallanNO();
                            rpt.SetDataSource(dtPurchaseRecvByOrder);

                            rpt.SetParameterValue("from", "From: ");
                            rpt.SetParameterValue("fromDate", Request.QueryString["sDate"].ToString());
                            rpt.SetParameterValue("toDate", Request.QueryString["eDate"].ToString());

                            if (dtShopStatic.Rows.Count > 0)
                            {
                                rpt.SetParameterValue("printedby", Page.User.Identity.Name);
                                rpt.SetParameterValue("reportName", "Purchase Receive by Order Number");
                                rpt.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                                rpt.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            }
                            else
                            {
                                rpt.SetParameterValue("printedby", Page.User.Identity.Name);
                                rpt.SetParameterValue("reportName", "Purchase Receive by Order Number");
                                rpt.SetParameterValue("shopname", "");
                                rpt.SetParameterValue("address", "");
                            }
                            rptViewer.ReportSource = rpt;
                            rptViewer.DataBind();
                        }
                        break;
                    #endregion

                    #region PR Supplier Summary
                    case "PRSupplierSummary":
                        if (Request.QueryString["SupID"] == null || Request.QueryString["ShopID"] == null || Request.QueryString["Chln"].ToString() == null || Request.QueryString["OrderNo"].ToString() == null)
                            return;

                        dtShopStatic = new ReportDbSource().GetByShopName(Request.QueryString["ShopID"].ToString());
                        if (Request.QueryString["ShopID"].ToString() == "9999") // from buyCental
                        {
                            rptPRChallanNO rpt = new rptPRChallanNO();
                            rpt.SetDataSource(dtPurchaseOrderSummary);

                            rpt.SetParameterValue("from", "From: ");
                            rpt.SetParameterValue("fromDate", Request.QueryString["sDate"].ToString());
                            rpt.SetParameterValue("toDate", Request.QueryString["eDate"].ToString());

                            if (dtShopStatic.Rows.Count > 0)
                            {
                                rpt.SetParameterValue("printedby", Page.User.Identity.Name);
                                rpt.SetParameterValue("reportName", "Purchase Receive");
                                rpt.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                                rpt.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            }
                            else
                            {
                                rpt.SetParameterValue("printedby", Page.User.Identity.Name);
                                rpt.SetParameterValue("reportName", "Purchase Receive");
                                rpt.SetParameterValue("shopname", "");
                                rpt.SetParameterValue("address", "");
                            }
                            rptViewer.ReportSource = rpt;
                            rptViewer.DataBind();
                        }
                        break;
                    #endregion

                    #region Periodical Stock
                    case "PeriodicalStockReport":
                        if (Request.QueryString["ShopID"] == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        string ShopID = Request.QueryString["ShopID"].ToString();
                        if (ShopID != "All")
                            dtShopStatic = new ReportDbSource().GetByShopName(ShopID);
                        else
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");

                        if (Request.QueryString["ShopID"].ToString() == "9999") // from buyCental
                        {
                            rptPeriodicalStockBuyCentral rpt = new rptPeriodicalStockBuyCentral();
                             rpt.SetDataSource(dtPeriodicalStockBuycentral);

                            rpt.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                            rpt.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());

                            if (dtShopStatic.Rows.Count > 0)
                            {
                                rpt.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                                rpt.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            }
                            else
                            {
                                rpt.SetParameterValue("shopname", "");
                                rpt.SetParameterValue("address", "");
                            }
                            rptViewer.ReportSource = rpt;
                            rptViewer.DataBind();
                        }
                        else
                        {
                            rptPeriodicalStock rpt = new rptPeriodicalStock();
                           
                            rpt.SetDataSource(dtPeriodicalStock);

                            rpt.SetParameterValue("@FromDate", Request.QueryString["sDate"].ToString());
                            rpt.SetParameterValue("@ToDate", Request.QueryString["eDate"].ToString());


                            if (dtShopStatic.Rows.Count > 0)
                            {
                                rpt.SetParameterValue("reportName", "Purchase Receive");
                                rpt.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                                rpt.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            }
                            else
                            {
                                rpt.SetParameterValue("reportName", "Purchase Receive");
                                rpt.SetParameterValue("shopname", "");
                                rpt.SetParameterValue("address", "");
                            }
                            rptViewer.ReportSource = rpt;
                            rptViewer.DataBind();
                        }
                        break;
                    #endregion

                }
            }
            catch (Exception ex)
            {

            }
        }
        private LogedInInfo GetLogedInInfo()
        {
            LogedInInfo info = new LogedInInfo();
            if (Request.Cookies["POSLogedInInfo"] != null)
            {
                var value = Request.Cookies["POSLogedInInfo"].Value;
                info = Newtonsoft.Json.JsonConvert.DeserializeObject<LogedInInfo>(value) as LogedInInfo;
            }
            return info;
        }
    }
}