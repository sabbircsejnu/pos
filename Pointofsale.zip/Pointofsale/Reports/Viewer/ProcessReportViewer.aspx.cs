﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using RetailMaster.POS.Service;
using RetailMaster.POS.Web.BLL;
using RetailMaster.POS.Web.Models;
using RetailMaster.POS.Web.Reports.Setup;
using RetailMaster.POS.Web.ViewModels;

namespace RetailMaster.POS.Web.Reports.Viewer
{
    public partial class ProcessReportViewer : System.Web.UI.Page
    {
        private static string strdvCriteria = string.Empty;
        private static DataTable dtShopStatic;
        private static DataTable dtPurchaseOrderTemp;
        private static DataTable dtPurchaseOrder;
        private static DataTable dtPurchaseReceiveByChln;
        private static DataTable dtPurchaseReceiveTempByChln;
        private static DataTable dtDeliveryShop;
        private static DataTable dtDeliveryShopTemp;
        private static DataTable dtShopRequisition;
        private static DataTable dtShopRequisitionTemp;
        private static DataTable dtShopRequisitionApproval;
        private static DataTable dtShopDeliveryReceive;
        private static DataTable dtShopDeliveryReceiveDraft;
        private static DataTable dtStockReturn;
        private static DataTable dtStockReturnDraft;
        private static DataTable dtStockDML;
        private static DataTable dtStockDMLDraft;
        private static DataTable dtStockReturnShop;
        private static DataTable dtStockReturnShopDraft;
       
        private static DataTable dtBuyAndGet;
        private static DataTable dtPackageSetup;
        private static DataTable dtPackageIssue;
        private static DataTable dtDiscountCircular;
        private static DataTable dtPriceChangedCircular;
        private static DataTable dtPayLessCreate;

        private static DataTable dtPackageIssueReceive;

        protected void Page_Init(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindReport();
            }
            else
            {
                BindReportWhenPostBack();
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        private void BindReport()
        {
            String LogedInShopID = GetLogedInInfo().ShopID;
            if (dtShopStatic == null)
            {
                DataTable dtShop = new ReportDbSource().GetByShopName(LogedInShopID);
                dtShopStatic = dtShop;
            }

            switch (Request.QueryString["ReportName"])
            {
                #region PurchaseOrderTemp
                case "PurchaseOrderTemp":
                    lblrptHeader.Text = "Purchase Order Draft Sheet";
                    rptPurchaseOrderTempByChln objPurchaseOrderTemp = new rptPurchaseOrderTempByChln();
                    DataTable dtPOT = new ReportDbSource().GetBuyOrderTempByChln(Request.QueryString["Chln"].ToString());
                    dtPurchaseOrderTemp = dtPOT;
                    objPurchaseOrderTemp.SetDataSource(dtPurchaseOrderTemp);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objPurchaseOrderTemp.SetParameterValue("ShopName", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objPurchaseOrderTemp.SetParameterValue("printedby", Page.User.Identity.Name);
                        objPurchaseOrderTemp.SetParameterValue("VillAreaRoad", dtShopStatic.Rows[0]["VillAreaRoad"].ToString());
                        objPurchaseOrderTemp.SetParameterValue("Post", dtShopStatic.Rows[0]["Post"].ToString());
                        objPurchaseOrderTemp.SetParameterValue("District", dtShopStatic.Rows[0]["District"].ToString());
                    }
                    else
                    {
                        objPurchaseOrderTemp.SetParameterValue("ShopName", "");
                        objPurchaseOrderTemp.SetParameterValue("printedby", Page.User.Identity.Name);
                        objPurchaseOrderTemp.SetParameterValue("VillAreaRoad", "");
                        objPurchaseOrderTemp.SetParameterValue("Post", "");
                        objPurchaseOrderTemp.SetParameterValue("District", "");
                    }
                    rptViewer.ReportSource = objPurchaseOrderTemp;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region PurchaseOrder
                case "PurchaseOrder":
                    lblrptHeader.Text = "Purchase Order Sheet";
                    rptPurchaseOrderByChln objPurchaseOrder = new rptPurchaseOrderByChln();
                    DataTable dtPO = new ReportDbSource().GetBuyOrderByChln(Request.QueryString["Chln"].ToString());
                    dtPurchaseOrder = dtPO;
                    objPurchaseOrder.SetDataSource(dtPO);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objPurchaseOrder.SetParameterValue("ShopName", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objPurchaseOrder.SetParameterValue("printedby", Page.User.Identity.Name);
                        objPurchaseOrder.SetParameterValue("VillAreaRoad", dtShopStatic.Rows[0]["VillAreaRoad"].ToString());
                        objPurchaseOrder.SetParameterValue("Post", dtShopStatic.Rows[0]["Post"].ToString());
                        objPurchaseOrder.SetParameterValue("District", dtShopStatic.Rows[0]["District"].ToString());
                    }
                    else
                    {
                        objPurchaseOrder.SetParameterValue("ShopName", "");
                        objPurchaseOrder.SetParameterValue("printedby", Page.User.Identity.Name);
                        objPurchaseOrder.SetParameterValue("VillAreaRoad", "");
                        objPurchaseOrder.SetParameterValue("Post", "");
                        objPurchaseOrder.SetParameterValue("District", "");
                    }
                    rptViewer.ReportSource = objPurchaseOrder;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region PurchaseReceive
                case "PurchaseReceive":
                    lblrptHeader.Text = "Stock Receiving Challan";
                    PurchaseReceiveByChln objPR = new PurchaseReceiveByChln();
                    DataTable dtPR = new ReportDbSource().rChallan_GetByChln(Request.QueryString["Chln"].ToString());
                    dtPurchaseReceiveByChln = dtPR;
                    objPR.SetDataSource(dtPR);

                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objPR.SetParameterValue("ShopName", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objPR.SetParameterValue("printedby", Page.User.Identity.Name);
                        objPR.SetParameterValue("VillAreaRoad", dtShopStatic.Rows[0]["VillAreaRoad"].ToString());
                        objPR.SetParameterValue("Post", dtShopStatic.Rows[0]["Post"].ToString());
                        objPR.SetParameterValue("District", dtShopStatic.Rows[0]["District"].ToString());
                    }
                    else
                    {
                        objPR.SetParameterValue("ShopName", "");
                        objPR.SetParameterValue("printedby", Page.User.Identity.Name);
                        objPR.SetParameterValue("VillAreaRoad", "");
                        objPR.SetParameterValue("Post", "");
                        objPR.SetParameterValue("District", "");
                    }
                    rptViewer.ReportSource = objPR;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region PurchaseReceiveTemp
                case "PurchaseReceiveTemp":
                    lblrptHeader.Text = "Receive Challan (Draft)";
                    PurchaseReceiveTempByChln objPRT = new PurchaseReceiveTempByChln();
                    DataTable dtPRT = new ReportDbSource().rChallanTemp_GetByChln(Request.QueryString["Chln"].ToString());
                    objPRT.SetDataSource(dtPRT);
                    dtPurchaseReceiveTempByChln = dtPRT;
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objPRT.SetParameterValue("printedby", User.Identity.Name);
                        objPRT.SetParameterValue("ShopName", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objPRT.SetParameterValue("VillAreaRoad", dtShopStatic.Rows[0]["VillAreaRoad"].ToString());
                        objPRT.SetParameterValue("Post", dtShopStatic.Rows[0]["Post"].ToString());
                        objPRT.SetParameterValue("District", dtShopStatic.Rows[0]["District"].ToString());
                    }
                    else
                    {
                        objPRT.SetParameterValue("printedby", "");
                        objPRT.SetParameterValue("ShopName", "");
                        objPRT.SetParameterValue("VillAreaRoad", "");
                        objPRT.SetParameterValue("Post", "");
                        objPRT.SetParameterValue("District", "");
                    }

                    rptViewer.ReportSource = objPRT;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region DeliveryShop
                case "DeliveryShop":
                    lblrptHeader.Text = "Delivery Challan";
                    DeliveryToShop objDC = new DeliveryToShop();
                    DataTable dtDC = new ReportDbSource().iChallan_GetByDCNO(Request.QueryString["DCNO"].ToString());
                    objDC.SetDataSource(dtDC);
                    dtDeliveryShop = dtDC;
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objDC.SetParameterValue("ReportName", "Delivery Challan");
                        objDC.SetParameterValue("printedby", Page.User.Identity.Name);
                        objDC.SetParameterValue("ShopName", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objDC.SetParameterValue("VillAreaRoad", dtShopStatic.Rows[0]["VillAreaRoad"].ToString());
                        objDC.SetParameterValue("Post", dtShopStatic.Rows[0]["Post"].ToString());
                        objDC.SetParameterValue("District", dtShopStatic.Rows[0]["District"].ToString());
                    }
                    else
                    {
                        objDC.SetParameterValue("ReportName", "Delivery Challan");
                        objDC.SetParameterValue("printedby", Page.User.Identity.Name);
                        objDC.SetParameterValue("ShopName", "");
                        objDC.SetParameterValue("VillAreaRoad", "");
                        objDC.SetParameterValue("Post", "");
                        objDC.SetParameterValue("District", "");
                    }

                    rptViewer.ReportSource = objDC;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region DeliveryShopTemp
                case "DeliveryShopTemp":
                    lblrptHeader.Text = "Delivery Challan (Draft)";
                    DeliveryToShop objDCT = new DeliveryToShop();
                    DataTable dtDCT = new ReportDbSource().iChallanTemp_GetByDCNO(Request.QueryString["DCNO"].ToString());
                    objDCT.SetDataSource(dtDCT);
                    dtDeliveryShopTemp = dtDCT;
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objDCT.SetParameterValue("ReportName", "Delivery Challan (Draft)");
                        objDCT.SetParameterValue("printedby", Page.User.Identity.Name);
                        objDCT.SetParameterValue("ShopName", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objDCT.SetParameterValue("VillAreaRoad", dtShopStatic.Rows[0]["VillAreaRoad"].ToString());
                        objDCT.SetParameterValue("Post", dtShopStatic.Rows[0]["Post"].ToString());
                        objDCT.SetParameterValue("District", dtShopStatic.Rows[0]["District"].ToString());
                    }
                    else
                    {
                        objDCT.SetParameterValue("ReportName", "Delivery Challan (Draft)");
                        objDCT.SetParameterValue("printedby", Page.User.Identity.Name);
                        objDCT.SetParameterValue("ShopName", "");
                        objDCT.SetParameterValue("VillAreaRoad", "");
                        objDCT.SetParameterValue("Post", "");
                        objDCT.SetParameterValue("District", "");
                    }

                    rptViewer.ReportSource = objDCT;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region ShopRequisition
                case "ShopRequisition":
                    lblrptHeader.Text = "Shop Requisition";
                    rptBuyRequisition objSR = new rptBuyRequisition();
                    DataTable dtSR = new ReportDbSource().BuyRequisition_GetByRequisitionNo(Request.QueryString["RequisitionNo"].ToString());
                    objSR.SetDataSource(dtSR);
                    dtShopRequisition = dtSR;
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objSR.SetParameterValue("ReportName", "Shop Requisition");
                        objSR.SetParameterValue("printedby", Page.User.Identity.Name);
                        objSR.SetParameterValue("ShopName", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objSR.SetParameterValue("VillAreaRoad", dtShopStatic.Rows[0]["VillAreaRoad"].ToString());
                        objSR.SetParameterValue("Post", dtShopStatic.Rows[0]["Post"].ToString());
                        objSR.SetParameterValue("District", dtShopStatic.Rows[0]["District"].ToString());
                    }
                    else
                    {
                        objSR.SetParameterValue("ReportName", "Shop Requisition");
                        objSR.SetParameterValue("printedby", Page.User.Identity.Name);
                        objSR.SetParameterValue("ShopName", "");
                        objSR.SetParameterValue("VillAreaRoad", "");
                        objSR.SetParameterValue("Post", "");
                        objSR.SetParameterValue("District", "");
                    }

                    rptViewer.ReportSource = objSR;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region ShopRequisitionTemp
                case "ShopRequisitionTemp":
                    lblrptHeader.Text = "Shop Requisition (Draft)";
                    rptBuyRequisition objSRT = new rptBuyRequisition();
                    DataTable dtSRT = new ReportDbSource().BuyRequisitionTemp_GetByShopID(LogedInShopID);
                    objSRT.SetDataSource(dtSRT);
                    dtShopRequisitionTemp = dtSRT;
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objSRT.SetParameterValue("ReportName", "Shop Requisition (Draft)");
                        objSRT.SetParameterValue("printedby", Page.User.Identity.Name);
                        objSRT.SetParameterValue("ShopName", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objSRT.SetParameterValue("VillAreaRoad", dtShopStatic.Rows[0]["VillAreaRoad"].ToString());
                        objSRT.SetParameterValue("Post", dtShopStatic.Rows[0]["Post"].ToString());
                        objSRT.SetParameterValue("District", dtShopStatic.Rows[0]["District"].ToString());
                    }
                    else
                    {
                        objSRT.SetParameterValue("ReportName", "Shop Requisition (Draft)");
                        objSRT.SetParameterValue("printedby", Page.User.Identity.Name);
                        objSRT.SetParameterValue("ShopName", "");
                        objSRT.SetParameterValue("VillAreaRoad", "");
                        objSRT.SetParameterValue("Post", "");
                        objSRT.SetParameterValue("District", "");
                    }

                    rptViewer.ReportSource = objSRT;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region ShopRequisitionApproval
                case "ShopRequisitionApproval":
                    lblrptHeader.Text = "Shop Requisition Approval";
                    rptApprovedRequisition objSRA = new rptApprovedRequisition();
                    DataTable dtSRA = new ReportDbSource().BuyRequisition_GetByRequisitionNo(Request.QueryString["RequisitionNo"].ToString());
                    objSRA.SetDataSource(dtSRA);
                    dtShopRequisitionApproval = dtSRA;
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objSRA.SetParameterValue("printedby", Page.User.Identity.Name);
                        objSRA.SetParameterValue("ShopName", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objSRA.SetParameterValue("VillAreaRoad", dtShopStatic.Rows[0]["VillAreaRoad"].ToString());
                        objSRA.SetParameterValue("Post", dtShopStatic.Rows[0]["Post"].ToString());
                        objSRA.SetParameterValue("District", dtShopStatic.Rows[0]["District"].ToString());
                    }
                    else
                    {
                        objSRA.SetParameterValue("printedby", Page.User.Identity.Name);
                        objSRA.SetParameterValue("ShopName", "");
                        objSRA.SetParameterValue("VillAreaRoad", "");
                        objSRA.SetParameterValue("Post", "");
                        objSRA.SetParameterValue("District", "");
                    }

                    rptViewer.ReportSource = objSRA;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region Shop DeliveryReceive
                case "DeliveryReceive":
                    lblrptHeader.Text = "Shop Item Receive";
                    rptDeliveryReceive objSDR = new rptDeliveryReceive();
                    DataTable dtSDR = new ReportDbSource().rChallanShop_GetByChlnShopID(Request.QueryString["DCNO"].ToString());
                    dtShopDeliveryReceive = dtSDR;
                    objSDR.SetDataSource(dtSDR);
                    DataTable dtShopInfo=new DataTable();
                    if (dtSDR.Rows.Count > 0)
                    {
                        dtShopInfo = new ReportDbSource().GetByShopName(dtSDR.Rows[0]["ShopID"].ToString());
                    }
                    else
                    {
                        dtShopInfo = dtShopStatic;
                    }
                    if (dtShopInfo.Rows.Count > 0)
                    {
                        objSDR.SetParameterValue("printedby", Page.User.Identity.Name);
                        objSDR.SetParameterValue("reportName", "Shop Item Receive");
                        objSDR.SetParameterValue("shopname", dtShopInfo.Rows[0]["ShopName"].ToString());
                        objSDR.SetParameterValue("address", dtShopInfo.Rows[0]["Address"].ToString());
                    }
                    else
                    {
                        objSDR.SetParameterValue("printedby", Page.User.Identity.Name);
                        objSDR.SetParameterValue("reportName", "Shop Item Receive");
                        objSDR.SetParameterValue("shopname", "");
                        objSDR.SetParameterValue("address", "");
                    }
                    rptViewer.ReportSource = objSDR;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region Shop DeliveryReceiveDraft
                case "DeliveryReceiveDraft":
                    lblrptHeader.Text = "Shop Item Receive (Draft)";
                    DataTable dtSDRT = new ReportDbSource().iChallan_GetByDCNO(Request.QueryString["DCNO"].ToString());
                    rptDeliveryReceiveDraft objSDRT = new rptDeliveryReceiveDraft();
                    dtShopDeliveryReceiveDraft = dtSDRT;
                    objSDRT.SetDataSource(dtSDRT);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objSDRT.SetParameterValue("printedby", Page.User.Identity.Name);
                        objSDRT.SetParameterValue("reportName", "Shop Item Receive (Draft)");
                        objSDRT.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objSDRT.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                    }
                    else
                    {
                        objSDRT.SetParameterValue("printedby", Page.User.Identity.Name);
                        objSDRT.SetParameterValue("reportName", "Shop Item Receive (Draft)");
                        objSDRT.SetParameterValue("shopname", "");
                        objSDRT.SetParameterValue("address", "");
                    }
                    rptViewer.ReportSource = objSDRT;
                    rptViewer.DataBind();
                    break;

                #endregion

                #region Stock Return
                case "StockReturnReport":
                    lblrptHeader.Text = "Stock Return Report";
                    DataTable dtsrR = new ReportDbSource().StockReturn_GetByChln(Request.QueryString["Chln"].ToString());
                    rptStockReturn objsrR = new rptStockReturn();
                    dtStockReturn = dtsrR;
                    objsrR.SetDataSource(dtsrR);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objsrR.SetParameterValue("printedby", Page.User.Identity.Name);
                        objsrR.SetParameterValue("reportName", "Stock Return Report");
                        objsrR.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objsrR.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                    }
                    else
                    {
                        objsrR.SetParameterValue("printedby", Page.User.Identity.Name);
                        objsrR.SetParameterValue("reportName", "Stock Return Report");
                        objsrR.SetParameterValue("shopname", "");
                        objsrR.SetParameterValue("address", "");
                    }
                    rptViewer.ReportSource = objsrR;
                    rptViewer.DataBind();
                    break;

                #endregion

                #region Stock Return Report Temp
                case "StockReturnReportTemp":
                    lblrptHeader.Text = "Stock Return Report (Draft)";
                    DataTable dtsrRT = new ReportDbSource().StockReturnTemp_GetList();
                    rptStockReturn objsrRT = new rptStockReturn();
                    dtStockReturnDraft = dtsrRT;
                    objsrRT.SetDataSource(dtsrRT);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objsrRT.SetParameterValue("printedby", Page.User.Identity.Name);
                        objsrRT.SetParameterValue("reportName", "Stock Return Report (Draft)");
                        objsrRT.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objsrRT.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                    }
                    else
                    {
                        objsrRT.SetParameterValue("printedby", Page.User.Identity.Name);
                        objsrRT.SetParameterValue("reportName", "Stock Return Report (Draft)");
                        objsrRT.SetParameterValue("shopname", "");
                        objsrRT.SetParameterValue("address", "");
                    }
                    rptViewer.ReportSource = objsrRT;
                    rptViewer.DataBind();
                    break;

                #endregion

                #region Stock DML 
                case "StockDML":
                    lblrptHeader.Text = "Stock DML";
                    DataTable dtDML = new ReportDbSource().StockDML_GetByChln(Request.QueryString["Chln"].ToString());
                    rptStockDML objDML = new rptStockDML();
                    dtStockDML = dtDML;
                    objDML.SetDataSource(dtDML);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objDML.SetParameterValue("printedby", Page.User.Identity.Name);
                        objDML.SetParameterValue("reportName", "Stock Damaged and Lost");
                        objDML.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objDML.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                    }
                    else
                    {
                        objDML.SetParameterValue("printedby", Page.User.Identity.Name);
                        objDML.SetParameterValue("reportName", "Stock Damaged and Lost");
                        objDML.SetParameterValue("shopname", "");
                        objDML.SetParameterValue("address", "");
                    }
                    rptViewer.ReportSource = objDML;
                    rptViewer.DataBind();
                    break;

                #endregion

                #region Stock DML Draft
                case "StockDMLTemp":
                    lblrptHeader.Text = "Stock DML (Draft)";
                    DataTable dtDMLT = new ReportDbSource().StockDMLTemp_GetList();
                    rptStockDML objDMLT = new rptStockDML();
                    dtStockDMLDraft = dtDMLT;
                    objDMLT.SetDataSource(dtDMLT);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objDMLT.SetParameterValue("printedby", Page.User.Identity.Name);
                        objDMLT.SetParameterValue("reportName", "Stock Damaged and Lost (Draft)");
                        objDMLT.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objDMLT.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                    }
                    else
                    {
                        objDMLT.SetParameterValue("printedby", Page.User.Identity.Name);
                        objDMLT.SetParameterValue("reportName", "Stock Damaged and Lost (Draft)");
                        objDMLT.SetParameterValue("shopname", "");
                        objDMLT.SetParameterValue("address", "");
                    }
                    rptViewer.ReportSource = objDMLT;
                    rptViewer.DataBind();
                    break;

                #endregion

                #region Shop Stock Return
                case "StockReturnShop":
                    lblrptHeader.Text = "Shop Stock Return";
                    DataTable dtSRS = new ReportDbSource().StockReturnShopByChln(Request.QueryString["Chln"].ToString(), Request.QueryString["IsTransfer"].ToString());
                    rptStockReturnShop objSRS = new rptStockReturnShop();
                    dtStockReturnShop = dtSRS;
                    objSRS.SetDataSource(dtSRS);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objSRS.SetParameterValue("printedby", Page.User.Identity.Name);
                        objSRS.SetParameterValue("reportName", "Shop Stock Return");
                        objSRS.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objSRS.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                    }
                    else
                    {
                        objSRS.SetParameterValue("printedby", Page.User.Identity.Name);
                        objSRS.SetParameterValue("reportName", "Shop Stock Return");
                        objSRS.SetParameterValue("shopname", "");
                        objSRS.SetParameterValue("address", "");
                    }
                    rptViewer.ReportSource = objSRS;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region Shop Stock Return Temp
                case "StockReturnShopTemp":
                    lblrptHeader.Text = "Shop Stock Return (Draft)";

                    DataTable dtSRST = new ReportDbSource().StockReturnShopTempByChln(LogedInShopID, Request.QueryString["TransferToShop"].ToString(), User.Identity.Name);
                    rptStockReturnShop objSRST = new rptStockReturnShop();
                    dtStockReturnShopDraft = dtSRST;
                    objSRST.SetDataSource(dtSRST);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objSRST.SetParameterValue("printedby", Page.User.Identity.Name);
                        objSRST.SetParameterValue("reportName", "Shop Stock Return (Draft)");
                        objSRST.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objSRST.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                    }
                    else
                    {
                        objSRST.SetParameterValue("printedby", Page.User.Identity.Name);
                        objSRST.SetParameterValue("reportName", "Shop Stock Return (Draft)");
                        objSRST.SetParameterValue("shopname", "");
                        objSRST.SetParameterValue("address", "");
                    }
                    rptViewer.ReportSource = objSRST;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region Buy and Get
                case "BuyAndGet":
                    lblrptHeader.Text = "Buy and Get";
                    DataTable dtBaG = new ReportDbSource().BuyAndGet_GetByNo(Request.QueryString["buyAndGetNo"].ToString());
                    rptBuyAndGet objBaG = new rptBuyAndGet();
                    dtStockReturnShop = dtBaG;
                    objBaG.SetDataSource(dtBaG);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objBaG.SetParameterValue("printedby", Page.User.Identity.Name);
                        objBaG.SetParameterValue("reportName", "Buy and Get");
                        objBaG.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objBaG.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                    }
                    else
                    {
                        objBaG.SetParameterValue("printedby", Page.User.Identity.Name);
                        objBaG.SetParameterValue("reportName", "Buy and Get");
                        objBaG.SetParameterValue("shopname", "");
                        objBaG.SetParameterValue("address", "");
                    }
                    rptViewer.ReportSource = objBaG;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region Package Setup
                case "PackageSetup":
                    lblrptHeader.Text = "Package Setup";
                    DataTable dtPS = new ReportDbSource().PackageSetupByPackageNo(Request.QueryString["PackageNo"].ToString());
                    rptPackageSetup objPS = new rptPackageSetup();
                    dtPackageSetup = dtPS;
                    objPS.SetDataSource(dtPS);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objPS.SetParameterValue("printedby", Page.User.Identity.Name);
                        objPS.SetParameterValue("reportName", "Package");
                        objPS.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objPS.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                    }
                    else
                    {
                        objPS.SetParameterValue("printedby", Page.User.Identity.Name);
                        objPS.SetParameterValue("reportName", "Package");
                        objPS.SetParameterValue("shopname", "");
                        objPS.SetParameterValue("address", "");
                    }
                    rptViewer.ReportSource = objPS;
                    rptViewer.DataBind();
                    break;
                #endregion
                
                #region Package Issue
                case "PackageIssue":
                    lblrptHeader.Text = "Package Issue";
                    DataTable dtPI = new ReportDbSource().PackageIssueByPIssueNo(Request.QueryString["PIssueNo"].ToString());
                    rptPackageIssue objPI = new rptPackageIssue();
                    dtPackageIssue= dtPI;
                    objPI.SetDataSource(dtPI);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objPI.SetParameterValue("printedby", Page.User.Identity.Name);
                        objPI.SetParameterValue("reportName", "Package Issue");
                        objPI.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objPI.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                    }
                    else
                    {
                        objPI.SetParameterValue("printedby", Page.User.Identity.Name);
                        objPI.SetParameterValue("reportName", "Package Issue");
                        objPI.SetParameterValue("shopname", "");
                        objPI.SetParameterValue("address", "");
                    }
                    rptViewer.ReportSource = objPI;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region Discount Circular
                case "DiscountCircular":
                    lblrptHeader.Text = "Discount Circular";
                    DataTable dtDisC = new ReportDbSource().CircularDiscount_GetByCDNo(Request.QueryString["CDNo"].ToString());
                    rptDiscountCircular objDisC = new rptDiscountCircular();
                    dtDiscountCircular = dtDisC;
                    objDisC.SetDataSource(dtDisC);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objDisC.SetParameterValue("printedby", Page.User.Identity.Name);
                        objDisC.SetParameterValue("reportName", "Discount Circular");
                        objDisC.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objDisC.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                    }
                    else
                    {
                        objDisC.SetParameterValue("printedby", Page.User.Identity.Name);
                        objDisC.SetParameterValue("reportName", "Discount Circular");
                        objDisC.SetParameterValue("shopname", "");
                        objDisC.SetParameterValue("address", "");
                    }
                    rptViewer.ReportSource = objDisC;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region Price Changed Circular
                case "PriceChangedCircular":
                    lblrptHeader.Text = "Price Changed Circular";
                    DataTable dtCPC = new ReportDbSource().CircularPriceChanged_GetByCPCNo(Request.QueryString["CPCNo"].ToString());
                    rptPriceChangedCircular objCPC = new rptPriceChangedCircular();
                    dtPriceChangedCircular = dtCPC;
                    objCPC.SetDataSource(dtCPC);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objCPC.SetParameterValue("printedby", Page.User.Identity.Name);
                        objCPC.SetParameterValue("reportName", "Price Changed Circular");
                        objCPC.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objCPC.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                    }
                    else
                    {
                        objCPC.SetParameterValue("printedby", Page.User.Identity.Name);
                        objCPC.SetParameterValue("reportName", "Price Changed Circular");
                        objCPC.SetParameterValue("shopname", "");
                        objCPC.SetParameterValue("address", "");
                    }
                    rptViewer.ReportSource = objCPC;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region Pay Less Create
                case "PayLessCreate":

                    if (Request.QueryString["PayLessNo"] == null)
                        return;

                    lblrptHeader.Text = "Pay Less Create";
                    DataTable dtPayLess = new ReportDbSource().rpt_PayLessByID(Request.QueryString["PayLessNo"].ToString());
                    rptPayLess objPayLess = new rptPayLess();
                    dtPayLessCreate = dtPayLess;
                    objPayLess.SetDataSource(dtPayLess);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objPayLess.SetParameterValue("printedby", Page.User.Identity.Name);
                        objPayLess.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objPayLess.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                    }
                    else
                    {
                        objPayLess.SetParameterValue("printedby", Page.User.Identity.Name);
                        objPayLess.SetParameterValue("shopname", "");
                        objPayLess.SetParameterValue("address", "");
                    }
                    rptViewer.ReportSource = objPayLess;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region Package Issue Receive 
                case "PackageIssueReceive":

                    if (Request.QueryString["PIssueNo"] == null)
                        return;

                    lblrptHeader.Text = "Package Issue Receive";
                    DataTable dtPIssueNo = new ReportDbSource().GetPackageIssueReceivePIssueNo(Request.QueryString["PIssueNo"].ToString());
                    rptPackageIssue objPIssueNo = new rptPackageIssue();
                    dtPackageIssueReceive = dtPIssueNo;
                    objPIssueNo.SetDataSource(dtPIssueNo);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objPIssueNo.SetParameterValue("printedby", Page.User.Identity.Name);
                        objPIssueNo.SetParameterValue("reportName", "Package Issue");
                        objPIssueNo.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objPIssueNo.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                    }
                    else
                    {
                        objPIssueNo.SetParameterValue("printedby", Page.User.Identity.Name);
                        objPIssueNo.SetParameterValue("reportName", "Package Issue");
                        objPIssueNo.SetParameterValue("shopname", "");
                        objPIssueNo.SetParameterValue("address", "");
                    }
                    rptViewer.ReportSource = objPIssueNo;
                    rptViewer.DataBind();
                    break;
                #endregion
                    
            }
        }
        private void BindReportWhenPostBack()
        {
            switch (Request.QueryString["ReportName"])
            {
                #region PurchaseOrderTemp
                case "PurchaseOrderTemp":
                    lblrptHeader.Text = "Purchase Order Draft Sheet";
                    rptPurchaseOrderTempByChln newobj = new rptPurchaseOrderTempByChln();
                    newobj.SetDataSource(dtPurchaseOrderTemp);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        newobj.SetParameterValue("ShopName", dtShopStatic.Rows[0]["ShopName"].ToString());
                        newobj.SetParameterValue("printedby", Page.User.Identity.Name);
                        newobj.SetParameterValue("VillAreaRoad", dtShopStatic.Rows[0]["VillAreaRoad"].ToString());
                        newobj.SetParameterValue("Post", dtShopStatic.Rows[0]["Post"].ToString());
                        newobj.SetParameterValue("District", dtShopStatic.Rows[0]["District"].ToString());
                    }
                    else
                    {
                        newobj.SetParameterValue("ShopName", "");
                        newobj.SetParameterValue("printedby", Page.User.Identity.Name);
                        newobj.SetParameterValue("VillAreaRoad", "");
                        newobj.SetParameterValue("Post", "");
                        newobj.SetParameterValue("District", "");
                    }
                    rptViewer.ReportSource = newobj;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region PurchaseOrder
                case "PurchaseOrder":
                    lblrptHeader.Text = "Purchase Order Sheet";
                    strdvCriteria = Request.QueryString["Chln"].ToString();
                    rptPurchaseOrderByChln objPurchaseOrder = new rptPurchaseOrderByChln();
                    objPurchaseOrder.SetDataSource(dtPurchaseOrder);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objPurchaseOrder.SetParameterValue("ShopName", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objPurchaseOrder.SetParameterValue("printedby", Page.User.Identity.Name);
                        objPurchaseOrder.SetParameterValue("VillAreaRoad", dtShopStatic.Rows[0]["VillAreaRoad"].ToString());
                        objPurchaseOrder.SetParameterValue("Post", dtShopStatic.Rows[0]["Post"].ToString());
                        objPurchaseOrder.SetParameterValue("District", dtShopStatic.Rows[0]["District"].ToString());
                    }
                    else
                    {
                        objPurchaseOrder.SetParameterValue("ShopName", "");
                        objPurchaseOrder.SetParameterValue("printedby", Page.User.Identity.Name);
                        objPurchaseOrder.SetParameterValue("VillAreaRoad", "");
                        objPurchaseOrder.SetParameterValue("Post", "");
                        objPurchaseOrder.SetParameterValue("District", "");
                    }
                    rptViewer.ReportSource = objPurchaseOrder;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region PurchaseReceive
                case "PurchaseReceive":
                    lblrptHeader.Text = "Stock Receiving Challan";
                    PurchaseReceiveByChln objPR = new PurchaseReceiveByChln();
                    objPR.SetDataSource(dtPurchaseReceiveByChln);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objPR.SetParameterValue("ShopName", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objPR.SetParameterValue("printedby", Page.User.Identity.Name);
                        objPR.SetParameterValue("VillAreaRoad", dtShopStatic.Rows[0]["VillAreaRoad"].ToString());
                        objPR.SetParameterValue("Post", dtShopStatic.Rows[0]["Post"].ToString());
                        objPR.SetParameterValue("District", dtShopStatic.Rows[0]["District"].ToString());
                    }
                    else
                    {
                        objPR.SetParameterValue("ShopName", "");
                        objPR.SetParameterValue("printedby", Page.User.Identity.Name);
                        objPR.SetParameterValue("VillAreaRoad", "");
                        objPR.SetParameterValue("Post", "");
                        objPR.SetParameterValue("District", "");
                    }
                    rptViewer.ReportSource = objPR;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region PurchaseReceiveTemp
                case "PurchaseReceiveTemp":
                    lblrptHeader.Text = "Receive Challan Tep";
                    PurchaseReceiveTempByChln objPRT = new PurchaseReceiveTempByChln();
                    objPRT.SetDataSource(dtPurchaseReceiveTempByChln);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objPRT.SetParameterValue("ShopName", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objPRT.SetParameterValue("printedby", Page.User.Identity.Name);
                        objPRT.SetParameterValue("VillAreaRoad", dtShopStatic.Rows[0]["VillAreaRoad"].ToString());
                        objPRT.SetParameterValue("Post", dtShopStatic.Rows[0]["Post"].ToString());
                        objPRT.SetParameterValue("District", dtShopStatic.Rows[0]["District"].ToString());
                    }
                    else
                    {
                        objPRT.SetParameterValue("ShopName", "");
                        objPRT.SetParameterValue("printedby", Page.User.Identity.Name);
                        objPRT.SetParameterValue("VillAreaRoad", "");
                        objPRT.SetParameterValue("Post", "");
                        objPRT.SetParameterValue("District", "");
                    }
                    rptViewer.ReportSource = objPRT;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region DeliveryShop
                case "DeliveryShop":
                    lblrptHeader.Text = "Delivery Challan";
                    DeliveryToShop objDC = new DeliveryToShop();
                    objDC.SetDataSource(dtDeliveryShop);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objDC.SetParameterValue("ReportName", "Delivery Challan");
                        objDC.SetParameterValue("printedby", Page.User.Identity.Name);
                        objDC.SetParameterValue("ShopName", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objDC.SetParameterValue("VillAreaRoad", dtShopStatic.Rows[0]["VillAreaRoad"].ToString());
                        objDC.SetParameterValue("Post", dtShopStatic.Rows[0]["Post"].ToString());
                        objDC.SetParameterValue("District", dtShopStatic.Rows[0]["District"].ToString());
                    }
                    else
                    {
                        objDC.SetParameterValue("ReportName", "Delivery Challan");
                        objDC.SetParameterValue("printedby", Page.User.Identity.Name);
                        objDC.SetParameterValue("ShopName", "");
                        objDC.SetParameterValue("VillAreaRoad", "");
                        objDC.SetParameterValue("Post", "");
                        objDC.SetParameterValue("District", "");
                    }

                    rptViewer.ReportSource = objDC;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region DeliveryShopTemp
                case "DeliveryShopTemp":
                    lblrptHeader.Text = "Delivery Challan (Draft)";
                    DeliveryToShop objDCT = new DeliveryToShop();
                    objDCT.SetDataSource(dtDeliveryShopTemp);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objDCT.SetParameterValue("ReportName", "Delivery Challan (Draft)");
                        objDCT.SetParameterValue("printedby", Page.User.Identity.Name);
                        objDCT.SetParameterValue("ShopName", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objDCT.SetParameterValue("VillAreaRoad", dtShopStatic.Rows[0]["VillAreaRoad"].ToString());
                        objDCT.SetParameterValue("Post", dtShopStatic.Rows[0]["Post"].ToString());
                        objDCT.SetParameterValue("District", dtShopStatic.Rows[0]["District"].ToString());
                    }
                    else
                    {
                        objDCT.SetParameterValue("ReportName", "Delivery Challan (Draft)");
                        objDCT.SetParameterValue("printedby", Page.User.Identity.Name);
                        objDCT.SetParameterValue("ShopName", "");
                        objDCT.SetParameterValue("VillAreaRoad", "");
                        objDCT.SetParameterValue("Post", "");
                        objDCT.SetParameterValue("District", "");
                    }

                    rptViewer.ReportSource = objDCT;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region ShopRequisition
                case "ShopRequisition":
                    lblrptHeader.Text = "Shop Requisition";
                    rptBuyRequisition objSR = new rptBuyRequisition();
                    objSR.SetDataSource(dtShopRequisition);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objSR.SetParameterValue("ReportName", "Shop Requisition");
                        objSR.SetParameterValue("printedby", Page.User.Identity.Name);
                        objSR.SetParameterValue("ShopName", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objSR.SetParameterValue("VillAreaRoad", dtShopStatic.Rows[0]["VillAreaRoad"].ToString());
                        objSR.SetParameterValue("Post", dtShopStatic.Rows[0]["Post"].ToString());
                        objSR.SetParameterValue("District", dtShopStatic.Rows[0]["District"].ToString());
                    }
                    else
                    {
                        objSR.SetParameterValue("ReportName", "Shop Requisition");
                        objSR.SetParameterValue("printedby", Page.User.Identity.Name);
                        objSR.SetParameterValue("ShopName", "");
                        objSR.SetParameterValue("VillAreaRoad", "");
                        objSR.SetParameterValue("Post", "");
                        objSR.SetParameterValue("District", "");
                    }

                    rptViewer.ReportSource = objSR;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region ShopRequisitionApproval
                case "ShopRequisitionApproval":
                    lblrptHeader.Text = "Shop Requisition Approval";
                    rptApprovedRequisition objSRA = new rptApprovedRequisition();
                    objSRA.SetDataSource(dtShopRequisitionApproval);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objSRA.SetParameterValue("printedby", Page.User.Identity.Name);
                        objSRA.SetParameterValue("ShopName", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objSRA.SetParameterValue("VillAreaRoad", dtShopStatic.Rows[0]["VillAreaRoad"].ToString());
                        objSRA.SetParameterValue("Post", dtShopStatic.Rows[0]["Post"].ToString());
                        objSRA.SetParameterValue("District", dtShopStatic.Rows[0]["District"].ToString());
                    }
                    else
                    {
                        objSRA.SetParameterValue("printedby", Page.User.Identity.Name);
                        objSRA.SetParameterValue("ShopName", "");
                        objSRA.SetParameterValue("VillAreaRoad", "");
                        objSRA.SetParameterValue("Post", "");
                        objSRA.SetParameterValue("District", "");
                    }

                    rptViewer.ReportSource = objSRA;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region Shop DeliveryReceive
                case "DeliveryReceive":
                    lblrptHeader.Text = "Shop Item Receive";
                    rptDeliveryReceive objSDR = new rptDeliveryReceive();
                    objSDR.SetDataSource(dtShopDeliveryReceive);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objSDR.SetParameterValue("printedby", Page.User.Identity.Name);
                        objSDR.SetParameterValue("reportName", "Shop Item Receive");
                        objSDR.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objSDR.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                    }
                    else
                    {
                        objSDR.SetParameterValue("printedby", Page.User.Identity.Name);
                        objSDR.SetParameterValue("reportName", "Shop Item Receive");
                        objSDR.SetParameterValue("shopname", "");
                        objSDR.SetParameterValue("address", "");
                    }
                    rptViewer.ReportSource = objSDR;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region Shop DeliveryReceiveDraft
                case "DeliveryReceiveDraft":
                    lblrptHeader.Text = "Shop Item Receive (Draft)";
                    rptDeliveryReceive objSDRT = new rptDeliveryReceive();
                    objSDRT.SetDataSource(dtShopDeliveryReceiveDraft);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objSDRT.SetParameterValue("printedby", Page.User.Identity.Name);
                        objSDRT.SetParameterValue("reportName", "Shop Delivery Item (Draft)");
                        objSDRT.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objSDRT.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                    }
                    else
                    {
                        objSDRT.SetParameterValue("printedby", Page.User.Identity.Name);
                        objSDRT.SetParameterValue("reportName", "Shop Delivery Item (Draft)");
                        objSDRT.SetParameterValue("shopname", "");
                        objSDRT.SetParameterValue("address", "");
                    }
                    rptViewer.ReportSource = objSDRT;
                    rptViewer.DataBind();
                    break;

                #endregion

                #region Stock return Report
                case "StockReturnReport":
                    lblrptHeader.Text = "Stock Return Report";
                    rptStockReturn objsrR = new rptStockReturn();
                    objsrR.SetDataSource(dtStockReturn);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objsrR.SetParameterValue("printedby", Page.User.Identity.Name);
                        objsrR.SetParameterValue("reportName", "Stock Return Report");
                        objsrR.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objsrR.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                    }
                    else
                    {
                        objsrR.SetParameterValue("printedby", Page.User.Identity.Name);
                        objsrR.SetParameterValue("reportName", "Stock Return Report");
                        objsrR.SetParameterValue("shopname", "");
                        objsrR.SetParameterValue("address", "");
                    }
                    rptViewer.ReportSource = objsrR;
                    rptViewer.DataBind();
                    break;

                #endregion

                #region Stock Return Temp
                case "StockReturnReportTemp":
                    lblrptHeader.Text = "Stock Return Report Temp";
                    DataTable dtsrRT = new ReportDbSource().StockReturnTemp_GetList();
                    rptStockReturn objsrRT = new rptStockReturn();
                    objsrRT.SetDataSource(dtStockReturnDraft);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objsrRT.SetParameterValue("printedby", Page.User.Identity.Name);
                        objsrRT.SetParameterValue("reportName", "Stock Return Report (Draft)");
                        objsrRT.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objsrRT.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                    }
                    else
                    {
                        objsrRT.SetParameterValue("printedby", Page.User.Identity.Name);
                        objsrRT.SetParameterValue("reportName", "Stock Return Report (Draft)");
                        objsrRT.SetParameterValue("shopname", "");
                        objsrRT.SetParameterValue("address", "");
                    }
                    rptViewer.ReportSource = objsrRT;
                    rptViewer.DataBind();
                    break;

                #endregion

                #region Stock DML
                case "StockDML":
                    lblrptHeader.Text = "Stock DML";
                    rptStockDML objDML = new rptStockDML();
                    objDML.SetDataSource(dtStockDML);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objDML.SetParameterValue("printedby", Page.User.Identity.Name);
                        objDML.SetParameterValue("reportName", "Stock Damaged and Lost");
                        objDML.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objDML.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                    }
                    else
                    {
                        objDML.SetParameterValue("printedby", Page.User.Identity.Name);
                        objDML.SetParameterValue("reportName", "Stock Damaged and Lost");
                        objDML.SetParameterValue("shopname", "");
                        objDML.SetParameterValue("address", "");
                    }
                    rptViewer.ReportSource = objDML;
                    rptViewer.DataBind();
                    break;

                #endregion

                #region Stock DML Draft
                case "StockDMLTemp":
                    lblrptHeader.Text = "Stock DML (Draft)";
                    rptStockDML objDMLT = new rptStockDML();
                    objDMLT.SetDataSource(dtStockDMLDraft);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objDMLT.SetParameterValue("printedby", Page.User.Identity.Name);
                        objDMLT.SetParameterValue("reportName", "Stock Damaged and Lost (Draft)");
                        objDMLT.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objDMLT.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                    }
                    else
                    {
                        objDMLT.SetParameterValue("printedby", Page.User.Identity.Name);
                        objDMLT.SetParameterValue("reportName", "Stock Damaged and Lost (Draft)");
                        objDMLT.SetParameterValue("shopname", "");
                        objDMLT.SetParameterValue("address", "");
                    }
                    rptViewer.ReportSource = objDMLT;
                    rptViewer.DataBind();
                    break;

                #endregion

                #region Shop Stock Return
                case "StockReturnShop":
                    lblrptHeader.Text = "Shop Stock Return";
                    rptStockReturnShop objSRS = new rptStockReturnShop();
                    objSRS.SetDataSource(dtStockReturnShop);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objSRS.SetParameterValue("printedby", Page.User.Identity.Name);
                        objSRS.SetParameterValue("reportName", "Shop Stock Return");
                        objSRS.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objSRS.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                    }
                    else
                    {
                        objSRS.SetParameterValue("printedby", Page.User.Identity.Name);
                        objSRS.SetParameterValue("reportName", "Shop Stock Return");
                        objSRS.SetParameterValue("shopname", "");
                        objSRS.SetParameterValue("address", "");
                    }
                    rptViewer.ReportSource = objSRS;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region Shop Stock Return Temp
                case "StockReturnShopTemp":
                    lblrptHeader.Text = "Shop Stock Return  (Draft)";
                    rptStockReturnShop objSRST = new rptStockReturnShop();
                    objSRST.SetDataSource(dtStockReturnShopDraft);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objSRST.SetParameterValue("printedby", Page.User.Identity.Name);
                        objSRST.SetParameterValue("reportName", "Shop Stock Return (Draft)");
                        objSRST.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objSRST.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                    }
                    else
                    {
                        objSRST.SetParameterValue("printedby", Page.User.Identity.Name);
                        objSRST.SetParameterValue("reportName", "Shop Stock Return (Draft)");
                        objSRST.SetParameterValue("shopname", "");
                        objSRST.SetParameterValue("address", "");
                    }
                    rptViewer.ReportSource = objSRST;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region Package Setup
                case "PackageSetup":
                    lblrptHeader.Text = "Package Setup";
                    rptPackageSetup objPS = new rptPackageSetup();
                    objPS.SetDataSource(dtPackageSetup);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objPS.SetParameterValue("printedby", Page.User.Identity.Name);
                        objPS.SetParameterValue("reportName", "Package");
                        objPS.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objPS.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                    }
                    else
                    {
                        objPS.SetParameterValue("printedby", Page.User.Identity.Name);
                        objPS.SetParameterValue("reportName", "Package");
                        objPS.SetParameterValue("shopname", "");
                        objPS.SetParameterValue("address", "");
                    }
                    rptViewer.ReportSource = objPS;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region Package Issue
                case "PackageIssue":
                    lblrptHeader.Text = "Package Issue";
                    rptPackageIssue objPI = new rptPackageIssue();
                    objPI.SetDataSource(dtPackageIssue);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objPI.SetParameterValue("printedby", Page.User.Identity.Name);
                        objPI.SetParameterValue("reportName", "Package Issue");
                        objPI.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objPI.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                    }
                    else
                    {
                        objPI.SetParameterValue("printedby", Page.User.Identity.Name);
                        objPI.SetParameterValue("reportName", "Package Issue");
                        objPI.SetParameterValue("shopname", "");
                        objPI.SetParameterValue("address", "");
                    }
                    rptViewer.ReportSource = objPI;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region Discount Circular
                case "DiscountCircular":
                    lblrptHeader.Text = "Discount Circular";
                    rptDiscountCircular objDisC = new rptDiscountCircular();
                    objDisC.SetDataSource(dtDiscountCircular);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objDisC.SetParameterValue("printedby", Page.User.Identity.Name);
                        objDisC.SetParameterValue("reportName", "Discount Circular");
                        objDisC.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objDisC.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                    }
                    else
                    {
                        objDisC.SetParameterValue("printedby", Page.User.Identity.Name);
                        objDisC.SetParameterValue("reportName", "Discount Circular");
                        objDisC.SetParameterValue("shopname", "");
                        objDisC.SetParameterValue("address", "");
                    }
                    rptViewer.ReportSource = objDisC;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region Price Changed Circular
                case "PriceChangedCircular":
                    lblrptHeader.Text = "Price Changed Circular";
                    rptPriceChangedCircular objCPC = new rptPriceChangedCircular();
                    objCPC.SetDataSource(dtPriceChangedCircular);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objCPC.SetParameterValue("printedby", Page.User.Identity.Name);
                        objCPC.SetParameterValue("reportName", "Price Changed Circular");
                        objCPC.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objCPC.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                    }
                    else
                    {
                        objCPC.SetParameterValue("printedby", Page.User.Identity.Name);
                        objCPC.SetParameterValue("reportName", "Price Changed Circular");
                        objCPC.SetParameterValue("shopname", "");
                        objCPC.SetParameterValue("address", "");
                    }
                    rptViewer.ReportSource = objCPC;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region Pay Less Create
                case "PayLessCreate":

                    if (Request.QueryString["PayLessNo"] == null)
                        return;

                    lblrptHeader.Text = "Pay Less Create";
                    rptPayLess objPayLess = new rptPayLess();
                    objPayLess.SetDataSource(dtPayLessCreate);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objPayLess.SetParameterValue("printedby", Page.User.Identity.Name);
                        objPayLess.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objPayLess.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                    }
                    else
                    {
                        objPayLess.SetParameterValue("printedby", Page.User.Identity.Name);
                        objPayLess.SetParameterValue("shopname", "");
                        objPayLess.SetParameterValue("address", "");
                    }
                    rptViewer.ReportSource = objPayLess;
                    rptViewer.DataBind();
                    break;
                #endregion

                #region Package Issue Receive
                case "PackageIssueReceive":

                    if (Request.QueryString["PIssueNo"] == null)
                        return;

                    lblrptHeader.Text = "Package Issue Receive";
                    rptPackageIssue objPIssueNo = new rptPackageIssue();
                    objPIssueNo.SetDataSource(dtPackageIssueReceive);
                    if (dtShopStatic.Rows.Count > 0)
                    {
                        objPIssueNo.SetParameterValue("printedby", Page.User.Identity.Name);
                        objPIssueNo.SetParameterValue("reportName", "Package Issue");
                        objPIssueNo.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                        objPIssueNo.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                    }
                    else
                    {
                        objPIssueNo.SetParameterValue("printedby", Page.User.Identity.Name);
                        objPIssueNo.SetParameterValue("reportName", "Package Issue");
                        objPIssueNo.SetParameterValue("shopname", "");
                        objPIssueNo.SetParameterValue("address", "");
                    }
                    rptViewer.ReportSource = objPIssueNo;
                    rptViewer.DataBind();
                    break;
                #endregion
            }
        }
        private LogedInInfo GetLogedInInfo()
        {
            LogedInInfo info = new LogedInInfo();
            if (Request.Cookies["POSLogedInInfo"] != null)
            {
                var value = Request.Cookies["POSLogedInInfo"].Value;
                info = Newtonsoft.Json.JsonConvert.DeserializeObject<LogedInInfo>(value) as LogedInInfo;
            }
            return info;
        }
    }
}