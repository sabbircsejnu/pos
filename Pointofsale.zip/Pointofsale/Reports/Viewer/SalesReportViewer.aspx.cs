﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using RetailMaster.POS.Service;
using RetailMaster.POS.Web.BLL;
using RetailMaster.POS.Web.Models;
using RetailMaster.POS.Web.Reports.Sales;
using RetailMaster.POS.Web.Reports.Setup;
using RetailMaster.POS.Web.Reports.Stock;
using RetailMaster.POS.Web.ViewModels;
using RetailMaster.POS.Web.ReportsClass;

namespace RetailMaster.POS.Web.Reports.Viewer
{
    public partial class SalesReportViewer : System.Web.UI.Page
    {
        private static string strdvCriteria = string.Empty;
        private static DataTable dtShopStatic;
        private static DataTable dtDailySalesReport;
        private static DataTable dtItemSalesReport;
        private static DataTable dtItemWiseSales;
        public static DataTable dtSalesStockReport;
        public static DataTable dtSalesFromStockPrcn;
        public static DataTable dtSupplierWiseGPPrcn;
        public static DataTable dtSupplierWiseSalesPrcn;
        public static DataTable dtInvoiceWiseSalesSummary;
        public static DataTable dtInvoiceWiseSalesDetails;
        public static DataTable dtGroupWiseSales;
        public static DataTable dtCashierWiseSales;
        public static DataTable dtCounterWiseSales;
        public static DataTable dtSales;
        public static DataTable dtCreditCollectin;
        protected void Page_Init(object sender, EventArgs e)
        {
            if (Request.QueryString["ShopID"] != null)
            {
                String LoginShopID = GetLogedInInfo().ShopID;
                // if shop user try to see the cs report
                string ShopID = Request.QueryString["ShopID"].ToString();
                if (ShopID == "All") ShopID = "9999";
                if (LoginShopID != "9999" && LoginShopID != ShopID)
                {
                    return;
                }
            }

            if (!IsPostBack)
            {
                BindReport();
            }
            else
            {
                BindReportWhenPostBack();
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        private void BindReport()
        {
            try
            {
                if (Request.QueryString["ReportName"] == null)
                    return;

                string ShopID = "";
                string sDate = "";
                string eDate = "";
                switch (Request.QueryString["ReportName"])
                {
                    #region Shop Wise Daily Sales
                    case "ShopWiseDailySales":
                        if (Request.QueryString["ShopID"] == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;
                        if (Request.QueryString["ShopID"].ToString() !="All")
                            dtShopStatic = new ReportDbSource().GetByShopName(Request.QueryString["ShopID"].ToString());
                        else
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");

                        rptDailySalesReport rpt = new rptDailySalesReport();

                        string ssDate = Request.QueryString["sDate"].ToString();
                        string lastDayOfMonth = Request.QueryString["eDate"].ToString();

                        string firstDayOfMonth = new DateTime(Convert.ToDateTime(ssDate).Year, Convert.ToDateTime(ssDate).Month, 1).ToShortDateString();

                        int year = Convert.ToDateTime(ssDate).Year;
                        string FirstDateofyear = new DateTime(year, 1, 1).ToShortDateString();

                        //string monthFromDate, string monthToDate, string yearFromDate, string YearToDate
                        //'11/1/2015','11/23/2015','1/1/2015','11/23/2015' 

                        DataTable dt = new ReportDbSource().rptDailySalesReport(firstDayOfMonth, lastDayOfMonth, FirstDateofyear, lastDayOfMonth);
                        dtDailySalesReport = dt;
                        rpt.SetDataSource(dt);
                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rpt.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rpt.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rpt.SetParameterValue("shopname", "");
                            rpt.SetParameterValue("address", "");
                        }
                        rptViewer.ReportSource = rpt;
                        rptViewer.DataBind();

                        break;
                    #endregion

                    #region Shop Wise Item Sales
                    case "ShopWiseItemSales":
                        if (Request.QueryString["ShopID"] == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        ShopID = Request.QueryString["ShopID"].ToString();
                        if (ShopID != "All")
                            dtShopStatic = new ReportDbSource().GetByShopName(ShopID);
                        else
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");

                        rptShopSupplierItemSalesReport rptItemSales = new rptShopSupplierItemSalesReport();

                         sDate = Request.QueryString["sDate"].ToString();
                         eDate = Request.QueryString["eDate"].ToString();

                         DataTable dtItemSales = new ReportDbSource().rptSalesShopSupItem(sDate, eDate, Request.QueryString["ShopID"].ToString(), Request.QueryString["BTID"].ToString(), Request.QueryString["GroupID"].ToString(), Request.QueryString["PrdID"].ToString(), Request.QueryString["SSID"].ToString(), Request.QueryString["SupID"].ToString());
                        dtItemSalesReport = dtItemSales;
                        rptItemSales.SetDataSource(dtItemSales);
                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptItemSales.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptItemSales.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            rptItemSales.SetParameterValue("@FromDate", sDate);
                            rptItemSales.SetParameterValue("@ToDate", eDate);
                        }
                        else
                        {
                            rptItemSales.SetParameterValue("shopname", "");
                            rptItemSales.SetParameterValue("address", "");
                            rptItemSales.SetParameterValue("@FromDate", "");
                            rptItemSales.SetParameterValue("@ToDate", "");
                        }
                        rptViewer.ReportSource = rptItemSales;
                        rptViewer.DataBind();

                        break;
                    #endregion

                    #region Item Wise Sales
                    case "ItemWiseSales":
                        if (Request.QueryString["ShopID"] == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        ShopID = Request.QueryString["ShopID"].ToString();
                        if (ShopID != "All")
                            dtShopStatic = new ReportDbSource().GetByShopName(ShopID);
                        else
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");

                        rptItemWiseSalesReport rptItemWiseSales = new rptItemWiseSalesReport();

                        sDate = Request.QueryString["sDate"].ToString();
                        eDate = Request.QueryString["eDate"].ToString();

                        DataTable ItemWiseSales = new ReportDbSource().rptSalesItemWise(sDate, eDate, Request.QueryString["ShopID"].ToString(), Request.QueryString["BTID"].ToString(), Request.QueryString["GroupID"].ToString(), Request.QueryString["PrdID"].ToString(), Request.QueryString["SSID"].ToString(), Request.QueryString["SupID"].ToString());
                        dtItemWiseSales = ItemWiseSales;
                        rptItemWiseSales.SetDataSource(ItemWiseSales);
                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptItemWiseSales.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptItemWiseSales.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            rptItemWiseSales.SetParameterValue("@FromDate", sDate);
                            rptItemWiseSales.SetParameterValue("@ToDate", eDate);
                        }
                        else
                        {
                            rptItemWiseSales.SetParameterValue("shopname", "");
                            rptItemWiseSales.SetParameterValue("address", "");
                            rptItemWiseSales.SetParameterValue("@FromDate", "");
                            rptItemWiseSales.SetParameterValue("@ToDate", "");
                        }
                        rptViewer.ReportSource = rptItemWiseSales;
                        rptViewer.DataBind();

                        break;
                    #endregion

                    #region Sales Stock Report
                    case "SalesStockReport":
                        if (Request.QueryString["ShopID"] == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        ShopID = Request.QueryString["ShopID"].ToString();
                        if (ShopID != "All")
                            dtShopStatic = new ReportDbSource().GetByShopName(ShopID);
                        else
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");

                        rptSalesStock rptSalesStock = new rptSalesStock();

                        sDate = Request.QueryString["sDate"].ToString();
                        eDate = Request.QueryString["eDate"].ToString();

                        DataTable dtSalesStock = new ReportDbSource().rptSalesStockReport(sDate, eDate, Request.QueryString["ShopID"].ToString(), Request.QueryString["BTID"].ToString(), Request.QueryString["GroupID"].ToString(), Request.QueryString["PrdID"].ToString(), Request.QueryString["SSID"].ToString(), Request.QueryString["SupID"].ToString());
                        dtSalesStockReport = dtSalesStock;
                        rptSalesStock.SetDataSource(dtSalesStock);
                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptSalesStock.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptSalesStock.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            rptSalesStock.SetParameterValue("@FromDate", sDate);
                            rptSalesStock.SetParameterValue("@ToDate", eDate);
                        }
                        else
                        {
                            rptSalesStock.SetParameterValue("shopname", "");
                            rptSalesStock.SetParameterValue("address", "");
                            rptSalesStock.SetParameterValue("@FromDate", "");
                            rptSalesStock.SetParameterValue("@ToDate", "");
                        }
                        rptViewer.ReportSource = rptSalesStock;
                        rptViewer.DataBind();

                        break;
                    #endregion

                    #region Sales From Stock Prcn
                    case "SalesFromStockPrcn":
                        if (Request.QueryString["ShopID"] == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        ShopID = Request.QueryString["ShopID"].ToString();
                        if (ShopID != "All")
                            dtShopStatic = new ReportDbSource().GetByShopName(ShopID);
                        else
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");

                        rptSalesFromStockPerc rptSalesFromStockPrcn = new rptSalesFromStockPerc();

                        sDate = Request.QueryString["sDate"].ToString();
                        eDate = Request.QueryString["eDate"].ToString();

                        DataTable dtSalesFromStock = new ReportDbSource().rptSalesFromStockPercent(sDate, eDate, Request.QueryString["ShopID"].ToString(), Request.QueryString["BTID"].ToString(), Request.QueryString["GroupID"].ToString(), Request.QueryString["PrdID"].ToString(), Request.QueryString["SSID"].ToString(), Request.QueryString["SupID"].ToString());
                        dtSalesFromStockPrcn = dtSalesFromStock;
                        rptSalesFromStockPrcn.SetDataSource(dtSalesFromStock);
                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptSalesFromStockPrcn.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptSalesFromStockPrcn.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            rptSalesFromStockPrcn.SetParameterValue("@FromDate", sDate);
                            rptSalesFromStockPrcn.SetParameterValue("@ToDate", eDate);
                        }
                        else
                        {
                            rptSalesFromStockPrcn.SetParameterValue("shopname", "");
                            rptSalesFromStockPrcn.SetParameterValue("address", "");
                            rptSalesFromStockPrcn.SetParameterValue("@FromDate", "");
                            rptSalesFromStockPrcn.SetParameterValue("@ToDate", "");
                        }
                        rptViewer.ReportSource = rptSalesFromStockPrcn;
                        rptViewer.DataBind();

                        break;
                    #endregion

                    #region Supplier Wise GP Prcn
                    case "SupplierWiseGPPrcn":
                        if (Request.QueryString["ShopID"] == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        ShopID = Request.QueryString["ShopID"].ToString();
                        if (ShopID != "All")
                            dtShopStatic = new ReportDbSource().GetByShopName(ShopID);
                        else
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");

                        rptSupplierWiseGP rptSupplierWiseGPPrcn = new rptSupplierWiseGP();

                        sDate = Request.QueryString["sDate"].ToString();
                        eDate = Request.QueryString["eDate"].ToString();

                        DataTable SupplierWiseGPPrcn = new ReportDbSource().rptSalesSupplierGP(sDate, eDate, Request.QueryString["ShopID"].ToString(), Request.QueryString["BTID"].ToString(), Request.QueryString["GroupID"].ToString(), Request.QueryString["PrdID"].ToString(), Request.QueryString["SSID"].ToString(), Request.QueryString["SupID"].ToString());
                        dtSupplierWiseGPPrcn = SupplierWiseGPPrcn;
                        rptSupplierWiseGPPrcn.SetDataSource(SupplierWiseGPPrcn);
                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptSupplierWiseGPPrcn.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptSupplierWiseGPPrcn.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            rptSupplierWiseGPPrcn.SetParameterValue("@FromDate", sDate);
                            rptSupplierWiseGPPrcn.SetParameterValue("@ToDate", eDate);
                        }
                        else
                        {
                            rptSupplierWiseGPPrcn.SetParameterValue("shopname", "");
                            rptSupplierWiseGPPrcn.SetParameterValue("address", "");
                            rptSupplierWiseGPPrcn.SetParameterValue("@FromDate", "");
                            rptSupplierWiseGPPrcn.SetParameterValue("@ToDate", "");
                        }
                        rptViewer.ReportSource = rptSupplierWiseGPPrcn;
                        rptViewer.DataBind();

                        break;
                    #endregion

                    #region Supplier Wise Sales Prcn
                    case "SupplierWiseSalesPrcn":
                        if (Request.QueryString["ShopID"] == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        ShopID = Request.QueryString["ShopID"].ToString();
                        if (ShopID != "All")
                            dtShopStatic = new ReportDbSource().GetByShopName(ShopID);
                        else
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");

                        rptSupplierSalesContribution rptSupplierSalesContribution = new rptSupplierSalesContribution();

                        sDate = Request.QueryString["sDate"].ToString();
                        eDate = Request.QueryString["eDate"].ToString();

                        DataTable SupplierSalesContribution = new ReportDbSource().rptSalesSupplierSalesPercent(sDate, eDate, Request.QueryString["ShopID"].ToString(), Request.QueryString["BTID"].ToString(), Request.QueryString["GroupID"].ToString(), Request.QueryString["PrdID"].ToString(), Request.QueryString["SSID"].ToString(), Request.QueryString["SupID"].ToString());
                        dtSupplierWiseSalesPrcn = SupplierSalesContribution;
                        rptSupplierSalesContribution.SetDataSource(SupplierSalesContribution);
                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptSupplierSalesContribution.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptSupplierSalesContribution.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            rptSupplierSalesContribution.SetParameterValue("@FromDate", sDate);
                            rptSupplierSalesContribution.SetParameterValue("@ToDate", eDate);
                        }
                        else
                        {
                            rptSupplierSalesContribution.SetParameterValue("shopname", "");
                            rptSupplierSalesContribution.SetParameterValue("address", "");
                            rptSupplierSalesContribution.SetParameterValue("@FromDate", "");
                            rptSupplierSalesContribution.SetParameterValue("@ToDate", "");
                        }
                        rptViewer.ReportSource = rptSupplierSalesContribution;
                        rptViewer.DataBind();

                        break;
                    #endregion

                    #region Invoice Wise Sales Summary
                    case "InvoiceWiseSalesSummary":
                        if (Request.QueryString["ShopID"] == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        ShopID = Request.QueryString["ShopID"].ToString();
                        if (ShopID != "All")
                            dtShopStatic = new ReportDbSource().GetByShopName(ShopID);
                        else
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");

                        rptInvoiceWiseSalesSummary objInvoiceWiseSalesSummary = new rptInvoiceWiseSalesSummary();

                        sDate = Request.QueryString["sDate"].ToString();
                        eDate = Request.QueryString["eDate"].ToString();

                        DataTable dtInvoiceWise = new ReportDbSource().rptSalesInvoiceWiseSalesSummary(sDate, eDate, Request.QueryString["ShopID"].ToString(), Request.QueryString["BTID"].ToString(), Request.QueryString["GroupID"].ToString(), Request.QueryString["PrdID"].ToString(), Request.QueryString["SSID"].ToString(), Request.QueryString["SupID"].ToString());
                        dtInvoiceWiseSalesSummary = dtInvoiceWise;
                        objInvoiceWiseSalesSummary.SetDataSource(dtInvoiceWise);
                        if (dtShopStatic.Rows.Count > 0)
                        {
                            objInvoiceWiseSalesSummary.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            objInvoiceWiseSalesSummary.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            objInvoiceWiseSalesSummary.SetParameterValue("@FromDate", sDate);
                            objInvoiceWiseSalesSummary.SetParameterValue("@ToDate", eDate);
                        }
                        else
                        {
                            objInvoiceWiseSalesSummary.SetParameterValue("shopname", "");
                            objInvoiceWiseSalesSummary.SetParameterValue("address", "");
                            objInvoiceWiseSalesSummary.SetParameterValue("@FromDate", "");
                            objInvoiceWiseSalesSummary.SetParameterValue("@ToDate", "");
                        }
                        rptViewer.ReportSource = objInvoiceWiseSalesSummary;
                        rptViewer.DataBind();

                        break;
                    #endregion

                    #region Invoice Wise Sales Details
                    case "InvoiceWiseSalesDetails":
                        if (Request.QueryString["ShopID"] == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        ShopID = Request.QueryString["ShopID"].ToString();
                        if (ShopID != "All")
                            dtShopStatic = new ReportDbSource().GetByShopName(ShopID);
                        else
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");

                        rptInvoiceWiseSalesDetails objInvoiceWiseSalesDetails = new rptInvoiceWiseSalesDetails();

                        sDate = Request.QueryString["sDate"].ToString();
                        eDate = Request.QueryString["eDate"].ToString();

                        DataTable dtInvoiceWiseDetails = new ReportDbSource().rptSalesInvoiceWiseSalesDetails(sDate, eDate, Request.QueryString["ShopID"].ToString(), Request.QueryString["BTID"].ToString(), Request.QueryString["GroupID"].ToString(), Request.QueryString["PrdID"].ToString(), Request.QueryString["SSID"].ToString(), Request.QueryString["SupID"].ToString());
                        dtInvoiceWiseSalesDetails = dtInvoiceWiseDetails;
                        objInvoiceWiseSalesDetails.SetDataSource(dtInvoiceWiseDetails);
                        if (dtShopStatic.Rows.Count > 0)
                        {
                            objInvoiceWiseSalesDetails.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            objInvoiceWiseSalesDetails.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            objInvoiceWiseSalesDetails.SetParameterValue("@FromDate", sDate);
                            objInvoiceWiseSalesDetails.SetParameterValue("@ToDate", eDate);
                        }
                        else
                        {
                            objInvoiceWiseSalesDetails.SetParameterValue("shopname", "");
                            objInvoiceWiseSalesDetails.SetParameterValue("address", "");
                            objInvoiceWiseSalesDetails.SetParameterValue("@FromDate", "");
                            objInvoiceWiseSalesDetails.SetParameterValue("@ToDate", "");
                        }
                        rptViewer.ReportSource = objInvoiceWiseSalesDetails;
                        rptViewer.DataBind();

                        break;
                    #endregion

                    #region Group Wise Sales
                    case "GroupWiseSales":
                        if (Request.QueryString["ShopID"] == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        ShopID = Request.QueryString["ShopID"].ToString();
                        if (ShopID != "All")
                            dtShopStatic = new ReportDbSource().GetByShopName(ShopID);
                        else
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");

                        rptGroupWiseSalesReport objGroupWiseSales = new rptGroupWiseSalesReport();

                        sDate = Request.QueryString["sDate"].ToString();
                        eDate = Request.QueryString["eDate"].ToString();

                        DataTable dtGroupWise = new ReportDbSource().rptSalesGroupWise(sDate, eDate, Request.QueryString["ShopID"].ToString(), Request.QueryString["BTID"].ToString(), Request.QueryString["GroupID"].ToString(), Request.QueryString["PrdID"].ToString(), Request.QueryString["SSID"].ToString(), Request.QueryString["SupID"].ToString());
                        dtGroupWiseSales = dtGroupWise;
                        objGroupWiseSales.SetDataSource(dtGroupWise);
                        if (dtShopStatic.Rows.Count > 0)
                        {
                           objGroupWiseSales.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            objGroupWiseSales.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            objGroupWiseSales.SetParameterValue("@FromDate", sDate);
                            objGroupWiseSales.SetParameterValue("@ToDate", eDate);
                        }
                        else
                        {
                            objGroupWiseSales.SetParameterValue("shopname", "");
                            objGroupWiseSales.SetParameterValue("address", "");
                            objGroupWiseSales.SetParameterValue("@FromDate", "");
                            objGroupWiseSales.SetParameterValue("@ToDate", "");
                        }
                        rptViewer.ReportSource = objGroupWiseSales;
                        rptViewer.DataBind();

                        break;
                    #endregion

                    #region Cashier Wise Sales
                    case "CashierWiseSales":
                        if (Request.QueryString["ShopID"] == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        ShopID = Request.QueryString["ShopID"].ToString();
                        if (ShopID != "All")
                            dtShopStatic = new ReportDbSource().GetByShopName(ShopID);
                        else
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");

                        rptSalesCashierSummary objCashierWiseSales = new rptSalesCashierSummary();

                        sDate = Request.QueryString["sDate"].ToString();
                        eDate = Request.QueryString["eDate"].ToString();

                        DataTable dtCashierWise = new ReportDbSource().rptSalesCasierSummaryReport(sDate, eDate, Request.QueryString["ShopID"].ToString(), Request.QueryString["BTID"].ToString(), Request.QueryString["GroupID"].ToString(), Request.QueryString["PrdID"].ToString(), Request.QueryString["SSID"].ToString(), Request.QueryString["SupID"].ToString());
                        dtCashierWiseSales = dtCashierWise;
                        objCashierWiseSales.SetDataSource(dtCashierWise);
                        if (dtShopStatic.Rows.Count > 0)
                        {
                            objCashierWiseSales.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            objCashierWiseSales.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            objCashierWiseSales.SetParameterValue("@FromDate", sDate);
                            objCashierWiseSales.SetParameterValue("@ToDate", eDate);
                        }
                        else
                        {
                            objCashierWiseSales.SetParameterValue("shopname", "");
                            objCashierWiseSales.SetParameterValue("address", "");
                            objCashierWiseSales.SetParameterValue("@FromDate", "");
                            objCashierWiseSales.SetParameterValue("@ToDate", "");
                        }
                        rptViewer.ReportSource = objCashierWiseSales;
                        rptViewer.DataBind();

                        break;
                    #endregion

                    #region Sales
                    case "Invoice":
                        if (Request.QueryString["InvoiceNo"] == null)
                            return;

                        dtShopStatic = new ReportDbSource().GetByShopName(Request.QueryString["ShopID"]);
                        rptInvoice objSale= new rptInvoice();

                        DataTable dtsaless = new ReportDbSource().rptSalesByInvoiceNo(Request.QueryString["InvoiceNo"]);
                        dtSales = dtsaless;
                        objSale.SetDataSource(dtSales);
                        if (dtShopStatic.Rows.Count > 0)
                        {
                            objSale.SetParameterValue("@ShopName", dtShopStatic.Rows[0]["ShopName"].ToString());
                            objSale.SetParameterValue("@Contact", dtShopStatic.Rows[0]["Contact"].ToString());
                            objSale.SetParameterValue("@Phone", dtShopStatic.Rows[0]["Phone"].ToString());
                            objSale.SetParameterValue("@ShopAddr", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            objSale.SetParameterValue("@ShopName", "");
                            objSale.SetParameterValue("@Contact", "");
                            objSale.SetParameterValue("@Contact", "");
                            objSale.SetParameterValue("@ShopAddr", "");
                        }
                        rptViewer.ReportSource = objSale;
                       rptViewer.DataBind();

                        break;
                    #endregion

                    #region Credit Collection
                    case "CreditCollection":
                        if (Request.QueryString["ID"] == null)
                            return;

                        ShopID = GetLogedInInfo().ShopID;
                        dtShopStatic = new ReportDbSource().GetByShopName(ShopID);

                        rpt_CreditCollection objCreditCol = new rpt_CreditCollection();

                        DataTable dtCreditCol = new ReportDbSource().rptCreditCollection(Request.QueryString["ID"].ToString());
                        dtCreditCollectin = dtCreditCol;
                        objCreditCol.SetDataSource(dtCreditCol);
                        if (dtShopStatic.Rows.Count > 0)
                        {
                            objCreditCol.SetParameterValue("@printedby", Page.User.Identity.Name);
                            objCreditCol.SetParameterValue("@ShopName", dtShopStatic.Rows[0]["ShopName"].ToString());
                            objCreditCol.SetParameterValue("@ShopAddr", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            objCreditCol.SetParameterValue("@printedby", Page.User.Identity.Name);
                            objCreditCol.SetParameterValue("@ShopName", "");
                            objCreditCol.SetParameterValue("@ShopAddr", "");
                        }
                        rptViewer.ReportSource = objCreditCol;
                        rptViewer.DataBind();

                        break;
                    #endregion

                    #region Counter Wise Sales
                    case "CounterWiseSales":
                        if (Request.QueryString["ShopID"] == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null || Request.QueryString["CounterID"].ToString()==null)
                            return;

                        ShopID = Request.QueryString["ShopID"].ToString();
                        if (ShopID != "All")
                            dtShopStatic = new ReportDbSource().GetByShopName(ShopID);
                        else
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");

                        rptSalesCounterSummary objCounterWiseSales = new rptSalesCounterSummary();
                        DataTable dtCounterWise = new ReportDbSource().rptReportSalesCounterSummaryReport(Request.QueryString["sDate"].ToString(), Request.QueryString["eDate"].ToString(), Request.QueryString["ShopID"].ToString(), Request.QueryString["CounterID"].ToString());
                        sDate = Request.QueryString["sDate"].ToString();
                        eDate = Request.QueryString["eDate"].ToString();
                        dtCounterWiseSales = dtCounterWise;
                        objCounterWiseSales.SetDataSource(dtCounterWise);
                        if (dtShopStatic.Rows.Count > 0)
                        {
                            objCounterWiseSales.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            objCounterWiseSales.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            objCounterWiseSales.SetParameterValue("@FromDate", sDate);
                            objCounterWiseSales.SetParameterValue("@ToDate", eDate);
                        }
                        else
                        {
                            objCounterWiseSales.SetParameterValue("shopname", "");
                            objCounterWiseSales.SetParameterValue("address", "");
                            objCounterWiseSales.SetParameterValue("@FromDate", "");
                            objCounterWiseSales.SetParameterValue("@ToDate", "");
                        }
                        rptViewer.ReportSource = objCounterWiseSales;
                        rptViewer.DataBind();

                        break;
                    #endregion
                }
            }
            catch (Exception ex)
            {

            }
        }
        private void BindReportWhenPostBack()
        {
            try
            {
                string ShopID = "";
                switch (Request.QueryString["ReportName"])
                {
                    #region Shop Wise Daily Sales
                    case "ShopWiseDailySales":
                        if (Request.QueryString["ShopID"] == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        ShopID = Request.QueryString["ShopID"].ToString();
                        if (ShopID != "All")
                            dtShopStatic = new ReportDbSource().GetByShopName(ShopID);
                        else
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");

                        rptDailySalesReport rpt = new rptDailySalesReport();
                        rpt.SetDataSource(dtDailySalesReport);
                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rpt.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rpt.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            rpt.SetParameterValue("shopname", "");
                            rpt.SetParameterValue("address", "");
                        }
                        rptViewer.ReportSource = rpt;
                        rptViewer.DataBind();

                        break;
                    #endregion

                    #region Shop Wise Item Sales
                    case "ShopWiseItemSales":
                        if (Request.QueryString["ShopID"] == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;
                       
                        ShopID = Request.QueryString["ShopID"].ToString();
                        if (ShopID != "All")
                            dtShopStatic = new ReportDbSource().GetByShopName(ShopID);
                        else
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");

                         rptShopSupplierItemSalesReport rptItemSales = new rptShopSupplierItemSalesReport();

                        string sDate = Request.QueryString["sDate"].ToString();
                        string eDate = Request.QueryString["eDate"].ToString();
                        rptItemSales.SetDataSource(dtItemSalesReport);
                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptItemSales.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptItemSales.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            rptItemSales.SetParameterValue("@FromDate", sDate);
                            rptItemSales.SetParameterValue("@ToDate", eDate);
                        }
                        else
                        {
                            rptItemSales.SetParameterValue("shopname", "");
                            rptItemSales.SetParameterValue("address", "");
                            rptItemSales.SetParameterValue("@FromDate", "");
                            rptItemSales.SetParameterValue("@ToDate", "");
                        }
                        rptViewer.ReportSource = rptItemSales;
                        rptViewer.DataBind();

                        break;
                    #endregion

                    #region Item Wise Sales
                    case "ItemWiseSales":
                        if (Request.QueryString["ShopID"] == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        ShopID = Request.QueryString["ShopID"].ToString();
                        if (ShopID != "All")
                            dtShopStatic = new ReportDbSource().GetByShopName(ShopID);
                        else
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");

                        rptItemWiseSalesReport rptItemWiseSales = new rptItemWiseSalesReport();

                        sDate = Request.QueryString["sDate"].ToString();
                        eDate = Request.QueryString["eDate"].ToString();

                        rptItemWiseSales.SetDataSource(dtItemWiseSales);
                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptItemWiseSales.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptItemWiseSales.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            rptItemWiseSales.SetParameterValue("@FromDate", sDate);
                            rptItemWiseSales.SetParameterValue("@ToDate", eDate);
                        }
                        else
                        {
                            rptItemWiseSales.SetParameterValue("shopname", "");
                            rptItemWiseSales.SetParameterValue("address", "");
                            rptItemWiseSales.SetParameterValue("@FromDate", "");
                            rptItemWiseSales.SetParameterValue("@ToDate", "");
                        }
                        rptViewer.ReportSource = rptItemWiseSales;
                        rptViewer.DataBind();

                        break;
                    #endregion

                    #region Sales Stock Report
                    case "SalesStockReport":
                        if (Request.QueryString["ShopID"] == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        ShopID = Request.QueryString["ShopID"].ToString();
                        if (ShopID != "All")
                            dtShopStatic = new ReportDbSource().GetByShopName(ShopID);
                        else
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");

                        rptSalesStock rptSalesStock = new rptSalesStock();

                        sDate = Request.QueryString["sDate"].ToString();
                        eDate = Request.QueryString["eDate"].ToString();

                        rptSalesStock.SetDataSource(dtSalesStockReport);
                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptSalesStock.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptSalesStock.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            rptSalesStock.SetParameterValue("@FromDate", sDate);
                            rptSalesStock.SetParameterValue("@ToDate", eDate);
                        }
                        else
                        {
                            rptSalesStock.SetParameterValue("shopname", "");
                            rptSalesStock.SetParameterValue("address", "");
                            rptSalesStock.SetParameterValue("@FromDate", "");
                            rptSalesStock.SetParameterValue("@ToDate", "");
                        }
                        rptViewer.ReportSource = rptSalesStock;
                        rptViewer.DataBind();

                        break;
                    #endregion

                    #region Sales From Stock Prcn
                    case "SalesFromStockPrcn":
                        if (Request.QueryString["ShopID"] == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        ShopID = Request.QueryString["ShopID"].ToString();
                        if (ShopID != "All")
                            dtShopStatic = new ReportDbSource().GetByShopName(ShopID);
                        else
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");

                        rptSalesFromStockPerc rptSalesFromStockPrcn = new rptSalesFromStockPerc();

                        sDate = Request.QueryString["sDate"].ToString();
                        eDate = Request.QueryString["eDate"].ToString();

                        rptSalesFromStockPrcn.SetDataSource(dtSalesFromStockPrcn);
                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptSalesFromStockPrcn.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptSalesFromStockPrcn.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            rptSalesFromStockPrcn.SetParameterValue("@FromDate", sDate);
                            rptSalesFromStockPrcn.SetParameterValue("@ToDate", eDate);
                        }
                        else
                        {
                            rptSalesFromStockPrcn.SetParameterValue("shopname", "");
                            rptSalesFromStockPrcn.SetParameterValue("address", "");
                            rptSalesFromStockPrcn.SetParameterValue("@FromDate", "");
                            rptSalesFromStockPrcn.SetParameterValue("@ToDate", "");
                        }
                        rptViewer.ReportSource = rptSalesFromStockPrcn;
                        rptViewer.DataBind();

                        break;
                    #endregion

                    #region Supplier Wise GP Prcn
                    case "SupplierWiseGPPrcn":
                        if (Request.QueryString["ShopID"] == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        ShopID = Request.QueryString["ShopID"].ToString();
                        if (ShopID != "All")
                            dtShopStatic = new ReportDbSource().GetByShopName(ShopID);
                        else
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");

                        rptSupplierWiseGP rptSupplierWiseGPPrcn = new rptSupplierWiseGP();

                        sDate = Request.QueryString["sDate"].ToString();
                        eDate = Request.QueryString["eDate"].ToString();

                        rptSupplierWiseGPPrcn.SetDataSource(dtSupplierWiseGPPrcn);
                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptSupplierWiseGPPrcn.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptSupplierWiseGPPrcn.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            rptSupplierWiseGPPrcn.SetParameterValue("@FromDate", sDate);
                            rptSupplierWiseGPPrcn.SetParameterValue("@ToDate", eDate);
                        }
                        else
                        {
                            rptSupplierWiseGPPrcn.SetParameterValue("shopname", "");
                            rptSupplierWiseGPPrcn.SetParameterValue("address", "");
                            rptSupplierWiseGPPrcn.SetParameterValue("@FromDate", "");
                            rptSupplierWiseGPPrcn.SetParameterValue("@ToDate", "");
                        }
                        rptViewer.ReportSource = rptSupplierWiseGPPrcn;
                        rptViewer.DataBind();

                        break;
                    #endregion

                    #region Supplier Wise Sales Prcn
                    case "SupplierWiseSalesPrcn":
                        if (Request.QueryString["ShopID"] == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        ShopID = Request.QueryString["ShopID"].ToString();
                        if (ShopID != "All")
                            dtShopStatic = new ReportDbSource().GetByShopName(ShopID);
                        else
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");

                        rptSupplierSalesContribution rptSupplierSalesContribution = new rptSupplierSalesContribution();

                        sDate = Request.QueryString["sDate"].ToString();
                        eDate = Request.QueryString["eDate"].ToString();

                        rptSupplierSalesContribution.SetDataSource(dtSupplierWiseSalesPrcn);
                        if (dtShopStatic.Rows.Count > 0)
                        {
                            rptSupplierSalesContribution.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            rptSupplierSalesContribution.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            rptSupplierSalesContribution.SetParameterValue("@FromDate", sDate);
                            rptSupplierSalesContribution.SetParameterValue("@ToDate", eDate);
                        }
                        else
                        {
                            rptSupplierSalesContribution.SetParameterValue("shopname", "");
                            rptSupplierSalesContribution.SetParameterValue("address", "");
                            rptSupplierSalesContribution.SetParameterValue("@FromDate", "");
                            rptSupplierSalesContribution.SetParameterValue("@ToDate", "");
                        }
                        rptViewer.ReportSource = rptSupplierSalesContribution;
                        rptViewer.DataBind();

                        break;
                    #endregion

                    #region Invoice Wise Sales Summary
                    case "InvoiceWiseSalesSummary":
                        if (Request.QueryString["ShopID"] == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        ShopID = Request.QueryString["ShopID"].ToString();
                        if (ShopID != "All")
                            dtShopStatic = new ReportDbSource().GetByShopName(ShopID);
                        else
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");

                        rptInvoiceWiseSalesSummary objInvoiceWiseSalesSummary = new rptInvoiceWiseSalesSummary();

                        sDate = Request.QueryString["sDate"].ToString();
                        eDate = Request.QueryString["eDate"].ToString();
                        objInvoiceWiseSalesSummary.SetDataSource(dtInvoiceWiseSalesSummary);
                        if (dtShopStatic.Rows.Count > 0)
                        {
                           objInvoiceWiseSalesSummary.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            objInvoiceWiseSalesSummary.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            objInvoiceWiseSalesSummary.SetParameterValue("@FromDate", sDate);
                            objInvoiceWiseSalesSummary.SetParameterValue("@ToDate", eDate);
                        }
                        else
                        {
                            objInvoiceWiseSalesSummary.SetParameterValue("shopname", "");
                            objInvoiceWiseSalesSummary.SetParameterValue("address", "");
                            objInvoiceWiseSalesSummary.SetParameterValue("@FromDate", "");
                            objInvoiceWiseSalesSummary.SetParameterValue("@ToDate", "");
                        }
                        rptViewer.ReportSource = objInvoiceWiseSalesSummary;
                        rptViewer.DataBind();

                        break;
                    #endregion

                    #region Invoice Wise Sales Details
                    case "InvoiceWiseSalesDetails":
                        if (Request.QueryString["ShopID"] == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        ShopID = Request.QueryString["ShopID"].ToString();
                        if (ShopID != "All")
                            dtShopStatic = new ReportDbSource().GetByShopName(ShopID);
                        else
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");
                         sDate = Request.QueryString["sDate"].ToString();
                        eDate = Request.QueryString["eDate"].ToString();
                        rptInvoiceWiseSalesDetails objInvoiceWiseSalesDetails = new rptInvoiceWiseSalesDetails();
                        objInvoiceWiseSalesDetails.SetDataSource(dtInvoiceWiseSalesDetails);
                        if (dtShopStatic.Rows.Count > 0)
                        {
                            objInvoiceWiseSalesDetails.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            objInvoiceWiseSalesDetails.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            objInvoiceWiseSalesDetails.SetParameterValue("@FromDate", sDate);
                            objInvoiceWiseSalesDetails.SetParameterValue("@ToDate", eDate);
                        }
                        else
                        {
                            objInvoiceWiseSalesDetails.SetParameterValue("shopname", "");
                            objInvoiceWiseSalesDetails.SetParameterValue("address", "");
                            objInvoiceWiseSalesDetails.SetParameterValue("@FromDate", "");
                            objInvoiceWiseSalesDetails.SetParameterValue("@ToDate", "");
                        }
                        rptViewer.ReportSource = objInvoiceWiseSalesDetails;
                        rptViewer.DataBind();

                        break;
                    #endregion

                    #region Group Wise Sales
                    case "GroupWiseSales":
                        if (Request.QueryString["ShopID"] == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        ShopID = Request.QueryString["ShopID"].ToString();
                        if (ShopID != "All")
                            dtShopStatic = new ReportDbSource().GetByShopName(ShopID);
                        else
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");

                        rptGroupWiseSalesReport objGroupWiseSales = new rptGroupWiseSalesReport();

                        sDate = Request.QueryString["sDate"].ToString();
                        eDate = Request.QueryString["eDate"].ToString();

                        objGroupWiseSales.SetDataSource(dtGroupWiseSales);
                        if (dtShopStatic.Rows.Count > 0)
                        {
                            objGroupWiseSales.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            objGroupWiseSales.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            objGroupWiseSales.SetParameterValue("@FromDate", sDate);
                            objGroupWiseSales.SetParameterValue("@ToDate", eDate);
                        }
                        else
                        {
                            objGroupWiseSales.SetParameterValue("shopname", "");
                            objGroupWiseSales.SetParameterValue("address", "");
                            objGroupWiseSales.SetParameterValue("@FromDate", "");
                            objGroupWiseSales.SetParameterValue("@ToDate", "");
                        }
                        rptViewer.ReportSource = objGroupWiseSales;
                        rptViewer.DataBind();

                        break;
                    #endregion

                    #region Cashier Wise Sales
                    case "CashierWiseSales":
                        if (Request.QueryString["ShopID"] == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null)
                            return;

                        ShopID = Request.QueryString["ShopID"].ToString();
                        if (ShopID != "All")
                            dtShopStatic = new ReportDbSource().GetByShopName(ShopID);
                        else
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");

                        rptSalesCashierSummary objCashierWiseSales = new rptSalesCashierSummary();

                        sDate = Request.QueryString["sDate"].ToString();
                        eDate = Request.QueryString["eDate"].ToString();

                        objCashierWiseSales.SetDataSource(dtCashierWiseSales);
                        if (dtShopStatic.Rows.Count > 0)
                        {
                            objCashierWiseSales.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            objCashierWiseSales.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            objCashierWiseSales.SetParameterValue("@FromDate", sDate);
                            objCashierWiseSales.SetParameterValue("@ToDate", eDate);
                        }
                        else
                        {
                            objCashierWiseSales.SetParameterValue("shopname", "");
                            objCashierWiseSales.SetParameterValue("address", "");
                            objCashierWiseSales.SetParameterValue("@FromDate", "");
                            objCashierWiseSales.SetParameterValue("@ToDate", "");
                        }
                        rptViewer.ReportSource = objCashierWiseSales;
                        rptViewer.DataBind();

                        break;
                    #endregion

                    #region Sales
                    case "Invoice":
                        if (Request.QueryString["Invoice"] == null)
                            return;

                        dtShopStatic = new ReportDbSource().GetByShopName("9999");
                        rptInvoice objSale = new rptInvoice();
                        objSale.SetDataSource(dtSales);
                        if (dtShopStatic.Rows.Count > 0)
                        {
                            objSale.SetParameterValue("@ShopName", dtShopStatic.Rows[0]["ShopName"].ToString());
                            objSale.SetParameterValue("@Contact", dtShopStatic.Rows[0]["Contact"].ToString());
                            objSale.SetParameterValue("@Phone", dtShopStatic.Rows[0]["Phone"].ToString());
                            objSale.SetParameterValue("@ShopAddr", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            objSale.SetParameterValue("@ShopName", "");
                            objSale.SetParameterValue("@Contact", "");
                            objSale.SetParameterValue("@Contact", "");
                            objSale.SetParameterValue("@ShopAddr", "");
                        }
                        rptViewer.ReportSource = objSale;
                        rptViewer.DataBind();

                        break;
                    #endregion

                    #region Credit Collection
                    case "CreditCollection":
                        if (Request.QueryString["ID"] == null)
                            return;

                        ShopID = GetLogedInInfo().ShopID;
                        dtShopStatic = new ReportDbSource().GetByShopName(ShopID);

                        rpt_CreditCollection objCreditCol = new rpt_CreditCollection();

                        objCreditCol.SetDataSource(dtCreditCollectin);
                        if (dtShopStatic.Rows.Count > 0)
                        {
                            objCreditCol.SetParameterValue("@printedby", Page.User.Identity.Name);
                            objCreditCol.SetParameterValue("@ShopName", dtShopStatic.Rows[0]["ShopName"].ToString());
                            objCreditCol.SetParameterValue("@ShopAddr", dtShopStatic.Rows[0]["Address"].ToString());
                        }
                        else
                        {
                            objCreditCol.SetParameterValue("@printedby", Page.User.Identity.Name);
                            objCreditCol.SetParameterValue("@ShopName", "");
                            objCreditCol.SetParameterValue("@ShopAddr", "");
                        }
                        rptViewer.ReportSource = objCreditCol;
                        rptViewer.DataBind();

                        break;
                    #endregion

                    #region Counter Wise Sales
                    case "CounterWiseSales":
                        if (Request.QueryString["ShopID"] == null || Request.QueryString["sDate"].ToString() == null || Request.QueryString["eDate"].ToString() == null || Request.QueryString["CounterID"].ToString() == null)
                            return;

                        ShopID = Request.QueryString["ShopID"].ToString();
                        if (ShopID != "All")
                            dtShopStatic = new ReportDbSource().GetByShopName(ShopID);
                        else
                            dtShopStatic = new ReportDbSource().GetByShopName("9999");

                        rptSalesCounterSummary objCounterWiseSales = new rptSalesCounterSummary();

                        sDate = Request.QueryString["sDate"].ToString();
                        eDate = Request.QueryString["eDate"].ToString();

                        objCounterWiseSales.SetDataSource(dtCounterWiseSales);
                        if (dtShopStatic.Rows.Count > 0)
                        {
                            objCounterWiseSales.SetParameterValue("shopname", dtShopStatic.Rows[0]["ShopName"].ToString());
                            objCounterWiseSales.SetParameterValue("address", dtShopStatic.Rows[0]["Address"].ToString());
                            objCounterWiseSales.SetParameterValue("@FromDate", sDate);
                            objCounterWiseSales.SetParameterValue("@ToDate", eDate);
                        }
                        else
                        {
                            objCounterWiseSales.SetParameterValue("shopname", "");
                            objCounterWiseSales.SetParameterValue("address", "");
                            objCounterWiseSales.SetParameterValue("@FromDate", "");
                            objCounterWiseSales.SetParameterValue("@ToDate", "");
                        }
                        rptViewer.ReportSource = objCounterWiseSales;
                        rptViewer.DataBind();

                        break;
                    #endregion


                }
            }
            catch (Exception ex)
            {

            }
        }
        private LogedInInfo GetLogedInInfo()
        {
            LogedInInfo info = new LogedInInfo();
            if (Request.Cookies["POSLogedInInfo"] != null)
            {
                var value = Request.Cookies["POSLogedInInfo"].Value;
                info = Newtonsoft.Json.JsonConvert.DeserializeObject<LogedInInfo>(value) as LogedInInfo;
            }
            return info;
        }
    }
}